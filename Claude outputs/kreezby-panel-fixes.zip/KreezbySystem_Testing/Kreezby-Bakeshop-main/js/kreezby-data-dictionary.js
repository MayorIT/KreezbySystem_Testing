/**
 * Capstone data dictionary (section 3.4) stored in the browser and shown
 * on stocks, alerts, sales, and account screens.
 */
(function () {
    'use strict';

    var STORE_KEY = 'kreezby_data_dictionary_v1';
    var lastSaleError = '';
    var ALERT_LINES = {
        'CRK-CHO-P': 100, 'CRK-ALM-P': 80, 'CRK-LEM-P': 90, 'CRK-BUT-J': 70, 'CRK-MNG-J': 60, 'CRK-UBE-P': 50,
        'RM-WFL-01': 40, 'RM-WSG-01': 30, 'RM-OIL-01': 20, 'RM-EGG-01': 24, 'RM-COC-01': 20,
        'RM-BKP-01': 10, 'RM-SLT-01': 15, 'RM-CFS-01': 12, 'RM-PSB-01': 5
    };
    var SALES_DATES = ['2026-09-20', '2026-09-21', '2026-09-22', '2026-09-23', '2026-09-24', '2026-09-25', '2026-09-26'];
    var FORECAST_DATE = '2026-09-27';

    var PRODUCTS = [
        { product_id: 'CRK-CHO-P', product_name: 'Chocolate Crinkles', batch_number: 'BCH-2026-0918-CHO', production_date: '2026-09-18', expiration_date: '2026-11-18', expiry_threshold_days: 3, quantities: [0, 0, 0, 0, 0, 0, 0] },
        { product_id: 'CRK-ALM-P', product_name: 'Choco-Almond Crinkles', batch_number: 'BCH-2026-0917-ALM', production_date: '2026-09-17', expiration_date: '2026-11-17', expiry_threshold_days: 3, quantities: [0, 0, 0, 0, 0, 0, 0] },
        { product_id: 'CRK-LEM-P', product_name: 'Lemon Crinkles', batch_number: 'BCH-2026-0920-LEM', production_date: '2026-09-20', expiration_date: '2026-10-21', expiry_threshold_days: 3, quantities: [0, 0, 0, 0, 0, 0, 0] },
        { product_id: 'CRK-BUT-J', product_name: 'Choco Butternut Crinkles', batch_number: 'BCH-2026-0915-BUT', production_date: '2026-09-15', expiration_date: '2026-11-15', expiry_threshold_days: 3, quantities: [0, 0, 0, 0, 0, 0, 0] },
        { product_id: 'CRK-MNG-J', product_name: 'Mango Crinkles', batch_number: 'BCH-2026-0908-MNG', production_date: '2026-09-08', expiration_date: '2026-09-26', expiry_threshold_days: 3, quantities: [0, 0, 0, 0, 0, 0, 0] },
        { product_id: 'CRK-UBE-P', product_name: 'Ube Crinkles', batch_number: 'BCH-2026-0919-UBE', production_date: '2026-09-19', expiration_date: '2026-11-19', expiry_threshold_days: 3, quantities: [0, 0, 0, 0, 0, 0, 0] }
    ];

    var RAW_MATERIALS = [
        { material_id: 'RM-WFL-01', name: 'Wheat Flour', current_stock: 0, expiration_date: '2027-03-01', expiry_threshold_days: 7 },
        { material_id: 'RM-WSG-01', name: 'White Sugar', current_stock: 0, expiration_date: '2027-06-01', expiry_threshold_days: 7 },
        { material_id: 'RM-OIL-01', name: 'Vegetable Oil', current_stock: 0, expiration_date: '2027-01-15', expiry_threshold_days: 7 },
        { material_id: 'RM-EGG-01', name: 'Egg', current_stock: 0, expiration_date: '2026-10-22', expiry_threshold_days: 7 },
        { material_id: 'RM-COC-01', name: 'Cocoa', current_stock: 0, expiration_date: '2026-12-20', expiry_threshold_days: 7 },
        { material_id: 'RM-BKP-01', name: 'Baking Powder', current_stock: 0, expiration_date: '2027-04-01', expiry_threshold_days: 7 },
        { material_id: 'RM-SLT-01', name: 'Salt', current_stock: 0, expiration_date: '2028-01-01', expiry_threshold_days: 7 },
        { material_id: 'RM-CFS-01', name: 'Confectioner Sugar', current_stock: 0, expiration_date: '2027-05-01', expiry_threshold_days: 7 },
        { material_id: 'RM-PSB-01', name: 'Potassium Sorbate', current_stock: 0, expiration_date: '2027-08-01', expiry_threshold_days: 7 }
    ];

    // Packaging stock (same codes as the Inventory list).
    var PACKAGING_MATERIALS = [
        { material_id: 'PKG-SUP-01', name: 'Stand up pouch', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        // One sticker stock per flavor, so each flavor's sticker count is clear.
        { material_id: 'PKG-STK-CHO', name: 'Stickers (Chocolate)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-ALM', name: 'Stickers (Choco-Almond)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-CSH', name: 'Stickers (Choco-Cashew)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-STR', name: 'Stickers (Strawberry)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-RVL', name: 'Stickers (Red Velvet)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-LEM', name: 'Stickers (Lemon)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-MEL', name: 'Stickers (Melon)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-PAN', name: 'Stickers (Pandan)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-UBE', name: 'Stickers (Ube)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-MNG', name: 'Stickers (Mango)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-BUT', name: 'Stickers (Choco Butternut)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 },
        { material_id: 'PKG-STK-AST', name: 'Stickers (Assorted)', type: 'packaging-material', current_stock: 0, expiration_date: '', expiry_threshold_days: 0 }
    ];

    var PROCUREMENT = [
        { product_id: 'CRK-CHO-P', product_name: 'Chocolate Crinkles', current_stock: 0, recommended_quantity: 400 },
        { product_id: 'CRK-LEM-P', product_name: 'Lemon Crinkles', current_stock: 0, recommended_quantity: 200 },
        { product_id: 'CRK-MNG-J', product_name: 'Mango Crinkles', current_stock: 0, recommended_quantity: 200 },
        { product_id: 'CRK-ALM-P', product_name: 'Choco-Almond Crinkles', current_stock: 0, recommended_quantity: 300 },
        { product_id: 'CRK-BUT-J', product_name: 'Choco Butternut Crinkles', current_stock: 0, recommended_quantity: 200 },
        { product_id: 'CRK-UBE-P', product_name: 'Ube Crinkles', current_stock: 0, recommended_quantity: 200 }
    ];

    var FLAVOR_CHOICES = [
        'Chocolate Crinkles',
        'Choco-Almond Crinkles',
        'Choco-Cashew Crinkles',
        'Strawberry Crinkles',
        'Red Velvet Crinkles',
        'Lemon Crinkles',
        'Melon Crinkles',
        'Pandan Crinkles',
        'Ube Crinkles',
        'Mango Crinkles',
        'Choco Butternut Crinkles',
        'Assorted Crinkles'
    ];

    function productId(name) {
        var text = String(name || '').toLowerCase();
        if (!text) return '';
        if (text.indexOf('oatmeal') >= 0) return 'CKE-OAT-P';
        if (text.indexOf('assorted') >= 0) return 'CRK-AST-P';
        if (text.indexOf('almond') >= 0) return 'CRK-ALM-P';
        if (text.indexOf('cashew') >= 0) return 'CRK-CSH-P';
        if (text.indexOf('butternut') >= 0) return 'CRK-BUT-J';
        if (text.indexOf('strawberry') >= 0) return 'CRK-STR-P';
        if (text.indexOf('velvet') >= 0) return 'CRK-RV-P';
        if (text.indexOf('lemon') >= 0) return 'CRK-LEM-P';
        if (text.indexOf('melon') >= 0) return 'CRK-MEL-P';
        if (text.indexOf('pandan') >= 0) return 'CRK-PAN-P';
        if (text.indexOf('mango') >= 0) return 'CRK-MNG-J';
        if (text.indexOf('ube') >= 0) return 'CRK-UBE-P';
        if (text.indexOf('chocolate') >= 0) return 'CRK-CHO-P';
        return '';
    }

    function productById(id) {
        var products = mergedProducts();
        for (var i = 0; i < products.length; i++) {
            if (products[i].product_id === id) return products[i];
        }
        return null;
    }

    function savedState() {
        return readJson(STORE_KEY, {});
    }

    function writeState(saved) {
        try { localStorage.setItem(STORE_KEY, JSON.stringify(saved)); } catch (e) { /* ignore */ }
    }

    function productStockMap() {
        var saved = savedState().product_stock || {};
        var map = {};
        PROCUREMENT.forEach(function (row) {
            map[row.product_id] = saved[row.product_id] != null ? Number(saved[row.product_id]) : row.current_stock;
        });
        Object.keys(saved).forEach(function (id) {
            if (map[id] == null && saved[id] != null) map[id] = Number(saved[id]);
        });
        return map;
    }

    function allMaterials() {
        return RAW_MATERIALS.concat(PACKAGING_MATERIALS, savedState().materials_extra || []);
    }

    function materialStockMap() {
        var saved = savedState().material_stock || {};
        var map = {};
        allMaterials().forEach(function (row) {
            map[row.material_id] = saved[row.material_id] != null ? Number(saved[row.material_id]) : (Number(row.current_stock) || 0);
        });
        return map;
    }

    function mergedProducts() {
        var edits = savedState().product_edits || {};
        var extra = savedState().products_extra || [];
        return PRODUCTS.map(function (product) {
            return Object.assign({}, product, edits[product.product_id] || {});
        }).concat(extra);
    }

    function materialByName(name) {
        var text = String(name || '').trim().toLowerCase();
        if (!text) return null;
        var list = allMaterials();
        for (var i = 0; i < list.length; i++) {
            if (list[i].name.toLowerCase() === text) return list[i];
        }
        return null;
    }

    function isPackaging(row) {
        return !!row && (row.type === 'packaging-material' || /^PKG-/.test(String(row.material_id || '')));
    }

    // ---- Cost per unit of raw and packaging materials (used for the stock value) ----
    // Kept in kreezby-stock-local-v1 -> cost[code], the same place the Stocks page and the
    // Inventory "Cost" column read from.
    var STOCK_LOCAL_KEY = 'kreezby-stock-local-v1';
    var DEFAULT_UNIT_COSTS = {
        'RM-WFL-01': 48, 'RM-WSG-01': 42, 'RM-OIL-01': 95, 'RM-EGG-01': 9, 'RM-COC-01': 180,
        'RM-BKP-01': 35, 'RM-SLT-01': 18, 'RM-CFS-01': 55, 'RM-PSB-01': 220,
        'PKG-SUP-01': 12, 'PKG-STK-CHO': 3, 'PKG-STK-ALM': 3, 'PKG-STK-CSH': 3, 'PKG-STK-STR': 3, 'PKG-STK-RVL': 3, 'PKG-STK-LEM': 3, 'PKG-STK-MEL': 3, 'PKG-STK-PAN': 3, 'PKG-STK-UBE': 3, 'PKG-STK-MNG': 3, 'PKG-STK-BUT': 3, 'PKG-STK-AST': 3
    };

    function materialUnitCost(code) {
        var local = readJson(STOCK_LOCAL_KEY, {}) || {};
        var costs = local.cost || {};
        if (costs[code] != null && costs[code] !== '') return Number(costs[code]) || 0;
        return DEFAULT_UNIT_COSTS[code] || 0;
    }

    // New stock bought at a different price: the unit cost becomes the average of what is on
    // hand, so stock value = old value + value of what was just added.
    function saveMaterialUnitCost(code, qtyBefore, qtyAdded, unitCost) {
        var local = readJson(STOCK_LOCAL_KEY, {}) || {};
        local.qty = local.qty || {};
        local.history = local.history || {};
        local.extra = local.extra || [];
        local.cost = local.cost || {};
        var oldQty = Math.max(0, Number(qtyBefore) || 0);
        var addQty = Math.max(0, Number(qtyAdded) || 0);
        var oldCost = materialUnitCost(code);
        var next = oldQty > 0
            ? (oldQty * oldCost + addQty * unitCost) / (oldQty + addQty)
            : unitCost;
        local.cost[code] = Math.round(next * 100) / 100;
        try { localStorage.setItem(STOCK_LOCAL_KEY, JSON.stringify(local)); } catch (e) { /* keep the stock count */ }
        return local.cost[code];
    }

    function ensureMaterial(name, kind) {
        var existing = materialByName(name);
        if (existing) return existing;
        var trimmed = String(name || '').trim();
        if (!trimmed) return null;
        var packaging = kind === 'packaging';
        var prefix = packaging ? 'PKG-' : 'RM-';
        var id = prefix + trimmed.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24);
        if (!id || id === prefix) id = prefix + Date.now();
        var row = { material_id: id, name: trimmed, type: packaging ? 'packaging-material' : 'raw-material', current_stock: 0, expiration_date: '', expiry_threshold_days: packaging ? 0 : 7 };
        var saved = savedState();
        var extra = saved.materials_extra || [];
        extra.push(row);
        saved.materials_extra = extra;
        writeState(saved);
        return row;
    }

    function liveProcurement() {
        var stock = productStockMap();
        return PROCUREMENT.map(function (row) {
            return {
                product_id: row.product_id,
                product_name: row.product_name,
                current_stock: stock[row.product_id],
                recommended_quantity: row.recommended_quantity
            };
        });
    }

    function readJson(key, fallback) {
        try {
            var raw = localStorage.getItem(key);
            return raw ? JSON.parse(raw) : fallback;
        } catch (e) {
            return fallback;
        }
    }

    function salesTransactions() {
        var extra = readJson(STORE_KEY, {}).sales_transactions_extra || [];
        var rows = [];
        PRODUCTS.forEach(function (product) {
            product.quantities.forEach(function (qty, index) {
                rows.push({
                    sales_date: SALES_DATES[index],
                    product_id: product.product_id,
                    quantity_sold: qty
                });
            });
        });
        extra.forEach(function (row) {
            if (row && row.product_id && row.sales_date) rows.push(row);
        });
        return rows;
    }

    function daysUntil(dateStr) {
        var text = String(dateStr || '').slice(0, 10);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return null;
        var parts = text.split('-');
        var exp = Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
        var now = new Date();
        var today = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
        return Math.round((exp - today) / 86400000);
    }

    function shelfLifeText(days) {
        if (days < 0) {
            var past = Math.abs(days);
            return past + (past === 1 ? ' day' : ' days') + ' past expiry';
        }
        if (days === 0) return 'expires today';
        return days + (days === 1 ? ' day' : ' days') + ' of shelf life left';
    }

    function alertStatusFor(type, ref) {
        var saved = savedState().alert_status || {};
        return saved[type + ':' + ref] || 'pending';
    }

    function configuredLine(code, fallback) {
        var settings = readJson('kreezbyAlertSettings', null);
        if (settings && settings.items && settings.items[code] != null && settings.items[code] !== '') {
            var custom = Number(settings.items[code]);
            if (Number.isFinite(custom) && custom >= 0) return custom;
        }
        return fallback;
    }

    function pushAlert(list, type, role, ref, message) {
        list.push({
            alert_type: type,
            target_role: role,
            reference_id: ref,
            message: message,
            status: alertStatusFor(type, ref)
        });
    }

    function alerts() {
        var list = [];
        var stock = productStockMap();
        mergedProducts().forEach(function (product) {
            var qty = Number(stock[product.product_id]);
            if (!Number.isFinite(qty)) qty = 0;
            var line = configuredLine(product.product_id, ALERT_LINES[product.product_id]);
            if (line != null && qty <= line) {
                pushAlert(list, 'low_stock', 'Admin', product.product_id, product.product_name + ' is at ' + qty + ' pouches, at or below the alert line of ' + line + '.');
            }
            // No stock means no batch on hand, so no expiry alert for it.
            if (qty <= 0) return;
            var threshold = Number(product.expiry_threshold_days);
            if (!Number.isFinite(threshold)) threshold = 3;
            // Every batch still on hand is checked with its own expiry date.
            var split = productBatches(product.product_name);
            var lots = split.batches.filter(function (b) { return b.remaining > 0; }).map(function (b) {
                return { batch: b.batch_number, expires: b.expiration_date, qty: b.remaining };
            });
            if (split.earlier > 0 || !lots.length) {
                lots.push({ batch: product.batch_number, expires: product.expiration_date, qty: split.earlier > 0 ? split.earlier : qty });
            }
            lots.forEach(function (lot) {
                var days = daysUntil(lot.expires);
                if (days == null) return;
                var batch = lot.batch ? (' batch ' + lot.batch) : '';
                var pcs = ' (' + lot.qty + ' ' + (lot.qty === 1 ? 'pouch' : 'pouches') + ')';
                if (days < 0) {
                    pushAlert(list, 'expired', 'Admin', product.product_id, product.product_name + batch + pcs + ' expired on ' + lot.expires + ' (' + shelfLifeText(days) + ') and cannot be sold.');
                } else if (days <= threshold) {
                    pushAlert(list, 'near_expiry', 'Staff', product.product_id, product.product_name + batch + pcs + ' expires on ' + lot.expires + ', with ' + shelfLifeText(days) + '.');
                }
            });
        });
        var materials = materialStockMap();
        allMaterials().forEach(function (item) {
            var qty = Number(materials[item.material_id]);
            if (!Number.isFinite(qty)) qty = 0;
            var line = configuredLine(item.material_id, ALERT_LINES[item.material_id]);
            if (line != null && qty <= line) {
                pushAlert(list, 'low_stock', 'Staff', item.material_id, item.name + ' is at ' + qty + ', at or below the alert line of ' + line + '.');
            }
            if (qty <= 0) return;
            var days = daysUntil(item.expiration_date);
            if (days == null) return;
            var threshold = Number(item.expiry_threshold_days);
            if (!Number.isFinite(threshold)) threshold = 7;
            if (days < 0) {
                pushAlert(list, 'expired', 'Admin', item.material_id, item.name + ' expired on ' + item.expiration_date + ' (' + shelfLifeText(days) + ').');
            } else if (days <= threshold) {
                pushAlert(list, 'near_expiry', 'Staff', item.material_id, item.name + ' expires on ' + item.expiration_date + ', with ' + shelfLifeText(days) + '.');
            }
        });
        (savedState().partner_alerts || []).forEach(function (alert) {
            if (alert && alert.message) list.push(alert);
        });
        return list;
    }

    function staffInventoryAlerts() {
        var stock = productStockMap();
        return mergedProducts().map(function (product) {
            var quantity = Number(stock[product.product_id]);
            if (!Number.isFinite(quantity)) quantity = 0;
            var threshold = configuredLine(product.product_id, ALERT_LINES[product.product_id]);
            if (threshold == null || quantity > threshold) return null;
            return {
                product: product.product_name,
                category: 'Finished Goods',
                currentStock: quantity,
                threshold: Number(threshold),
                status: 'Low Stock'
            };
        }).filter(Boolean);
    }

    function users() {
        var source = { admins: [], staff: [], retailers: [], customers: [] };
        if (window.KreezbyMaintenanceSettings && typeof window.KreezbyMaintenanceSettings.getUsers === 'function') {
            source = window.KreezbyMaintenanceSettings.getUsers();
        }
        var rows = [];
        function push(list, role) {
            (list || []).forEach(function (user) {
                rows.push({
                    user_id: user.user_id || user.id,
                    role: role,
                    password_hash: user.password_hash || ('ph_' + (user.user_id || user.id))
                });
            });
        }
        push(source.admins, 'Admin');
        push(source.staff, 'Staff');
        push(source.retailers, 'Retailer');
        push(source.customers, 'Customer');
        return rows;
    }

    function orders() {
        var rows = [];
        readJson('kreezbyOrders', []).forEach(function (order) {
            if (!order) return;
            rows.push({
                order_id: order.orderNumber || order.receiptNumber,
                account_type: order.accountType || 'Regular Customer',
                account_name: order.accountName || '',
                account_area: order.accountArea || '',
                status: order.status || '',
                date: order.date || ''
            });
        });
        var pos = readJson('kreezby-po-orders-v1', {});
        Object.keys(pos || {}).forEach(function (code) {
            var order = pos[code];
            if (!order) return;
            rows.push({
                order_id: order.code || code,
                account_type: order.accountType || '',
                account_name: order.accountName || order.entity || '',
                account_area: order.accountArea || order.area || '',
                status: order.status || '',
                date: order.dateCreated || ''
            });
        });
        return rows;
    }

    var BASE_MOVEMENTS = [];

    function inventoryTransactions() {
        return BASE_MOVEMENTS.concat(savedState().inventory_transactions_extra || []);
    }

    function orderItemList(raw) {
        if (Array.isArray(raw)) return raw;
        if (!raw || typeof raw !== 'object') return [];
        return Object.keys(raw).map(function (key) { return raw[key]; });
    }

    function isOpenOrderStatus(status) {
        var text = String(status || '').toLowerCase();
        if (!text) return true;
        // Failed, expired, refunded or held payments are not orders to bake for.
        if (/fail|expire|refund|review/.test(text)) return false;
        return text !== 'completed' && text !== 'shipped' && text !== 'delivered'
            && text !== 'cancelled' && text !== 'canceled' && text !== 'received'
            && text !== 'rejected' && text !== 'returned';
    }

    function pendingOrderLines() {
        var seen = {};
        var lines = [];
        function add(orderId, status, items, deducted) {
            var id = String(orderId || '');
            if (!id || seen[id] || !isOpenOrderStatus(status)) return;
            seen[id] = true;
            orderItemList(items).forEach(function (item) {
                var name = item && item.name;
                var qty = Number(item && (item.qty != null ? item.qty : item.quantity)) || 0;
                var product = productId(name);
                if (!product || qty <= 0) return;
                lines.push({
                    productId: product,
                    qty: qty,
                    deducted: !!deducted
                });
            });
        }
        readJson('kreezbyOrders', []).forEach(function (order) {
            if (!order) return;
            var deducted = !!order.inventoryDeducted;
            add(order.orderNumber || order.receiptNumber, order.status, order.items, deducted);
        });
        var pos = readJson('kreezby-po-orders-v1', {});
        Object.keys(pos || {}).forEach(function (code) {
            var order = pos[code];
            if (!order) return;
            add(order.code || code, order.status, order.items, order.inventoryDeducted);
        });
        return lines;
    }

    // ---- Production recommendation: a fixed formula (no AI) ----
    //   Good stock (S)      = pouches on hand − expired pouches (expired are never counted)
    //   Customer orders (O) = open customer orders whose pouches are not yet taken from stock
    //   Retailer deliveries (R) = usual pouches of every shop on the Delivery Schedule in the next
    //                         7 days (retailers receive Chocolate Crinkles only)
    //   Need                = O + R − S (0 when stock covers it)
    //   Packaging limit (P) = pouches that can be packed now = min(stand up pouches, flavor stickers)
    //   Bake                = Need, shown with how many days it takes at the daily capacity
    //                         (250 crinkles a day ÷ 10 crinkles per pouch = 25 pouches a day).
    // GPT-4o mini only explains these numbers in words; it cannot change them or any record.
    var CRINKLES_PER_POUCH = 10;
    var DAILY_CAPACITY_CRINKLES = 250;
    var DAILY_CAPACITY_POUCHES = DAILY_CAPACITY_CRINKLES / CRINKLES_PER_POUCH;
    var RETAILER_PRODUCT = 'Chocolate Crinkles';

    function retailerCommitments(days) {
        var rows = readJson('kreezby_delivery_schedule_v5', []);
        if (!Array.isArray(rows)) rows = [];
        var users = (readJson('kreezby_maintenance_users', {}) || {}).retailers || [];
        var today = todayIso();
        var end = new Date(Date.now() + days * 86400000).toISOString().slice(0, 10);
        var total = 0;
        rows.forEach(function (row) {
            if (!row || !row.date || row.date < today || row.date > end) return;
            (row.shops || []).forEach(function (shop) {
                var u = users.filter(function (x) {
                    return x && ((shop.id && (x.id === shop.id || x._id === shop.id)) || String(x.name || x.shopName || '').toLowerCase() === String(shop.name || '').toLowerCase());
                })[0];
                total += Number(u && u.usualPcs) || 0;
            });
        });
        return total;
    }

    function packagingLimit(productName) {
        var list = packagingForProduct(productName);
        if (!list.length) return null;
        var stock = materialStockMap();
        return list.reduce(function (min, m) {
            var have = Number(stock[m.material_id]) || 0;
            return min == null ? have : Math.min(min, have);
        }, null);
    }

    function productRecommendationSnapshot() {
        var pendingByProduct = {};
        var uncoveredByProduct = {};
        pendingOrderLines().forEach(function (line) {
            pendingByProduct[line.productId] = (pendingByProduct[line.productId] || 0) + line.qty;
            if (!line.deducted) uncoveredByProduct[line.productId] = (uncoveredByProduct[line.productId] || 0) + line.qty;
        });
        var retailerPouches = retailerCommitments(7);
        var seen = {};
        function rowFor(id, name) {
            if (!id || seen[id]) return null;
            seen[id] = true;
            var product = productById(id);
            var productName = (product && product.product_name) || name || id;
            var split = productBatches(productName);
            var goodStock = split.sellable;
            var expiredStock = split.expired;
            var pendingOrders = pendingByProduct[id] || 0;
            var stillToCover = uncoveredByProduct[id] || 0;
            var retailer = productName.toLowerCase() === RETAILER_PRODUCT.toLowerCase() ? retailerPouches : 0;
            var gap = stillToCover + retailer - goodStock;
            var bake = gap > 0 ? Math.ceil(gap) : 0;
            var pack = packagingLimit(productName);
            return {
                name: productName,
                finishedStock: goodStock,
                expiredStock: expiredStock,
                pendingOrders: pendingOrders,
                pendingStillToCover: stillToCover,
                retailerDeliveries: retailer,
                suggestedBake: bake,
                packagingAvailable: pack,
                packagingShort: pack != null && bake > pack ? bake - pack : 0
            };
        }
        var products = [];
        liveProcurement().forEach(function (row) {
            var next = rowFor(row.product_id, row.product_name);
            if (next) products.push(next);
        });
        Object.keys(pendingByProduct).forEach(function (id) {
            var next = rowFor(id, id);
            if (next) products.push(next);
        });
        var totalBake = products.reduce(function (t, p) { return t + p.suggestedBake; }, 0);
        return {
            asOf: new Date().toISOString().slice(0, 10),
            products: products,
            totalBake: totalBake,
            dailyCapacity: DAILY_CAPACITY_POUCHES,
            daysNeeded: totalBake ? Math.ceil(totalBake / DAILY_CAPACITY_POUCHES) : 0,
            crinklesPerPouch: CRINKLES_PER_POUCH
        };
    }

    function insightSnapshot() {
        var salesByProduct = {};
        salesTransactions().forEach(function (row) {
            if (!row || !row.product_id) return;
            salesByProduct[row.product_id] = (salesByProduct[row.product_id] || 0) + (Number(row.quantity_sold) || 0);
        });
        var materialStock = materialStockMap();
        return {
            asOf: new Date().toISOString().slice(0, 10),
            products: liveProcurement().map(function (row) {
                return {
                    name: row.product_name,
                    stock: row.current_stock,
                    recommendedStock: row.recommended_quantity,
                    recentSales: salesByProduct[row.product_id] || 0
                };
            }),
            materials: RAW_MATERIALS.map(function (item) {
                return {
                    name: item.name,
                    stock: materialStock[item.material_id],
                    expires: item.expiration_date
                };
            }),
            alerts: alerts().filter(function (alert) {
                return alert.status === 'pending';
            }).map(function (alert) {
                return alert.message;
            })
        };
    }

    function snapshot() {
        var sales = salesTransactions();
        var previous = savedState();
        var materialStock = materialStockMap();
        var data = {
            users: users(),
            products: mergedProducts().map(function (product) {
                return {
                    product_id: product.product_id,
                    product_name: product.product_name,
                    batch_number: product.batch_number,
                    production_date: product.production_date,
                    expiration_date: product.expiration_date,
                    expiry_threshold_days: product.expiry_threshold_days
                };
            }),
            raw_materials: allMaterials().map(function (item) {
                return {
                    material_id: item.material_id,
                    name: item.name,
                    current_stock: materialStock[item.material_id],
                    expiration_date: item.expiration_date,
                    expiry_threshold_days: item.expiry_threshold_days
                };
            }),
            inventory_transactions: inventoryTransactions(),
            sales_transactions: sales,
            orders: orders(),
            alerts: alerts(),
            procurement_recommendations: liveProcurement().map(function (row) {
                var shortage = row.current_stock - row.recommended_quantity;
                return {
                    product_id: row.product_id,
                    product_name: row.product_name,
                    current_stock: row.current_stock,
                    recommended_quantity: row.recommended_quantity,
                    shortage: shortage < 0 ? Math.abs(shortage) : 0
                };
            }),
            audit_logs: readJson('kreezby_login_history', []).slice(0, 20).map(function (log) {
                return {
                    user_id: log.identity || log.userName,
                    action: 'login',
                    at: log.loggedAt || ''
                };
            })
        };
        data.sales_transactions_extra = previous.sales_transactions_extra || [];
        data.inventory_transactions_extra = previous.inventory_transactions_extra || [];
        data.product_stock = productStockMap();
        data.material_stock = materialStock;
        data.product_edits = previous.product_edits || {};
        data.products_extra = previous.products_extra || [];
        data.materials_extra = previous.materials_extra || [];
        data.alert_status = previous.alert_status || {};
        data.partner_alerts = previous.partner_alerts || [];
        data.product_prices = previous.product_prices || {};
        data.product_batches = previous.product_batches || [];
        if (previous.retailer_price != null) data.retailer_price = previous.retailer_price;
        writeState(data);
        return data;
    }

    var lastSaleShort = null;

    function saleBlockReason(productName) {
        var id = productId(productName);
        if (!id) return 'unknown';
        var product = productById(id);
        var days = product ? daysUntil(product.expiration_date) : null;
        if (days != null && days < 0) return 'expired';
        // Every pouch on hand is from an expired batch: nothing can be sold.
        var split = productBatches(productName);
        if (split.onHand > 0 && split.sellable <= 0 && split.expired > 0) return 'expired';
        return '';
    }

    function pushPartnerNotice(type, name, message) {
        var saved = savedState();
        var list = saved.partner_alerts || [];
        list.unshift({
            alert_type: type,
            target_role: 'Customer',
            reference_id: productId(name) || name,
            message: message,
            status: 'pending',
            at: new Date().toISOString()
        });
        saved.partner_alerts = list.slice(0, 40);
        writeState(saved);
        var note = {
            id: 'partner-' + type + '-' + Date.now(),
            title: type === 'price_change' ? 'Price update' : 'New flavor',
            description: message,
            source: type,
            // Retailers pay a fixed retailer price, so shop price changes are for customers only.
            audiences: type === 'price_change' ? ['customer'] : ['customer', 'retailer'],
            timestamp: new Date().toISOString(),
            read: false
        };
        if (window.KreezbyNotifications && typeof window.KreezbyNotifications.push === 'function') {
            window.KreezbyNotifications.push(note);
            return;
        }
        var notes = readJson('kreezbyNotifications', []);
        notes.unshift(note);
        try { localStorage.setItem('kreezbyNotifications', JSON.stringify(notes)); } catch (e) { /* ignore */ }
    }

    function recordSale(productName, quantity, salesDate) {
        var block = saleBlockReason(productName);
        if (block) {
            lastSaleError = block;
            return null;
        }
        lastSaleError = '';
        var id = productId(productName);
        if (!id) return null;
        var qty = Number(quantity) || 0;
        if (!(qty > 0)) { lastSaleError = 'invalid'; return null; }
        // Never sell more than the good (not expired) pouches on hand: stock cannot go negative.
        var sellable = sellableStock(productName);
        if (qty > sellable) {
            lastSaleError = 'insufficient';
            lastSaleShort = { product: productName, wanted: qty, available: sellable };
            return null;
        }
        var saved = savedState();
        var extra = saved.sales_transactions_extra || [];
        extra.push({
            sales_date: salesDate || FORECAST_DATE,
            product_id: id,
            quantity_sold: qty
        });
        saved.sales_transactions_extra = extra;
        var stock = productStockMap();
        stock[id] = (Number(stock[id]) || 0) - qty;
        saved.product_stock = stock;
        var moves = saved.inventory_transactions_extra || [];
        moves.push({
            type: 'stock-out',
            reference_id: id,
            quantity: qty,
            date: new Date().toISOString(),
            by: movementActor(),
            note: 'Finished goods sold on ' + (salesDate || FORECAST_DATE)
        });
        saved.inventory_transactions_extra = moves;
        writeState(saved);
        snapshot();
        paintStockCells();
        notifyStocks();
        return stock[id];
    }

    // Retailer deliveries (POS > Retailer Delivery): pouches delivered or given as replacements
    // leave the finished-product stock. A positive quantity takes stock out; a negative one puts
    // it back (a saved delivery that was corrected). Not counted as a sale here: retailer sales
    // are counted from the route sheets (COD on delivery, consignment when collected).
    function recordDeliveryStock(productName, quantity, note) {
        lastStockError = '';
        var id = productId(productName);
        if (!id) { lastStockError = 'Unknown product.'; return null; }
        var qty = Number(quantity) || 0;
        if (!qty) return Number(productStockMap()[id]) || 0;
        var saved = savedState();
        var stock = productStockMap();
        var before = Number(stock[id]) || 0;
        var after = Math.max(0, before - qty);
        stock[id] = after;
        saved.product_stock = stock;
        var moves = saved.inventory_transactions_extra || [];
        moves.push({
            type: qty > 0 ? 'stock-out' : 'stock-in',
            reference_id: id,
            quantity: Math.abs(qty),
            before: before,
            after: after,
            date: new Date().toISOString(),
            by: movementActor(),
            note: String(note || (qty > 0 ? 'Delivered to retailers' : 'Returned: retailer delivery corrected'))
        });
        saved.inventory_transactions_extra = moves;
        writeState(saved);
        snapshot();
        paintStockCells();
        notifyStocks();
        return after;
    }

    // Pouches pulled out from retailer shops (unsold or expired) come back to the bakeshop but are
    // NOT returned to sellable stock (they are old). They are only logged, so every retailer
    // movement can be traced: delivered / replaced = stock out, pulled out = logged return.
    function recordRetailerReturn(productName, pulled, expired, note) {
        var id = productId(productName);
        var qty = Number(pulled) || 0;
        if (!id || !qty) return null;
        var saved = savedState();
        var onHand = Number(productStockMap()[id]) || 0;
        var moves = saved.inventory_transactions_extra || [];
        moves.push({
            type: 'retailer-return',
            reference_id: id,
            quantity: Math.abs(qty),
            before: onHand,
            after: onHand,
            date: new Date().toISOString(),
            by: movementActor(),
            note: String(note || '') + (Number(expired) ? ' (' + Number(expired) + ' expired)' : '')
        });
        saved.inventory_transactions_extra = moves;
        writeState(saved);
        return onHand;
    }

    function undoSale(productName, quantity, salesDate) {
        var id = productId(productName);
        if (!id) return null;
        var qty = Number(quantity) || 0;
        if (!qty) return null;
        var saved = savedState();
        var extra = saved.sales_transactions_extra || [];
        var date = salesDate || '';
        for (var i = extra.length - 1; i >= 0; i--) {
            var row = extra[i];
            if (!row || row.product_id !== id || Number(row.quantity_sold) !== qty) continue;
            if (date && row.sales_date !== date) continue;
            extra.splice(i, 1);
            break;
        }
        saved.sales_transactions_extra = extra;
        var stock = productStockMap();
        stock[id] = (Number(stock[id]) || 0) + qty;
        saved.product_stock = stock;
        var moves = saved.inventory_transactions_extra || [];
        moves.push({
            type: 'stock-in',
            reference_id: id,
            quantity: qty,
            date: new Date().toISOString(),
            by: movementActor(),
            note: 'POS sale reversed on ' + (date || FORECAST_DATE)
        });
        saved.inventory_transactions_extra = moves;
        writeState(saved);
        snapshot();
        paintStockCells();
        notifyStocks();
        return stock[id];
    }

    function notifyStocks() {
        try { document.dispatchEvent(new CustomEvent('kreezby:stocks-sync')); } catch (e) { /* ignore */ }
    }

    // Stocks are add-only: a count can no longer be typed over or lowered by hand.
    // New stock goes in through addProductBatch(); sales still deduct automatically.
    var lastStockError = '';
    function setProductStock(productName, quantity) {
        lastStockError = 'Stock can only be added (Add stock), not changed or deleted.';
        return null;
    }

    function todayIso() {
        var d = new Date();
        return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    }

    function productBatchRecords(id) {
        return (savedState().product_batches || []).filter(function (b) {
            return b && b.product_id === id;
        }).sort(function (a, b) {
            return String(a.added_at || '').localeCompare(String(b.added_at || ''));
        });
    }

    // Adds a new batch of a finished product. Stock only goes up here: the batch quantity is
    // added to what is on hand, and the batch keeps its own produced and expiry dates.
    function addProductBatch(productName, fields) {
        lastStockError = '';
        fields = fields || {};
        var id = productId(productName);
        if (!id) { lastStockError = 'Choose a product.'; return null; }
        var qty = Number(fields.quantity);
        if (!(qty > 0) || Math.floor(qty) !== qty) { lastStockError = 'Enter how many pouches to add (a whole number above 0).'; return null; }
        var produced = String(fields.production_date || '').trim();
        var expires = String(fields.expiration_date || '').trim();
        if (!/^\d{4}-\d{2}-\d{2}$/.test(produced)) { lastStockError = 'Enter the produced date.'; return null; }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(expires)) { lastStockError = 'Enter the expiry date.'; return null; }
        if (produced > todayIso()) { lastStockError = 'The produced date cannot be in the future.'; return null; }
        if (expires <= produced) { lastStockError = 'The expiry date must be after the produced date.'; return null; }
        var batchNumber = String(fields.batch_number || '').trim()
            || ('BCH-' + produced.replace(/-/g, '') + '-' + (id.split('-')[1] || id));
        var clash = productBatchRecords(id).some(function (b) {
            return String(b.batch_number).toLowerCase() === batchNumber.toLowerCase();
        });
        if (clash) { lastStockError = 'Batch ' + batchNumber + ' was already added for this product. Use a new batch number.'; return null; }

        // Each pouch produced uses one stand up pouch and one sticker of its flavor.
        lastPackagingUsed = '';
        var packagingNeeded = fields.use_packaging ? packagingForProduct(productName) : [];
        if (packagingNeeded.length) {
            var onHand = materialStockMap();
            var short = packagingNeeded.filter(function (m) { return (Number(onHand[m.material_id]) || 0) < qty; });
            if (short.length) {
                lastStockError = 'Not enough packaging for ' + qty + ' pouches: ' + short.map(function (m) {
                    return m.name + ' has ' + (Number(onHand[m.material_id]) || 0);
                }).join(', ') + '. Add packaging stock first, or untick "Take packaging from stock".';
                return null;
            }
        }

        // Stock already on hand that has no batch record yet keeps its own produced and expiry
        // dates as an "old stock" batch, so adding the new batch never merges or hides it.
        var existing = productBatches(productName);
        var openingBatch = null;
        if (existing.earlier > 0) {
            var current = null;
            mergedProducts().forEach(function (p) { if (p.product_id === id) current = p; });
            current = current || {};
            var openingNumber = String(current.batch_number || '').trim() || ('BCH-OLD-' + (id.split('-')[1] || id));
            if (openingNumber.toLowerCase() === batchNumber.toLowerCase()) openingNumber += '-OLD';
            openingBatch = {
                batch_id: id + '-old-' + Date.now(),
                product_id: id,
                product_name: productName,
                batch_number: openingNumber,
                production_date: String(current.production_date || ''),
                expiration_date: String(current.expiration_date || ''),
                quantity: existing.earlier,
                // Sorts before every batch added later.
                added_at: '0000-01-01T00:00:00.000Z',
                added_by: '',
                opening: true
            };
        }

        var saved = savedState();
        var stock = productStockMap();
        var before = Number(stock[id]) || 0;
        var after = before + qty;
        stock[id] = after;
        saved.product_stock = stock;
        var batches = saved.product_batches || [];
        if (openingBatch) batches.push(openingBatch);
        batches.push({
            batch_id: id + '-' + Date.now(),
            product_id: id,
            product_name: productName,
            batch_number: batchNumber,
            production_date: produced,
            expiration_date: expires,
            quantity: qty,
            added_at: new Date().toISOString(),
            added_by: movementActor()
        });
        saved.product_batches = batches;
        // The product record shows the newest batch's details.
        var edits = saved.product_edits || {};
        var inCatalog = PRODUCTS.some(function (product) { return product.product_id === id; });
        if (inCatalog) {
            edits[id] = Object.assign({}, edits[id] || {}, { batch_number: batchNumber, production_date: produced, expiration_date: expires });
            saved.product_edits = edits;
        } else {
            var extra = saved.products_extra || [];
            var found = null;
            extra.forEach(function (item) { if (item.product_id === id) found = item; });
            if (!found) {
                found = { product_id: id, product_name: productName, expiry_threshold_days: 3, quantities: [] };
                extra.push(found);
            }
            found.batch_number = batchNumber;
            found.production_date = produced;
            found.expiration_date = expires;
            saved.products_extra = extra;
        }
        var moves = saved.inventory_transactions_extra || [];
        moves.push({
            type: 'stock-in',
            reference_id: id,
            quantity: qty,
            before: before,
            after: after,
            date: new Date().toISOString(),
            by: movementActor(),
            note: 'Batch ' + batchNumber + ' added (produced ' + produced + ', expires ' + expires + ')'
        });
        saved.inventory_transactions_extra = moves;
        writeState(saved);
        packagingNeeded.forEach(function (m) {
            recordMaterialMovement(m.name, 'usage', qty, 'Used for batch ' + batchNumber + ' (' + productName + ')', 'packaging');
        });
        lastPackagingUsed = packagingNeeded.map(function (m) { return qty + ' ' + m.name; }).join(', ');
        snapshot();
        paintStockCells();
        notifyStocks();
        return after;
    }

    var lastPackagingUsed = '';

    // Packaging one pouch of this product uses: the stand up pouch and the flavor's sticker.
    function packagingForProduct(productName) {
        var list = [];
        var pouch = materialByName('Stand up pouch');
        if (pouch) list.push(pouch);
        var flavor = String(productName || '').replace(/\s*crinkles\s*$/i, '').trim();
        var sticker = flavor ? materialByName('Stickers (' + flavor + ')') : null;
        if (sticker) list.push(sticker);
        return list;
    }

    // Splits what is on hand into batches, newest first kept apart from older stock.
    // Sales take the oldest GOOD stock first (first-expiry, first-out), so the pouches still on
    // hand belong to the newest batches. Once a batch passes its expiry date, the pouches it still
    // has are frozen (saved as frozen_remaining): they stay counted as expired stock until they are
    // disposed of, and no sale can take them.
    function batchExpired(b) {
        var days = daysUntil(b && b.expiration_date);
        return days != null && days < 0;
    }

    function productBatches(productName) {
        var id = productId(productName);
        if (!id) return { batches: [], earlier: 0, onHand: 0, expired: 0, sellable: 0 };
        var onHand = Number(productStockMap()[id]) || 0;
        var records = productBatchRecords(id);
        var frozen = 0;
        records.forEach(function (r) {
            if (r.frozen_remaining != null && !r.disposed) frozen += Number(r.frozen_remaining) || 0;
        });
        frozen = Math.min(frozen, onHand);
        var left = onHand - frozen;
        var out = [];
        var newlyFrozen = [];
        for (var i = records.length - 1; i >= 0; i--) {
            var r = records[i];
            var rem;
            if (r.frozen_remaining != null) {
                rem = r.disposed ? 0 : Math.min(Number(r.frozen_remaining) || 0, frozen);
                frozen -= rem;
            } else {
                rem = Math.min(left, Number(r.quantity) || 0);
                left -= rem;
                if (rem > 0 && batchExpired(r)) newlyFrozen.push({ batch_id: r.batch_id, qty: rem });
            }
            out.unshift(Object.assign({}, r, { remaining: rem, is_new: i === records.length - 1, expired: batchExpired(r) && rem > 0 }));
        }
        if (newlyFrozen.length) freezeBatches(newlyFrozen);
        var expiredQty = out.reduce(function (sum, b) { return sum + (b.expired ? b.remaining : 0); }, 0);
        return { batches: out, earlier: left, onHand: onHand, expired: expiredQty, sellable: Math.max(0, onHand - expiredQty) };
    }

    // Saves how many pouches each newly expired batch still had, so later sales cannot take them.
    function freezeBatches(list) {
        var saved = savedState();
        var batches = saved.product_batches || [];
        var changed = false;
        list.forEach(function (item) {
            batches.forEach(function (b) {
                if (b && b.batch_id === item.batch_id && b.frozen_remaining == null) {
                    b.frozen_remaining = item.qty;
                    b.frozen_at = new Date().toISOString();
                    changed = true;
                }
            });
        });
        if (changed) { saved.product_batches = batches; writeState(saved); }
    }

    // Pouches that may be sold now: on hand minus expired pouches waiting to be disposed of.
    function sellableStock(productName) {
        var id = productId(productName);
        if (!id) return 0;
        return productBatches(productName).sellable;
    }

    // Head admin / admin: take an expired batch's pouches out of stock (recorded as waste).
    function disposeExpiredBatch(batchId, reason) {
        lastStockError = '';
        if (!canEditPrice()) { lastStockError = 'Only head admin and admin can dispose of expired stock.'; return null; }
        var saved = savedState();
        var batches = saved.product_batches || [];
        var batch = batches.filter(function (b) { return b && b.batch_id === batchId; })[0];
        if (!batch) { lastStockError = 'Batch not found.'; return null; }
        if (!batchExpired(batch)) { lastStockError = 'Only an expired batch can be disposed of.'; return null; }
        var product = productById(batch.product_id);
        var split = productBatches(product ? product.product_name : '');
        var row = split.batches.filter(function (b) { return b.batch_id === batchId; })[0];
        var qty = row ? row.remaining : 0;
        if (!(qty > 0)) { lastStockError = 'This batch has no pouches left.'; return null; }
        saved = savedState();
        batches = saved.product_batches || [];
        batches.forEach(function (b) {
            if (b && b.batch_id === batchId) { b.disposed = true; b.disposed_at = new Date().toISOString(); b.disposed_qty = qty; b.disposed_by = movementActor(); }
        });
        saved.product_batches = batches;
        var stock = productStockMap();
        stock[batch.product_id] = Math.max(0, (Number(stock[batch.product_id]) || 0) - qty);
        saved.product_stock = stock;
        var moves = saved.inventory_transactions_extra || [];
        moves.push({
            type: 'waste',
            reference_id: batch.product_id,
            quantity: qty,
            date: new Date().toISOString(),
            by: movementActor(),
            note: 'Expired batch ' + (batch.batch_number || '') + ' disposed (expired ' + (batch.expiration_date || '') + ')' + (reason ? ': ' + String(reason).slice(0, 120) : '')
        });
        saved.inventory_transactions_extra = moves;
        writeState(saved);
        snapshot();
        paintStockCells();
        notifyStocks();
        return qty;
    }

    // Retailer price per pouch: one price for every retailer and flavor (₱140 unless head admin /
    // admin saved another). It is kept apart from the customer price (₱165 / ₱200).
    var DEFAULT_RETAILER_PRICE = 140;
    function retailerPrice() {
        var saved = Number(savedState().retailer_price);
        return saved > 0 ? saved : DEFAULT_RETAILER_PRICE;
    }

    function setRetailerPrice(value) {
        lastStockError = '';
        if (!canEditPrice()) { lastStockError = 'Only head admin and admin can change the retailer price.'; return null; }
        var price = Math.round(Number(value) * 100) / 100;
        if (!(price > 0)) { lastStockError = 'Enter a retailer price above ₱0.'; return null; }
        var before = retailerPrice();
        if (price === before) return price;
        var saved = savedState();
        saved.retailer_price = price;
        writeState(saved);
        // Retailers are told; customers are not (their price is separate).
        var note = {
            id: 'partner-retailer-price-' + Date.now(),
            title: 'Retailer price update',
            description: 'The retailer price is now ₱' + price.toFixed(2) + ' per pouch.',
            source: 'retailer_price',
            audiences: ['retailer'],
            timestamp: new Date().toISOString(),
            read: false
        };
        if (window.KreezbyNotifications && typeof window.KreezbyNotifications.push === 'function') {
            window.KreezbyNotifications.push(note);
        } else {
            var notes = readJson('kreezbyNotifications', []);
            notes.unshift(note);
            try { localStorage.setItem('kreezbyNotifications', JSON.stringify(notes)); } catch (e) { /* ignore */ }
        }
        notifyStocks();
        return price;
    }

    // Every product the shop sells (Maintenance > Item List), with its current selling price.
    function productCatalog() {
        var seen = {};
        var list = [];
        var prices = savedState().product_prices || {};
        FLAVOR_CHOICES.concat(mergedProducts().map(function (p) { return p.product_name; })).forEach(function (name) {
            var id = productId(name);
            if (!id || seen[id]) return;
            seen[id] = true;
            list.push({ id: id, name: name, packaging: 'Pouch', price: prices[id] == null ? defaultPrice(id) : Number(prices[id]) });
        });
        return list;
    }

    var lastMovementError = '';
    var MOVEMENT_KINDS = {
        'stock-in': 'Stock in',
        'stock-out': 'Stock out',
        'usage': 'Used in production',
        'waste': 'Spoiled / waste',
        'retailer-return': 'Pulled out from retailer (not resold)'
    };

    function movementActor() {
        try {
            var sess = JSON.parse(localStorage.getItem('kreezby_session') || 'null') || {};
            // The signed-in account's own name (set at login), never a role word.
            return String(sess.userName || sess.name || sess.fullName || sess.username || sess.identity || sess.email || 'Unknown account');
        } catch (e) { return 'Staff'; }
    }

    // Records a raw material movement in the ledger (date, who, balance before and after).
    function recordMaterialMovement(materialName, movementType, quantity, note, materialKind, unitCost) {
        lastMovementError = '';
        var costText = unitCost == null ? '' : String(unitCost).trim();
        var costValue = costText === '' ? null : Number(costText);
        if (costValue != null && (!isFinite(costValue) || costValue < 0)) { lastMovementError = 'Enter a cost of 0 or more.'; return null; }
        var kind = String(movementType || '').toLowerCase();
        if (!MOVEMENT_KINDS[kind] || kind === 'retailer-return') { lastMovementError = 'Choose a movement type.'; return null; }
        // Stock is never edited or deleted: it comes in (stock in) and raw/packaging materials go
        // out when used in production (recorded by Inventory > Production) or as waste / spoiled,
        // which always needs a reason.
        if (kind !== 'stock-in' && kind !== 'usage' && kind !== 'waste') { lastMovementError = 'Materials can only be added (stock in), used in production, or taken out as waste / spoiled.'; return null; }
        if (kind === 'waste' && String(note || '').trim().length < 3) { lastMovementError = 'Type the reason for the waste / spoiled stock (e.g. "flour got wet").'; return null; }
        if (kind === 'usage' || kind === 'waste') costValue = null;
        var qty = Math.abs(Number(quantity) || 0);
        if (!qty) { lastMovementError = 'Enter a quantity greater than zero.'; return null; }
        var material = ensureMaterial(materialName, materialKind);
        if (!material) { lastMovementError = 'Type a material name.'; return null; }
        var saved = savedState();
        var stock = materialStockMap();
        var current = Number(stock[material.material_id]) || 0;
        if (kind !== 'stock-in' && qty > current) {
            lastMovementError = material.name + ' only has ' + current + ' on hand, so ' + qty + ' cannot be taken out.';
            return null;
        }
        var after = kind === 'stock-in' ? current + qty : current - qty;
        var savedCost = costValue == null ? null : saveMaterialUnitCost(material.material_id, current, qty, costValue);
        stock[material.material_id] = after;
        saved.material_stock = stock;
        var moves = saved.inventory_transactions_extra || [];
        var text = String(note || '').trim();
        moves.push({
            type: kind,
            reference_id: material.material_id,
            material: material.name,
            quantity: qty,
            before: current,
            after: after,
            date: new Date().toISOString(),
            by: movementActor(),
            unit_cost: costValue == null ? undefined : costValue,
            value: costValue == null ? undefined : Math.round(costValue * qty * 100) / 100,
            note: (text || (material.name + ' ' + (MOVEMENT_KINDS[kind] || kind).toLowerCase()))
                + (costValue == null ? '' : ' · ₱' + costValue.toFixed(2) + ' each (₱' + (costValue * qty).toFixed(2) + ')')
        });
        lastMovementCost = savedCost;
        saved.inventory_transactions_extra = moves;
        writeState(saved);
        snapshot();
        paintStockCells();
        notifyStocks();
        return after;
    }

    var lastMovementCost = null;

    // Every raw material movement, newest first.
    function materialMovements() {
        var names = {};
        allMaterials().forEach(function (m) { names[m.material_id] = m.name; });
        var baseCount = BASE_MOVEMENTS.length;
        return inventoryTransactions().map(function (row, index) {
            return { row: row, index: index };
        }).filter(function (entry) {
            return names[entry.row.reference_id] != null;
        }).map(function (entry) {
            var r = entry.row;
            return {
                date: r.date || '',
                material: names[r.reference_id],
                code: r.reference_id,
                type: r.type,
                quantity: Number(r.quantity) || 0,
                before: r.before,
                after: r.after,
                by: r.by || '',
                note: r.note || '',
                order: entry.index
            };
        }).sort(function (a, b) {
            if (a.date && b.date) return a.date < b.date ? 1 : -1;
            if (a.date) return -1;
            if (b.date) return 1;
            return b.order - a.order;
        });
    }

    function formatMoveDate(iso) {
        if (!iso) return '—';
        var d = new Date(iso);
        if (isNaN(d.getTime())) return '—';
        return d.toLocaleString('en-PH', { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
    }

    function ensureLedgerStyles() {
        if (document.getElementById('kreezby-ledger-style')) return;
        var style = document.createElement('style');
        style.id = 'kreezby-ledger-style';
        style.textContent = ''
            + '#kreezby-fr-ledger{margin-top:16px;padding:16px 18px;background:#fff;border:1px solid #efe7e0;border-radius:16px;box-shadow:0 6px 18px rgba(93,64,55,.06);}'
            + '#kreezby-fr-ledger h3{margin:0 0 4px;font-size:16px;color:#3d2c2a;}'
            + '#kreezby-fr-ledger .rl-lead{margin:0 0 12px;color:#7a655c;font-size:13px;}'
            + '#kreezby-fr-ledger .rl-bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:12px;}'
            + '#kreezby-fr-ledger select,#kreezby-fr-ledger button{height:34px;border:1px solid #e4d9d0;border-radius:10px;background:#fff;color:#3d2c2a;font:inherit;font-size:13px;padding:0 10px;}'
            + '#kreezby-fr-ledger button{background:#ffca28;border-color:#ffca28;font-weight:800;cursor:pointer;}'
            + '#kreezby-fr-ledger .rl-chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;}'
            + '#kreezby-fr-ledger .rl-chip{padding:6px 12px;border-radius:999px;background:#f7f0ea;color:#5d4037;font-size:12px;font-weight:700;}'
            + '#kreezby-fr-ledger .rl-scroll{max-height:380px;overflow:auto;border:1px solid #f3ece6;border-radius:12px;}'
            + '#kreezby-fr-ledger table{width:100%;border-collapse:collapse;font-size:13px;}'
            + '#kreezby-fr-ledger th{position:sticky;top:0;background:#f7f0ea;color:#6d4c41;text-align:left;font-size:11px;letter-spacing:.05em;text-transform:uppercase;padding:9px 10px;}'
            + '#kreezby-fr-ledger td{padding:9px 10px;border-top:1px solid #f3ece6;color:#3d2c2a;vertical-align:top;}'
            + '#kreezby-fr-ledger td.rl-in{color:#2e7d32;font-weight:800;white-space:nowrap;}'
            + '#kreezby-fr-ledger td.rl-out{color:#c62828;font-weight:800;white-space:nowrap;}'
            + '#kreezby-fr-ledger .rl-empty{padding:18px;text-align:center;color:#7a655c;}';
        document.head.appendChild(style);
    }

    function moveSign(type, qty) {
        if (type === 'stock-in') return { cls: 'rl-in', text: '+' + qty };
        if (type === 'retailer-return') return { cls: '', text: '0 (' + qty + ' back, not resold)' };
        if (type === 'adjustment') return { cls: qty < 0 ? 'rl-out' : 'rl-in', text: (qty > 0 ? '+' : '') + qty };
        return { cls: 'rl-out', text: '−' + qty };
    }

    function renderLedger() {
        var box = document.getElementById('kreezby-fr-ledger');
        if (!box) return;
        var materialSel = box.querySelector('#rl-material');
        var typeSel = box.querySelector('#rl-type');
        var wantMaterial = materialSel ? materialSel.value : '';
        var wantType = typeSel ? typeSel.value : '';
        var all = materialMovements();
        var rows = all.filter(function (m) {
            return (!wantMaterial || m.code === wantMaterial) && (!wantType || m.type === wantType);
        });
        var totals = { 'stock-in': 0, usage: 0, 'stock-out': 0, waste: 0 };
        rows.forEach(function (m) { if (totals[m.type] != null) totals[m.type] += m.quantity; });
        var options = '<option value="">All materials</option>' + allMaterials().map(function (m) {
            return '<option value="' + esc(m.material_id) + '"' + (m.material_id === wantMaterial ? ' selected' : '') + '>' + esc(m.name) + '</option>';
        }).join('');
        var typeOptions = '<option value="">All movements</option>' + Object.keys(MOVEMENT_KINDS).concat(['adjustment']).map(function (k) {
            return '<option value="' + k + '"' + (k === wantType ? ' selected' : '') + '>' + esc(MOVEMENT_KINDS[k] || 'Adjustment') + '</option>';
        }).join('');
        var body = rows.length ? rows.slice(0, 200).map(function (m) {
            var sign = moveSign(m.type, m.quantity);
            return '<tr><td>' + esc(formatMoveDate(m.date)) + '</td><td>' + esc(m.material) + '</td><td>' + esc(MOVEMENT_KINDS[m.type] || (m.type === 'adjustment' ? 'Adjustment' : m.type)) + '</td>'
                + '<td class="' + sign.cls + '">' + esc(sign.text) + '</td>'
                + '<td>' + (m.before != null ? esc(m.before) + ' → ' + esc(m.after) : '—') + '</td>'
                + '<td>' + esc(m.by || '—') + '</td><td>' + esc(m.note) + '</td></tr>';
        }).join('') : '<tr><td colspan="7" class="rl-empty">No raw material movements recorded yet. Use “Record movement” above.</td></tr>';
        box.innerHTML = '<h3>Raw Material Movement Log</h3>'
            + '<p class="rl-lead">Every stock-in, stock-out, usage and waste entry, with who recorded it and the balance before and after.</p>'
            + '<div class="rl-bar"><select id="rl-material" aria-label="Filter by raw material">' + options + '</select>'
            + '<select id="rl-type" aria-label="Filter by movement">' + typeOptions + '</select>'
            + '<button type="button" id="rl-export">Export CSV</button></div>'
            + '<div class="rl-chips"><span class="rl-chip">Entries: ' + rows.length + '</span>'
            + '<span class="rl-chip">Stock in: ' + totals['stock-in'] + '</span>'
            + '<span class="rl-chip">Used: ' + totals.usage + '</span>'
            + '<span class="rl-chip">Stock out: ' + totals['stock-out'] + '</span>'
            + '<span class="rl-chip">Waste: ' + totals.waste + '</span></div>'
            + '<div class="rl-scroll"><table><thead><tr><th>Date</th><th>Raw material</th><th>Movement</th><th>Qty</th><th>Balance</th><th>Recorded by</th><th>Note</th></tr></thead><tbody>' + body + '</tbody></table></div>';
        box.querySelector('#rl-material').addEventListener('change', renderLedger);
        box.querySelector('#rl-type').addEventListener('change', renderLedger);
        box.querySelector('#rl-export').addEventListener('click', function () {
            var lines = [['Date', 'Raw material', 'Movement', 'Quantity', 'Balance before', 'Balance after', 'Recorded by', 'Note']];
            rows.forEach(function (m) {
                lines.push([m.date, m.material, m.type, m.quantity, m.before == null ? '' : m.before, m.after == null ? '' : m.after, m.by, m.note]);
            });
            var csv = lines.map(function (r) {
                return r.map(function (c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(',');
            }).join('\r\n');
            var a = document.createElement('a');
            a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
            a.download = 'raw-material-movements.csv';
            document.body.appendChild(a);
            a.click();
            setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
        });
    }

    function mountLedger() {
        // The Products/Stocks page shows stocks only; the raw material movement log is not shown.
        var old = document.getElementById('kreezby-fr-ledger');
        if (old) old.remove();
        return;
        // eslint-disable-next-line no-unreachable
        var table = document.getElementById('stocks-table-body');
        if (!table) return;
        if (document.getElementById('kreezby-fr-ledger')) { renderLedger(); return; }
        var card = table.closest('.panel-data-card');
        if (!card) return;
        ensureLedgerStyles();
        var box = document.createElement('section');
        box.id = 'kreezby-fr-ledger';
        card.insertAdjacentElement('afterend', box);
        renderLedger();
    }

    function saveProductFields(productName, fields) {
        var id = productId(productName);
        if (!id) return null;
        var saved = savedState();
        var inCatalog = PRODUCTS.some(function (product) { return product.product_id === id; });
        var isNewFlavor = false;
        // A price-only change (Inventory > Edit) never registers the flavor as new.
        var priceOnly = !!fields && ['batch_number', 'production_date', 'expiration_date', 'current_stock'].every(function (key) {
            return fields[key] == null || String(fields[key]) === '';
        });
        if (priceOnly) {
            // nothing to record but the price below
        } else if (!inCatalog) {
            var extra = saved.products_extra || [];
            var found = null;
            extra.forEach(function (item) {
                if (item.product_id === id) found = item;
            });
            if (!found) {
                found = { product_id: id, product_name: productName, expiry_threshold_days: 3, quantities: [] };
                extra.push(found);
                isNewFlavor = true;
            }
            ['batch_number', 'production_date', 'expiration_date'].forEach(function (key) {
                if (fields && fields[key]) found[key] = String(fields[key]);
            });
            saved.products_extra = extra;
        } else {
            var edits = saved.product_edits || {};
            var current = edits[id] || {};
            ['batch_number', 'production_date', 'expiration_date'].forEach(function (key) {
                if (fields && fields[key]) current[key] = String(fields[key]);
            });
            edits[id] = current;
            saved.product_edits = edits;
        }
        var priceNotice = '';
        if (fields && fields.price != null && String(fields.price) !== '') {
            var price = Number(fields.price);
            if (Number.isFinite(price) && price >= 0) {
                var prices = saved.product_prices || {};
                var previousPrice = prices[id] == null ? defaultPrice(id) : Number(prices[id]);
                if (Number(previousPrice) !== price) {
                    prices[id] = price;
                    saved.product_prices = prices;
                    priceNotice = productName + ' price is now ₱' + price.toFixed(2) + '.';
                }
            }
        }
        writeState(saved);
        snapshot();
        notifyStocks();
        if (isNewFlavor) pushPartnerNotice('new_product', productName, productName + ' is a newly released flavor.');
        if (priceNotice) pushPartnerNotice('price_change', productName, priceNotice);
        return productById(id);
    }

    function historyFor(name) {
        var id = productId(name);
        var material = materialByName(name);
        var ref = id || (material && material.material_id) || '';
        if (!ref) return [];
        return inventoryTransactions().filter(function (row) {
            return row.reference_id === ref;
        });
    }

    function esc(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function decorateStocks() {
        if (document.getElementById('stocks-master-list-panel-view')) return;
        document.querySelectorAll('tr.stock-row').forEach(function (row) {
            if (row.querySelector('.dict-fields')) return;
            var cells = row.querySelectorAll('td');
            var nameCell = null;
            var name = '';
            for (var i = 0; i < cells.length; i++) {
                var text = cellLabel(cells[i]);
                if (productId(text) || materialByName(text)) {
                    nameCell = cells[i];
                    name = text;
                    break;
                }
            }
            if (!nameCell) return;
            var product = null;
            mergedProducts().forEach(function (item) {
                if (item.product_name === name) product = item;
            });
            var material = materialByName(name);
            var html = '';
            var producedCell = row.querySelector('.dict-produced');
            var expiresCell = row.querySelector('.dict-expires');
            if (productId(name)) {
                // New stock and older stock are listed apart, each batch with its own dates.
                var split = productBatches(name);
                var lines = [];
                var made = [];
                var exp = [];
                split.batches.slice().reverse().forEach(function (b) {
                    if (!(b.remaining > 0)) return;
                    var tag = b.is_new ? 'New stock' : 'Old stock';
                    lines.push('<strong>' + tag + '</strong> · Batch ' + esc(b.batch_number) + ': ' + b.remaining + ' pcs');
                    made.push(tag + ': ' + esc(b.production_date));
                    exp.push(tag + ': ' + esc(b.expiration_date));
                });
                if (split.earlier > 0) {
                    lines.push('<strong>Old stock</strong> · added before batches: ' + split.earlier + ' pcs');
                    made.push('Old stock: —');
                    exp.push('Old stock: —');
                }
                html = lines.join('<br>');
                if (producedCell) producedCell.innerHTML = made.length ? made.join('<br>') : '—';
                if (expiresCell) expiresCell.innerHTML = exp.length ? exp.join('<br>') : '—';
            } else if (product) {
                html = 'Batch ' + esc(product.batch_number) +
                    '<br>Produced ' + esc(product.production_date) +
                    '<br>Expires ' + esc(product.expiration_date) +
                    '<br>Expiry alert: ' + esc(product.expiry_threshold_days) + ' days';
            } else if (material) {
                if (expiresCell) expiresCell.textContent = material.expiration_date || '—';
                html = 'Expires ' + esc(material.expiration_date) +
                    '<br>Expiry alert: ' + esc(material.expiry_threshold_days) + ' days';
            }
            if (!html) return;
            var note = document.createElement('div');
            note.className = 'dict-fields';
            note.style.cssText = 'font-size:12px;color:#5d4037;margin-top:4px;line-height:1.45;font-weight:500;';
            note.innerHTML = html;
            nameCell.appendChild(note);
        });
    }

    function alertMatch(message) {
        var text = String(message || '').toLowerCase();
        if (text.indexOf('mango') >= 0 && text.indexOf('threshold') >= 0) return alerts()[0];
        if (text.indexOf('lemon') >= 0) return alerts()[1];
        return null;
    }

    function decorateAlerts() {
        var tables = document.querySelectorAll('table');
        tables.forEach(function (table) {
            var head = (table.querySelector('thead') || {}).textContent || '';
            if (head.indexOf('Alert Message') < 0) return;
            var body = table.querySelector('tbody');
            if (!body || body.querySelector('.dict-alert')) return;
            Array.prototype.forEach.call(body.rows, function (row) {
                var cells = row.cells;
                if (!cells || cells.length < 4) return;
                var message = (cells[3].textContent || '').trim();
                var match = alertMatch(message);
                if (!match) return;
                var note = document.createElement('div');
                note.className = 'dict-alert';
                note.style.cssText = 'font-size:12px;color:#5d4037;margin-top:4px;line-height:1.45;';
                note.textContent = match.alert_type + ' · ' + match.target_role + ' · ' + match.reference_id + ' · ' + match.status;
                cells[3].appendChild(note);
            });
            if (table.id === 'alert-table') {
                if (window.AlertAdmin && window.AlertAdmin.filter) window.AlertAdmin.filter();
                return;
            }
            alerts().forEach(function (alert) {
                if (body.textContent.indexOf(alert.alert_type) >= 0 && body.textContent.indexOf(alert.reference_id) >= 0) return;
                var row = document.createElement('tr');
                row.innerHTML = '<td>' + (body.rows.length + 1) + '</td><td>' + esc(FORECAST_DATE) + '</td><td><strong>' + esc(alert.reference_id) + '</strong></td><td>' + esc(alert.message) + '<div class="dict-alert" style="font-size:12px;color:#5d4037;margin-top:4px;">' + esc(alert.alert_type) + ' · ' + esc(alert.target_role) + ' · ' + esc(alert.reference_id) + ' · ' + esc(alert.status) + '</div></td><td style="text-align:center;">' + esc(alert.status) + '</td><td></td>';
                var actionCell = row.cells[row.cells.length - 1];
                var button = document.createElement('button');
                button.type = 'button';
                button.textContent = alert.status === 'resolved' ? 'Resolved' : 'Acknowledge';
                button.style.cssText = 'border:0;border-radius:999px;padding:6px 10px;background:#5d4037;color:#fff;font-weight:700;cursor:pointer;';
                button.addEventListener('click', function () {
                    var saved = savedState();
                    var statuses = saved.alert_status || {};
                    statuses[alert.alert_type + ':' + alert.reference_id] = 'acknowledged';
                    saved.alert_status = statuses;
                    writeState(saved);
                    if (row.cells[4]) row.cells[4].textContent = 'acknowledged';
                    button.textContent = 'Acknowledged';
                });
                if (actionCell) actionCell.appendChild(button);
                body.appendChild(row);
            });
        });
    }

    function decorateSaleCards() {
        document.querySelectorAll('.account-order-card').forEach(function (card) {
            card.querySelectorAll('tbody tr').forEach(function (row) {
                if (row.querySelector('.dict-sale')) return;
                var cells = row.cells;
                if (!cells || cells.length < 2) return;
                var name = (cells[1].textContent || '').trim();
                var id = productId(name);
                if (!id) return;
                var note = document.createElement('div');
                note.className = 'dict-sale';
                note.style.cssText = 'font-size:12px;color:#5d4037;margin-top:2px;';
                note.textContent = 'product_id ' + id + ' · quantity_sold ' + (cells[0].textContent || '').trim();
                cells[1].appendChild(note);
            });
        });
    }

    function cellLabel(cell) {
        var clone = cell.cloneNode(true);
        clone.querySelectorAll('.dict-fields, .dict-alert, .dict-forecast, .dict-sale').forEach(function (node) {
            node.remove();
        });
        return (clone.textContent || '').replace(/\s+/g, ' ').trim();
    }

    function paintStockCells() {
        var products = productStockMap();
        var materials = materialStockMap();
        document.querySelectorAll('tr.stock-row').forEach(function (row) {
            var count = row.querySelector('.inventory-count-text');
            if (!count) return;
            var cells = row.querySelectorAll('td');
            var name = '';
            for (var i = 0; i < cells.length; i++) {
                var text = cellLabel(cells[i]);
                if (productId(text) || materialByName(text)) {
                    name = text;
                    break;
                }
            }
            var id = productId(name);
            if (id && products[id] != null) count.textContent = String(products[id]);
            var material = materialByName(name);
            if (material && materials[material.material_id] != null) count.textContent = String(materials[material.material_id]);
        });
    }

    function ensureForecastStyles() {
        if (document.getElementById('dict-forecast-layout')) return;
        var style = document.createElement('style');
        style.id = 'dict-forecast-layout';
        style.textContent = ''
            + '#ai-filter-pills,.ai-filter-pills{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:0 0 18px;padding:0;border:0;border-radius:0;background:transparent;box-shadow:none;overflow:visible;}'
            + '#ai-filter-pills .pill,.ai-filter-pills .pill{height:auto!important;min-height:36px;min-width:0;padding:8px 14px!important;border:1px solid #e6e7eb!important;border-radius:6px!important;background:#f3f4f6!important;color:#111827!important;font-size:13px;font-weight:700;box-shadow:none!important;gap:0!important;white-space:normal;text-align:center;line-height:1.3;}'
            + '#ai-filter-pills .pill.active,.ai-filter-pills .pill.active{background:#1e88e5!important;color:#fff!important;border-color:#1e88e5!important;}'
            + '#ai-filter-pills .expanding-tab__icon,.ai-filter-pills .expanding-tab__icon{display:none!important;}'
            + '#ai-filter-pills .expanding-tab__label,.ai-filter-pills .expanding-tab__label{display:inline!important;max-width:none!important;opacity:1!important;}'
            + '.dict-sales-window{margin:0 0 16px;padding:14px 16px;border:1px solid #eadfce;border-radius:12px;background:#fffaf3;}'
            + '.dict-sales-window__lead{margin:0 0 4px;font-size:13px;color:#5d4037;line-height:1.45;}'
            + '.dict-sales-row{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1.35fr) minmax(0,1fr) 210px;gap:8px 16px;align-items:center;padding:10px 0;border-top:1px solid #f0e6d8;font-size:13px;color:#333;line-height:1.4;}'
            + '.dict-sales-row:first-child{border-top:0;padding-top:0;}'
            + '.dict-sales-row strong{display:block;color:#1f1f1f;}'
            + '.dict-sales-id,.dict-sales-stock{display:block;color:#7a6558;font-size:12px;}'
            + '.dict-sales-k{font-weight:700;color:#5d4037;}'
            + '.dict-sales-action{display:flex;flex-direction:column;align-items:flex-end;gap:4px;width:210px;max-width:100%;}'
            + '.dict-reorder{display:inline-flex;align-items:center;justify-content:center;padding:7px 12px;border-radius:999px;background:#5d4037;color:#fff;font-weight:700;font-size:12px;text-decoration:none;white-space:nowrap;}'
            + '.dict-reorder:hover{background:#3e2723;}'
            + '@media (max-width:860px){.dict-sales-row{grid-template-columns:1fr;}.dict-sales-action{align-items:flex-start;}}';
        document.head.appendChild(style);
    }

    function stocksPageHref() {
        var path = (location.pathname || '').replace(/\\/g, '/').toLowerCase();
        if (path.indexOf('/head_admin/') >= 0) return 'stocks-headadmin.html';
        if (path.indexOf('/staff/') >= 0 || path.indexOf('/staff_names/') >= 0) return 'stocks-staff.html';
        return 'stocks-admin.html';
    }

    function hideArchivedStock() {
        var archived = [];
        try { archived = JSON.parse(localStorage.getItem('kreezby_archived_stock') || '[]'); } catch (e) { archived = []; }
        if (!archived.length) return;
        document.querySelectorAll('tr.stock-row').forEach(function (row) {
            var cells = row.querySelectorAll('td');
            for (var i = 0; i < cells.length; i++) {
                if (archived.indexOf(cellLabel(cells[i])) >= 0) row.hidden = true;
            }
        });
    }

    function canEditInventory() {
        var path = (location.pathname || '').replace(/\\/g, '/').toLowerCase();
        return path.indexOf('/admin/') >= 0 || path.indexOf('/admin_names/') >= 0
            || path.indexOf('/head_admin/') >= 0 || path.indexOf('/staff/') >= 0
            || path.indexOf('/staff_names/') >= 0;
    }

    // Shop price per pouch: ₱165 for every flavor, ₱200 for Choco Butternut, unless head admin / admin saved another.
    function defaultPrice(id) {
        return id === 'CRK-BUT-J' ? 200 : 165;
    }

    // Selling price of finished products: head admin and admin only (staff cannot change it).
    function canEditPrice() {
        var path = (location.pathname || '').replace(/\\/g, '/').toLowerCase();
        return path.indexOf('/admin/') >= 0 || path.indexOf('/admin_names/') >= 0
            || path.indexOf('/head_admin/') >= 0;
    }

    function stockFieldIcon(kind) {
        var paths = {
            product: '<circle cx="12" cy="12" r="8"/><circle cx="9" cy="10" r=".8" fill="currentColor" stroke="none"/><circle cx="14" cy="9" r=".8" fill="currentColor" stroke="none"/><circle cx="13.5" cy="14" r=".8" fill="currentColor" stroke="none"/><circle cx="10" cy="15" r=".8" fill="currentColor" stroke="none"/>',
            batch: '<path d="M20.6 13.4 11 3.8A2 2 0 0 0 9.6 3H4a1 1 0 0 0-1 1v5.6a2 2 0 0 0 .6 1.4l9.6 9.6a2 2 0 0 0 2.8 0l4.6-4.6a2 2 0 0 0 0-2.8z"/><circle cx="7.5" cy="7.5" r="1"/>',
            made: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
            expires: '<circle cx="12" cy="13" r="7"/><path d="M12 10v3.5L14.5 15M9 3h6"/>',
            stock: '<path d="m21 8-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>',
            price: '<path d="M12 2v20"/><path d="M17 6.5c0-1.5-2-2.5-5-2.5S7 5 7 7s2 2.5 5 2.5 5 1 5 2.5-2 2.5-5 2.5-5-1-5-2.5"/>',
            material: '<path d="M12 22V11"/><path d="M7 8c1.5 2 3 3.2 5 3.8C14 11.2 15.5 10 17 8c-1.4.2-2.8.8-4 2.2C11.8 8.8 10.4 8.2 9 8H7z"/><path d="M6 14c2 .8 4 .8 6 0 2 .8 4 .8 6 0"/>',
            move: '<path d="M7 7h11M15 4l3 3-3 3M17 17H6M9 14l-3 3 3 3"/>',
            qty: '<path d="M5 9h14M5 15h14M10 4l-1.5 16M16 4l-1.5 16"/>',
            note: '<path d="M5 4h14v16H5z"/><path d="M8 9h8M8 13h8"/>'
        };
        return '<span class="fr-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + (paths[kind] || '') + '</svg></span>';
    }

    function stockField(id, label, icon, control, wide) {
        return '<label class="fr-field' + (wide ? ' fr-field--wide' : '') + '">'
            + '<span class="fr-label">' + stockFieldIcon(icon) + label + '</span>'
            + control
            + '</label>';
    }

    function ensureHeadStockFormStyles() {
        if (document.getElementById('fr-head-stock-style')) return;
        var style = document.createElement('style');
        style.id = 'fr-head-stock-style';
        style.textContent = ''
            + '.fr-records{margin:0 0 16px;width:100%;min-width:0;container-type:inline-size;}'
            + '.fr-records__grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:12px;width:100%;}'
            + '.fr-card{background:#fffaf3;border:1px solid #eadfce;border-radius:12px;padding:14px 14px 12px;min-width:0;}'
            + '.fr-card__title{display:flex;align-items:center;gap:8px;margin:0 0 4px;font-size:15px;color:#3e2723;}'
            + '.fr-card__icon{width:28px;height:28px;border-radius:8px;background:#fff;border:1px solid #eadfce;display:inline-flex;align-items:center;justify-content:center;color:#5d4037;flex-shrink:0;}'
            + '.fr-card__lead{margin:0 0 12px;padding-left:36px;color:#7a6558;font-size:12px;line-height:1.4;}'
            + '.fr-fields{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;align-items:end;}'
            + '.fr-field{display:flex;flex-direction:column;gap:4px;min-width:0;font-size:12px;font-weight:700;color:#5d4037;}'
            + '.fr-field--wide{grid-column:span 2;}'
            + '.fr-label{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;}'
            + '.fr-ico{display:inline-flex;color:#8d6e63;}'
            + '.fr-ico svg{display:block;}'
            + '.fr-field input,.fr-field select{height:36px;width:100%;min-width:0;max-width:100%;box-sizing:border-box;border:1px solid #e4d8c4;border-radius:8px;padding:0 10px;background:#fff;color:#1f1f1f;font:500 13px/1.2 inherit;}'
            + '.fr-field input:focus,.fr-field select:focus{outline:none;border-color:#5d4037;box-shadow:0 0 0 3px rgba(93,64,55,.12);}'
            + '.fr-actions{display:flex;align-items:end;min-width:0;}'
            + '.fr-card--materials .fr-fields{grid-template-columns:repeat(auto-fit,minmax(140px,1fr));}'
            + '.fr-records__grid--single{grid-template-columns:minmax(0,1fr);}'
            + '.fr-group{display:contents;}'
            + '.fr-group[hidden]{display:none;}'
            + '.fr-btn{height:36px;width:100%;border:0;border-radius:8px;background:#5d4037;color:#fff;font-weight:700;font-size:13px;cursor:pointer;white-space:nowrap;}'
            + '.fr-btn:hover{background:#3e2723;}'
            + '.fr-hide-btn{margin-left:auto;height:28px;padding:0 10px;border:1px solid #c4b4a4;border-radius:8px;background:#fff;color:#5d4037;font-size:12px;font-weight:700;cursor:pointer;flex:0 0 auto;}'
            + '.fr-hide-btn:hover{background:#f6efe6;}'
            + '.fr-card.is-collapsed .fr-card__lead,.fr-card.is-collapsed .fr-fields{display:none;}'
            + '.fr-panel{margin:0 0 12px;padding:12px;border:1px solid #eadfce;border-radius:12px;background:#fffaf3;}'
            + '.fr-panel__bar{display:flex;align-items:center;gap:8px;color:#3e2723;}'
            + '.fr-panel.is-collapsed .fr-panel__body{display:none;}'
            + '.fr-panel__body{margin-top:8px;}'
            + '#fr-stock-note{margin:10px 2px 0;min-height:1.2em;color:#3e2723;font-size:13px;}'
            + '@container (max-width:860px){.fr-records__grid{grid-template-columns:minmax(0,1fr);}.fr-field--wide{grid-column:auto;}}'
            + '@media (max-width:720px){.fr-records__grid{grid-template-columns:minmax(0,1fr);}.fr-field--wide{grid-column:auto;}}';
        document.head.appendChild(style);
    }

    function hideControl(panel) {
        return '<button type="button" class="fr-hide-btn" data-fr-hide="' + panel + '" aria-expanded="true">Hide</button>';
    }

    function bindStockHide(box) {
        box.querySelectorAll('[data-fr-hide]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var panel = box.querySelector('[data-fr-panel="' + btn.getAttribute('data-fr-hide') + '"]');
                if (!panel) return;
                var collapsed = panel.classList.toggle('is-collapsed');
                btn.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
                btn.textContent = collapsed ? 'Show' : 'Hide';
            });
        });
    }

    function mountStockTools() {
        if (!canEditInventory() || document.getElementById('kreezby-fr-stock-tools')) return;
        var table = document.getElementById('stocks-table-body');
        if (!table && !document.getElementById('stocks-record-host')) return;
        var recordHost = document.getElementById('stocks-record-host');
        var host = recordHost || table.closest('.card-body-padded, .card-body, .workspace-view-canvas') || table.parentNode;
        var box = document.createElement('div');
        box.id = 'kreezby-fr-stock-tools';
        var pathName = (location.pathname || '').replace(/\\/g, '/').toLowerCase();
        var cardLayout = pathName.indexOf('/head_admin/') !== -1
            || pathName.indexOf('/admin/') !== -1
            || pathName.indexOf('/admin_names/') !== -1
            || pathName.indexOf('/staff/') !== -1;
        var productNames = cardLayout ? FLAVOR_CHOICES.slice() : [];
        if (cardLayout) {
            var seenFlavor = {};
            productNames.forEach(function (name) { seenFlavor[name] = true; });
            mergedProducts().forEach(function (product) {
                if (product.product_name && !seenFlavor[product.product_name]) {
                    seenFlavor[product.product_name] = true;
                    productNames.push(product.product_name);
                }
            });
        }
        var productOptions = (cardLayout ? productNames : mergedProducts().map(function (product) { return product.product_name; })).map(function (name) {
            return '<option value="' + esc(name) + '">' + esc(name) + '</option>';
        }).join('');
        var materialOptions = RAW_MATERIALS.map(function (item) {
            return '<option value="' + esc(item.name) + '">' + esc(item.name) + '</option>';
        }).join('');
        ensureHeadStockFormStyles();
        if (cardLayout) {
            box.className = 'fr-records';
            box.innerHTML = '<div class="fr-records__grid fr-records__grid--single">'
                + '<section class="fr-card" data-fr-panel="stock" aria-label="Add stock">'
                + '<h3 class="fr-card__title">' + '<span class="fr-card__icon">' + stockFieldIcon('product') + '</span>Add stock' + hideControl('stock') + '</h3>'
                + '<p class="fr-card__lead" id="fr-lead"></p>'
                + '<div class="fr-fields">'
                + stockField('fr-type', 'Stock type', 'move', '<select id="fr-type">'
                    + '<option value="product">Finished product</option>'
                    + '<option value="raw">Raw material</option>'
                    + '<option value="packaging">Packaging material</option>'
                    + '</select>')
                // Finished product
                + '<div class="fr-group" data-fr-group="product">'
                + stockField('fr-product', 'Product', 'product', '<select id="fr-product">' + productOptions + '</select>')
                + stockField('fr-batch', 'Batch no.', 'batch', '<input id="fr-batch" type="text" placeholder="Auto if left blank">')
                + stockField('fr-produced', 'Produced date', 'made', '<input id="fr-produced" type="date">')
                + stockField('fr-expires', 'Expiry date', 'expires', '<input id="fr-expires" type="date">')
                + stockField('fr-stock', 'Quantity to add', 'stock', '<input id="fr-stock" type="number" min="1" step="1" placeholder="0">')
                + (canEditPrice() ? stockField('fr-price', 'Price (₱ per pouch)', 'price', '<input id="fr-price" type="number" min="1" step="0.01">') : '')
                + '<label class="fr-field fr-field--wide" style="flex-direction:row;align-items:center;gap:8px;font-weight:600;"><input id="fr-use-pack" type="checkbox" checked style="width:auto;height:auto;"> Take packaging from stock (1 stand up pouch + 1 sticker of this flavor per pouch)</label>'
                + '<div class="fr-actions"><button type="button" class="fr-btn" id="fr-save-product">Add stock</button></div>'
                + '</div>'
                // Raw / packaging material
                + '<div class="fr-group" data-fr-group="material" hidden>'
                + '<label class="fr-field"><span class="fr-label">' + stockFieldIcon('material') + '<span id="fr-material-label">Raw material</span></span>'
                + '<input id="fr-material" type="text" list="fr-material-list" placeholder="Type a raw material"><datalist id="fr-material-list"></datalist></label>'
                + stockField('fr-move', 'Movement', 'move', '<select id="fr-move"><option value="stock-in">Stock in (received)</option><option value="waste">Stock out (waste / spoiled)</option></select>')
                + stockField('fr-qty', 'Quantity', 'qty', '<input id="fr-qty" type="number" min="1" value="1">')
                + stockField('fr-unit-cost', 'Cost per unit (₱)', 'price', '<input id="fr-unit-cost" type="number" min="0" step="0.01" placeholder="0.00">')
                + stockField('fr-note', 'Note', 'note', '<input id="fr-note" type="text" placeholder="Supplier, batch or reason (optional)">')
                + '<div class="fr-actions"><button type="button" class="fr-btn" id="fr-save-move">Add stock</button></div>'
                + '</div>'
                + '</div></section>'
                + '</div>'
                + '<p id="fr-stock-note"></p>';
        } else {
            box.innerHTML = '<section class="fr-panel" data-fr-panel="product">'
                + '<div class="fr-panel__bar"><strong>Finished products</strong>' + hideControl('product') + '</div>'
                + '<div class="fr-panel__body">'
                + '<p style="margin:0 0 10px;color:#5d4037;">Add a new batch with its produced and expiry dates. Stock can only be added; sales deduct finished goods automatically.</p>'
                + '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:end;">'
                + '<label>Product<br><select id="fr-product">' + productOptions + '</select></label>'
                + '<label>Batch no.<br><input id="fr-batch" type="text" placeholder="Auto if left blank"></label>'
                + '<label>Produced date<br><input id="fr-produced" type="date"></label>'
                + '<label>Expiry date<br><input id="fr-expires" type="date"></label>'
                + '<label>Quantity to add<br><input id="fr-stock" type="number" min="1" step="1" placeholder="0" style="width:90px;"></label>'
                + '<label style="align-self:center;"><input id="fr-use-pack" type="checkbox" checked> Take packaging from stock</label>'
                + (canEditPrice() ? '<label>Price (₱ per pouch)<br><input id="fr-price" type="number" min="1" step="0.01" style="width:90px;"></label>' : '')
                + '<button type="button" id="fr-save-product">Add stock</button>'
                + '</div></div></section>'
                + '<section class="fr-panel" data-fr-panel="material">'
                + '<div class="fr-panel__bar"><strong>Raw materials</strong>' + hideControl('material') + '</div>'
                + '<div class="fr-panel__body">'
                + '<p style="margin:0 0 10px;color:#5d4037;">Type any raw material, then add the quantity received.</p>'
                + '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:end;">'
                + '<label>Raw material<br><input id="fr-material" type="text" list="fr-material-list" placeholder="Type a raw material"><datalist id="fr-material-list">' + materialOptions + '</datalist></label>'
                + '<label>Movement<br><select id="fr-move"><option value="stock-in">Stock in (received)</option><option value="waste">Stock out (waste / spoiled)</option></select></label>'
                + '<label>Quantity<br><input id="fr-qty" type="number" min="1" value="1" style="width:90px;"></label>'
                + '<label>Cost per unit (₱)<br><input id="fr-unit-cost" type="number" min="0" step="0.01" placeholder="0.00" style="width:110px;"></label>'
                + '<label>Note<br><input id="fr-note" type="text" placeholder="Supplier, batch or reason"></label>'
                + '<button type="button" id="fr-save-move">Add stock</button>'
                + '</div></div></section>'
                + '<p id="fr-stock-note" style="margin:10px 0 0;"></p>';
        }
        if (recordHost) recordHost.appendChild(box);
        else host.insertBefore(box, host.firstChild);
        bindStockHide(box);

        function fillProduct() {
            var name = document.getElementById('fr-product').value;
            var pid = productId(name);
            // Every save is a new batch: the fields start empty, produced date defaults to today.
            document.getElementById('fr-batch').value = '';
            document.getElementById('fr-produced').value = todayIso();
            document.getElementById('fr-expires').value = '';
            document.getElementById('fr-stock').value = '';
            var pricePick = document.getElementById('fr-price');
            if (pricePick) {
                var savedPrices = savedState().product_prices || {};
                pricePick.value = pid ? (savedPrices[pid] == null ? defaultPrice(pid) : Number(savedPrices[pid])).toFixed(2) : '';
            }
            var note = document.getElementById('fr-stock-note');
            if (note && pid) note.textContent = name + ' on hand now: ' + (Number(productStockMap()[pid]) || 0) + ' pouches.';
        }
        document.getElementById('fr-product').addEventListener('change', fillProduct);
        document.getElementById('fr-save-product').addEventListener('click', function () {
            var name = document.getElementById('fr-product').value;
            var note = document.getElementById('fr-stock-note');
            var usePackNode = document.getElementById('fr-use-pack');
            var after = addProductBatch(name, {
                batch_number: document.getElementById('fr-batch').value,
                production_date: document.getElementById('fr-produced').value,
                expiration_date: document.getElementById('fr-expires').value,
                quantity: document.getElementById('fr-stock').value,
                use_packaging: !usePackNode || usePackNode.checked
            });
            if (after == null) {
                note.textContent = lastStockError || 'That stock could not be added.';
                return;
            }
            var added = Number(document.getElementById('fr-stock').value);
            var priceNode = document.getElementById('fr-price');
            var priceText = '';
            if (priceNode && canEditPrice() && priceNode.value !== '') {
                var before = window.KreezbyDictionary.productPrice(name);
                saveProductFields(name, { price: priceNode.value });
                if (Number(before) !== Number(priceNode.value)) priceText = ' Price is now ₱' + Number(priceNode.value).toFixed(2) + '.';
            }
            document.querySelectorAll('.dict-fields').forEach(function (node) { node.remove(); });
            decorateStocks();
            fillProduct();
            note.textContent = added + ' pouches of ' + name + ' added as a new batch. On hand now: ' + after + '.' + priceText
                + (lastPackagingUsed ? ' Packaging used: ' + lastPackagingUsed + '.' : '');
        });
        document.getElementById('fr-save-move').addEventListener('click', function () {
            var name = String(document.getElementById('fr-material').value || '').trim();
            var typeNode = document.getElementById('fr-type');
            var kind = typeNode && typeNode.value === 'packaging' ? 'packaging' : 'raw';
            var costNode = document.getElementById('fr-unit-cost');
            var next = name ? recordMaterialMovement(name, document.getElementById('fr-move').value, document.getElementById('fr-qty').value, (document.getElementById('fr-note') || {}).value, kind, costNode ? costNode.value : null) : null;
            document.getElementById('fr-stock-note').textContent = !name
                ? (kind === 'packaging' ? 'Type a packaging material name.' : 'Type a raw material name.')
                : (next == null ? (lastMovementError || 'Enter a quantity greater than zero.') : (document.getElementById('fr-move').value === 'waste' ? document.getElementById('fr-qty').value + ' recorded as waste / spoiled. ' : '') + name + ' now has ' + next + ' on hand.'
                    + (lastMovementCost != null && costNode && costNode.value !== '' ? ' Cost per unit: ₱' + Number(lastMovementCost).toFixed(2) + ', stock value ₱' + (Number(lastMovementCost) * next).toFixed(2) + '.' : '')
                    + ' Movement saved to the log below.');
            if (next != null) lastMovementCost = null;
            if (next != null && document.getElementById('fr-note')) document.getElementById('fr-note').value = '';
        });
        fillProduct();

        // Stock out (waste / spoiled) keeps the cost per unit, so its field is hidden. Use in
        // production is recorded automatically by Inventory > Production.
        var moveSelect = document.getElementById('fr-move');
        var syncMoveFields = function () {
            var costInput = document.getElementById('fr-unit-cost');
            var field = costInput && (costInput.closest('.fr-field') || costInput.closest('label'));
            var out = moveSelect && moveSelect.value !== 'stock-in';
            if (field) field.style.display = out ? 'none' : '';
            var noteInput = document.getElementById('fr-note');
            if (noteInput) noteInput.placeholder = out
                ? 'Reason (required), e.g. flour got wet'
                : 'Supplier, batch or reason (optional)';
        };
        if (moveSelect) moveSelect.addEventListener('change', syncMoveFields);
        syncMoveFields();

        // Picking a material fills in its current cost per unit (it can be changed).
        var materialInput = document.getElementById('fr-material');
        if (materialInput) {
            materialInput.addEventListener('change', function () {
                var costInput = document.getElementById('fr-unit-cost');
                var found = materialByName(materialInput.value);
                if (!costInput) return;
                costInput.value = found ? materialUnitCost(found.material_id).toFixed(2) : '';
            });
        }

        // One "Add stock" card: the Stock type picks which fields show.
        var typeSelect = document.getElementById('fr-type');
        if (typeSelect) {
            var LEADS = {
                product: 'Add a new batch with its produced and expiry dates' + (canEditPrice() ? ' (you can also set the selling price)' : '') + '. Stock can only be added; sales deduct finished goods automatically. To take the ingredients off automatically, use Production instead.',
                raw: 'Type any raw material, then record stock received (stock in), or stock thrown away as waste / spoiled with its reason. Ingredients used in production come off automatically in Production.',
                packaging: 'Type any packaging material (pouches, stickers), then record stock received, or waste / spoiled with its reason. Adding finished pouches uses packaging automatically.'
            };
            var applyType = function () {
                var type = typeSelect.value;
                var isProduct = type === 'product';
                box.querySelectorAll('[data-fr-group]').forEach(function (group) {
                    group.hidden = (group.getAttribute('data-fr-group') === 'product') !== isProduct;
                });
                var lead = document.getElementById('fr-lead');
                if (lead) lead.textContent = LEADS[type] || LEADS.product;
                if (!isProduct) {
                    var packaging = type === 'packaging';
                    var label = document.getElementById('fr-material-label');
                    if (label) label.textContent = packaging ? 'Packaging material' : 'Raw material';
                    var input = document.getElementById('fr-material');
                    if (input) input.placeholder = packaging ? 'Type a packaging material' : 'Type a raw material';
                    var list = document.getElementById('fr-material-list');
                    if (list) {
                        list.innerHTML = allMaterials().filter(function (item) {
                            return packaging ? isPackaging(item) : !isPackaging(item);
                        }).map(function (item) {
                            return '<option value="' + esc(item.name) + '">';
                        }).join('');
                    }
                }
                var note = document.getElementById('fr-stock-note');
                if (note) note.textContent = '';
                if (isProduct) fillProduct();
            };
            typeSelect.addEventListener('change', function () {
                var input = document.getElementById('fr-material');
                if (input) input.value = '';
                var costInput = document.getElementById('fr-unit-cost');
                if (costInput) costInput.value = '';
                applyType();
            });
            applyType();
        }
    }

    function seedPartnerAlerts() {
        var path = (location.pathname || '').replace(/\\/g, '/').toLowerCase();
        var partner = path.indexOf('/customer/') >= 0 || path.indexOf('/retailer/') >= 0;
        if (!partner) return;
        var notes = alerts().filter(function (alert) {
            return alert.alert_type === 'price_change' || alert.alert_type === 'new_product';
        });
        if (window.KreezbyNotifications && typeof window.KreezbyNotifications.getAll === 'function') {
            var existing = window.KreezbyNotifications.getAll();
            notes.forEach(function (alert) {
                var found = existing.some(function (item) { return item.id === 'dict-' + alert.alert_type; });
                if (found || typeof window.KreezbyNotifications.push !== 'function') return;
                window.KreezbyNotifications.push({
                    id: 'dict-' + alert.alert_type,
                    title: alert.alert_type === 'new_product' ? 'New product' : 'Price change',
                    description: alert.message,
                    source: alert.alert_type,
                    audiences: alert.alert_type === 'price_change' ? ['customer'] : ['customer', 'retailer'],
                    read: alert.status !== 'pending'
                });
            });
            return;
        }
        var list = readJson('kreezbyNotifications', []);
        notes.forEach(function (alert) {
            var id = 'dict-' + alert.alert_type;
            if (list.some(function (item) { return item.id === id; })) return;
            list.unshift({
                id: id,
                title: alert.alert_type === 'new_product' ? 'New product' : 'Price change',
                description: alert.message,
                timestamp: new Date().toISOString(),
                read: alert.status !== 'pending',
                source: alert.alert_type,
                audiences: alert.alert_type === 'price_change' ? ['customer'] : ['customer', 'retailer']
            });
        });
        try { localStorage.setItem('kreezbyNotifications', JSON.stringify(list)); } catch (e) { /* ignore */ }
    }

    function apply() {
        snapshot();
        decorateStocks();
        paintStockCells();
        hideArchivedStock();
        decorateAlerts();
        ensureForecastStyles();
        decorateSaleCards();
        mountStockTools();
        mountLedger();
        seedPartnerAlerts();
        notifyStocks();
    }

    window.KreezbyDictionary = {
        apply: apply,
        productId: productId,
        productById: productById,
        recordSale: recordSale,
        recordDeliveryStock: recordDeliveryStock,
        undoSale: undoSale,
        saleBlockReason: saleBlockReason,
        lastSaleError: function () { return lastSaleError; },
        setProductStock: setProductStock,
        addProductBatch: addProductBatch,
        productBatches: productBatches,
        productCatalog: productCatalog,
        lastStockError: function () { return lastStockError; },
        recordMaterialMovement: recordMaterialMovement,
        materialUnitCost: materialUnitCost,
        lastMovementError: function () { return lastMovementError; },
        materialMovements: materialMovements,
        saveProductFields: saveProductFields,
        // Current selling price per pouch: the saved price, else ₱165 (₱200 for Choco Butternut).
        productPrice: function (name) {
            var id = productId(name);
            if (!id) return null;
            var prices = savedState().product_prices || {};
            return prices[id] == null ? defaultPrice(id) : Number(prices[id]);
        },
        canEditPrice: canEditPrice,
        retailerPrice: retailerPrice,
        setRetailerPrice: setRetailerPrice,
        historyFor: historyFor,
        productStock: function (name) {
            var id = productId(name);
            return id ? productStockMap()[id] : null;
        },
        sellableStock: sellableStock,
        recordRetailerReturn: recordRetailerReturn,
        disposeExpiredBatch: disposeExpiredBatch,
        lastSaleShort: function () { return lastSaleShort; },
        materialByName: materialByName,
        // Every raw and packaging material with its stock on hand (for Inventory > Production).
        materials: function () {
            var stock = materialStockMap();
            return allMaterials().map(function (m) {
                return { material_id: m.material_id, name: m.name, packaging: isPackaging(m), stock: Number(stock[m.material_id]) || 0 };
            });
        },
        movementActor: movementActor,
        materialStock: function (name) {
            var material = materialByName(name);
            if (!material) return null;
            var map = materialStockMap();
            return map[material.material_id] == null ? null : map[material.material_id];
        },
        alerts: alerts,
        alertLineFor: function (code) { return configuredLine(code, ALERT_LINES[code]); },
        staffInventoryAlerts: staffInventoryAlerts,
        salesTransactions: salesTransactions,
        insightSnapshot: insightSnapshot,
        productRecommendationSnapshot: productRecommendationSnapshot
    };

    // A QR Ph order paid in GCash can be confirmed on the server while the customer is away
    // from the checkout page. Admin and staff pages take its items out of stock once.
    function deductPaidQrOrders() {
        if (!/\/(admin|head_admin|staff)\//i.test(location.pathname || '')) return;
        var orders = readJson('kreezbyOrders', []);
        if (!Array.isArray(orders)) return;
        orders.forEach(function (order) {
            if (!order || order.inventoryDeducted || order.paymentStatus !== 'paid' || order.paymentMethod !== 'paymongo') return;
            if (/cancel|return|reject/i.test(String(order.status || ''))) return;
            var number = String(order.orderNumber || '');
            if (!number || claimsInFlight[number]) return;
            claimsInFlight[number] = true;
            // The server gives each order's stock deduction to exactly one page. Pages that lose
            // the claim only mark the order as handled, so stock is never taken twice.
            claimOrderDeduction(number, function (won) {
                delete claimsInFlight[number];
                if (won === null) return; // server unreachable: try again on the next check
                var fresh = readJson('kreezbyOrders', []);
                var target = Array.isArray(fresh) ? fresh.filter(function (row) { return row && row.orderNumber === number; })[0] : null;
                if (!target) return;
                if (won) {
                    Object.keys(target.items || {}).forEach(function (key) {
                        var item = target.items[key];
                        if (item && item.name && productId(item.name)) recordSale(item.name, Number(item.qty) || 0, String(target.paidAt || target.date || '').slice(0, 10));
                    });
                }
                target.inventoryDeducted = true;
                try { localStorage.setItem('kreezbyOrders', JSON.stringify(fresh)); } catch (e) { /* ignore */ }
            });
        });
    }

    var claimsInFlight = {};
    function claimOrderDeduction(orderNumber, done) {
        try {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/stock/claim-order', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.timeout = 10000;
            xhr.onload = function () {
                if (xhr.status !== 200) { done(null); return; }
                try { done(!!JSON.parse(xhr.responseText).claimed); } catch (e) { done(null); }
            };
            xhr.onerror = xhr.ontimeout = function () { done(null); };
            xhr.send(JSON.stringify({ orderNumber: orderNumber }));
        } catch (e) { done(null); }
    }

    function boot() {
        apply();
        // Wait for the server copy before checking, so an older local copy is never used.
        setTimeout(deductPaidQrOrders, 5000);
    }
    document.addEventListener('kreezby:remote-state', function (e) {
        var keys = e && e.detail && e.detail.keys;
        if (keys && keys.indexOf('kreezbyOrders') !== -1) deductPaidQrOrders();
    });

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
    document.addEventListener('kreezby:page-load', apply);
    document.addEventListener('kreezby:stocks-sync', function () { mountLedger(); });
    document.addEventListener('content:replaced', ensureForecastStyles);
})();
