const fs = require("fs");
const path = require("path");
const https = require("https");
const dns = require("dns");
const express = require("express");
const { MongoClient } = require("mongodb");
const QRCode = require("qrcode");
require("dotenv").config();
const crypto = require("crypto");
// Vercel's network can leave the IPv6 route to api.openai.com hanging until the
// function is killed. Prefer IPv4 for every lookup, same as the Mongo client.
if (typeof dns.setDefaultResultOrder === "function") dns.setDefaultResultOrder("ipv4first");
const retailerRecords = require("./scripts/retailer-records.js");

const PORT = process.env.PORT || 3000;
const SERVERLESS = !!process.env.VERCEL;
const DB_NAME = "kreezby";
const SITE_ROOT = path.join(__dirname, "Kreezby-Bakeshop-main");
const SALES_LIST_FILE = path.join(SITE_ROOT, "data", "kreezby-sales-fake-admin.json");
const CUSTOMER_ORDERS_FILE = path.join(SITE_ROOT, "data", "customer-orders.json");
const KEY_RE = /^kreezby[A-Za-z0-9_-]{0,120}$/;
const LOCAL_ONLY = new Set([
  "kreezbySidebarCollapsed",
  "kreezby_session",
  "kreezbyOpenOrdersAfterCheckout",
  "kreezbyLatestOrderNumber",
  "kreezby_retailer_home",
  "kreezby_wholesaler_home",
  "kreezby_admin_delivery_nav_v1",
  "kreezby_staff_delivery_nav_v1",
  "kreezbyBrowserAlertSeen",
  "kreezbyNotifyPrompted",
  "kreezbyCart",
  "kreezbyCustomerProfile",
  "kreezbyDockedSidebar",
  "kreezby_admin_pos_nav_v1",
  "kreezby_staff_pos_nav_v1",
]);

function isSharedKey(key) {
  return KEY_RE.test(key) && !LOCAL_ONLY.has(key);
}

function isEphemeralKey(key) {
  // Bookkeeping that should be saved but must not make every open page re-download the state.
  return /^(kreezbyPresence_|kreezbyBrowserAlert|kreezbyBadgeSeen_|kreezbyNotificationCursor$|kreezbyAlertLastQty$|kreezby_login_history$)/.test(String(key || ""));
}

const app = express();
let stateVersion = 0;
let lastDocCount = null;
let cache = {};
let mongoReady = false;

function createMongoClient() {
  if (!process.env.MONGODB_URI) return null;
  // One local server and a few people in the shop at once, talking to a
  // 3-member Atlas set. Five warm sockets stay open so a quiet stretch does
  // not drop the link. Twenty is enough if several pages save together.
  // (5 pool + 2 monitoring) x 3 members is about 21 connections on the cluster.
  return new MongoClient(process.env.MONGODB_URI, {
    minPoolSize: SERVERLESS ? 0 : 5,
    maxPoolSize: SERVERLESS ? 5 : 20,
    maxIdleTimeMS: SERVERLESS ? 60 * 1000 : 10 * 60 * 1000,
    connectTimeoutMS: 10000,
    socketTimeoutMS: 30000,
    serverSelectionTimeoutMS: 10000,
    heartbeatFrequencyMS: 10000,
    // Windows Node races IPv6 and IPv4. Atlas closes the IPv6 handshake,
    // which showed up as a TLS internal error. Stay on IPv4.
    autoSelectFamily: false,
    family: 4,
  });
}

let client = createMongoClient();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function resetClient() {
  if (client) {
    try {
      await client.close();
    } catch (error) {
      /* The failed client may already be closed. */
    }
  }
  client = createMongoClient();
}

// One-time data reset (2026-10-23): removes the 9 demo customers (keeps Mark Cruz) and zeroes the
// demo orders, purchasing, stock and sales. Runs once per database; backup in backup_20261023_*.
// Removed in the 2026-10-23 reset. A browser tab that still holds the old data must not
// bring these back when it saves.
const RETIRED_CUSTOMER_IDS = new Set([
  "cust-maria-santos", "cust-bryle-atienza", "cust-kyla-ramos", "cust-ana-reyes", "cust-christine-bautista",
  "cust-paolo-mendoza", "cust-jericho-villanueva", "cust-angela-flores", "cust-nicole-garcia",
]);
const RETIRED_ORDER_NUMBERS = new Set(["ORD-2026-1042", "ORD-2026-1038", "ORD-2026-1021", "ORD-2026-1015", "ORD-2026-1008"]);

// Orders and receipts are records of what happened: a save never removes one. The incoming
// list is merged with the stored list (same number = the incoming version wins), so a page
// that sends an empty or outdated list cannot wipe orders.
const APPEND_ONLY_LISTS = { kreezbyOrders: "orderNumber", kreezbyCustomerReceipts: "receiptNumber", kreezbyOwnerReceipts: "receiptNumber" };

// A note someone has read stays read: when a page sends an older copy of the notification
// list (for example while adding a new note), the read marks already saved are kept.
function keepNotificationReads(incoming) {
  if (typeof cache.kreezbyNotifications !== "string") return incoming;
  let next;
  let stored;
  try { next = JSON.parse(incoming); stored = JSON.parse(cache.kreezbyNotifications); } catch (error) { return incoming; }
  if (!Array.isArray(next) || !Array.isArray(stored)) return incoming;
  const saved = new Map();
  stored.forEach((row) => { if (row && row.id != null) saved.set(String(row.id), row); });
  let changed = false;
  next.forEach((row) => {
    const was = row && row.id != null ? saved.get(String(row.id)) : null;
    if (!was) return;
    if (was.read && !row.read) { row.read = true; changed = true; }
    if (was.readBy && typeof was.readBy === "object") {
      const readBy = row.readBy && typeof row.readBy === "object" ? row.readBy : {};
      Object.keys(was.readBy).forEach((who) => {
        if (was.readBy[who] && !readBy[who]) { readBy[who] = true; changed = true; }
      });
      row.readBy = readBy;
    }
  });
  return changed ? JSON.stringify(next) : incoming;
}

function keepStoredRecords(key, incoming) {
  if (key === "kreezbyNotifications") return keepNotificationReads(incoming);
  const field = APPEND_ONLY_LISTS[key];
  if (!field || typeof cache[key] !== "string") return incoming;
  let next;
  let stored;
  try { next = JSON.parse(incoming); stored = JSON.parse(cache[key]); } catch (error) { return incoming; }
  if (!Array.isArray(next) || !Array.isArray(stored)) return incoming;
  // A paid order never goes back to unpaid because a page sent an older copy.
  let upgraded = false;
  if (key === "kreezbyOrders") {
    const paid = new Map();
    stored.forEach((row) => { if (row && row.paymentStatus === "paid" && row.orderNumber) paid.set(String(row.orderNumber), row); });
    next.forEach((row) => {
      const was = row && paid.get(String(row.orderNumber || ""));
      if (!was || row.paymentStatus === "paid") return;
      ["paymentStatus", "paymentVerified", "paidAt", "paymongo"].forEach((k) => { if (was[k] !== undefined) row[k] = was[k]; });
      if (row.status === "Awaiting payment" || row.status === "Payment expired") row.status = was.status;
      upgraded = true;
    });
  }
  const ids = new Set(next.map((row) => row && String(row[field] || "")).filter(Boolean));
  const missing = stored.filter((row) => {
    const id = row && String(row[field] || "");
    return id && !ids.has(id) && !RETIRED_ORDER_NUMBERS.has(String(row.orderNumber || ""));
  });
  if (!missing.length) return upgraded ? JSON.stringify(next) : incoming;
  return JSON.stringify(next.concat(missing));
}

// ---- Stock consistency -------------------------------------------------------------------
// Stock lives in a few shared JSON documents. Two people changing stock at the same moment used
// to overwrite each other (last write won). These keys are now merged three ways: what the
// browser started from (base), what it sends, and what the database holds right now. Stock
// counts are merged as differences (database + this change), so both changes count.
const STOCK_MERGE_KEYS = {
  kreezby_data_dictionary_v1: /^(product_stock|material_stock)\.[^.]+$/,
  "kreezby-stock-local-v1": /^qty\.[^.]+$/,
  kreezby_archived_stock: null,
  kreezbyStockItemValues: null,
  kreezby_stock_snapshots_v1: null,
};

function sameJson(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

function isPlainObject(v) {
  return v && typeof v === "object" && !Array.isArray(v);
}

let mergeConflicts = [];

function threeWayMerge(base, inc, cur, path, numericRule) {
  if (sameJson(inc, base)) return cur;
  if (sameJson(cur, base)) return inc;
  if (isPlainObject(inc) && isPlainObject(cur)) {
    const b = isPlainObject(base) ? base : {};
    const out = {};
    const keys = new Set([...Object.keys(b), ...Object.keys(inc), ...Object.keys(cur)]);
    for (const k of keys) {
      const inHas = Object.prototype.hasOwnProperty.call(inc, k);
      const curHas = Object.prototype.hasOwnProperty.call(cur, k);
      const baseHas = Object.prototype.hasOwnProperty.call(b, k);
      if (!inHas) {
        // we removed it: honour that unless someone else changed it meanwhile
        if (curHas && !(baseHas && sameJson(cur[k], b[k]))) out[k] = cur[k];
        continue;
      }
      if (!curHas) {
        // they removed it: keep our version only if we changed it
        if (!baseHas || !sameJson(inc[k], b[k])) out[k] = inc[k];
        continue;
      }
      out[k] = threeWayMerge(baseHas ? b[k] : undefined, inc[k], cur[k], path ? path + "." + k : k, numericRule);
    }
    return out;
  }
  if (Array.isArray(inc) && Array.isArray(cur)) {
    const b = Array.isArray(base) ? base : [];
    const count = (list) => { const m = new Map(); list.forEach((x) => { const j = JSON.stringify(x); m.set(j, (m.get(j) || 0) + 1); }); return m; };
    const baseCount = count(b);
    const incCount = count(inc);
    const removed = new Map();
    const added = [];
    baseCount.forEach((n, j) => { const gone = n - (incCount.get(j) || 0); if (gone > 0) removed.set(j, gone); });
    const addSeen = new Map();
    inc.forEach((x) => {
      const j = JSON.stringify(x);
      const had = baseCount.get(j) || 0;
      const used = addSeen.get(j) || 0;
      if (used >= had) added.push(x);
      addSeen.set(j, used + 1);
    });
    const result = [];
    cur.forEach((x) => {
      const j = JSON.stringify(x);
      const gone = removed.get(j) || 0;
      if (gone > 0) { removed.set(j, gone - 1); return; }
      result.push(x);
    });
    return result.concat(added);
  }
  if (numericRule && numericRule.test(path) && typeof inc === "number" && typeof cur === "number" && typeof base === "number") {
    const next = cur + (inc - base);
    // Two places took the same last pouches at the same moment: stock never goes below zero,
    // and the shortfall is reported (stock_conflicts + a notification) so it can be checked.
    if (next < 0) mergeConflicts.push({ path, stockBefore: cur, change: inc - base, short: -next });
    return Math.max(0, next);
  }
  return inc;
}

async function reportStockConflicts(key, list) {
  try {
    await client.db(DB_NAME).collection("stock_conflicts").insertOne({ at: new Date(), key, conflicts: list });
    const notes = JSON.parse(cache.kreezbyNotifications || "[]");
    if (!Array.isArray(notes)) return;
    const text = list.map((c) => c.path.split(".").pop() + ": " + c.short + " short").join(", ");
    notes.unshift({
      id: "n-stock-conflict-" + Date.now(),
      title: "Stock conflict",
      description: "Two transactions used the same stock at the same time (" + text + "). Stock was kept at 0. Check the Inventory history.",
      timestamp: new Date().toISOString(),
      read: false,
      source: "stock",
      audiences: ["head", "admin"],
    });
    const value = JSON.stringify(notes);
    cache.kreezbyNotifications = value;
    cacheTouched.kreezbyNotifications = Date.now();
    await collection().updateOne({ _id: "kreezbyNotifications" }, { $set: { value, updatedAt: new Date() } }, { upsert: true });
  } catch (error) {
    console.error("Stock conflict report: " + error.message);
  }
}

// Reads the current value, merges, and writes only if nobody changed it in between (retries).
async function saveStockKey(key, incoming, baseText) {
  const col = collection();
  let base = null;
  try { base = JSON.parse(baseText); } catch (e) { base = null; }
  for (let attempt = 0; attempt < 6; attempt++) {
    mergeConflicts = [];
    const row = await col.findOne({ _id: key });
    const curText = row && typeof row.value === "string" ? row.value : null;
    let finalText = incoming;
    if (curText != null && curText !== incoming && curText !== baseText && base !== null) {
      try {
        const merged = threeWayMerge(base, JSON.parse(incoming), JSON.parse(curText), "", STOCK_MERGE_KEYS[key]);
        finalText = JSON.stringify(merged);
      } catch (e) { finalText = incoming; }
    }
    const filter = curText == null ? { _id: key } : { _id: key, value: curText };
    try {
      const result = await col.updateOne(filter, { $set: { value: finalText, updatedAt: new Date() } }, { upsert: curText == null });
      if (result.matchedCount || result.upsertedCount) {
        cache[key] = finalText;
        cacheTouched[key] = Date.now();
        if (mergeConflicts.length) await reportStockConflicts(key, mergeConflicts.slice());
        return finalText;
      }
    } catch (error) {
      if (!(error && error.code === 11000)) throw error;
    }
  }
  throw new Error("Stock changed too often at once; please retry.");
}

// Accounts deleted straight in MongoDB: a browser that still holds them must not bring them back.
let accountTombstones = {};
function accountRowKeys(row) {
  if (!row || typeof row !== "object") return [];
  return [row.id, row.user_id, row.email, row.username].map((v) => String(v == null ? "" : v).trim().toLowerCase()).filter(Boolean);
}

function dropRetired(key, stored) {
  try {
    if (key === "kreezby_maintenance_users") {
      const users = JSON.parse(stored);
      const dead = Object.keys(accountTombstones);
      if (users && dead.length) {
        let touched = false;
        for (const bucket of Object.keys(ACCOUNT_COLLECTIONS)) {
          if (!Array.isArray(users[bucket])) continue;
          const kept = users[bucket].filter((row) => !accountRowKeys(row).some((k) => accountTombstones[k]));
          if (kept.length !== users[bucket].length) { users[bucket] = kept; touched = true; }
        }
        if (touched) return dropRetired(key, JSON.stringify(users));
      }
      if (users && Array.isArray(users.customers)) {
        const kept = users.customers.filter((c) => !c || !RETIRED_CUSTOMER_IDS.has(String(c.id || c.user_id || "")));
        if (kept.length !== users.customers.length) return JSON.stringify(Object.assign({}, users, { customers: kept }));
      }
    } else if (key === "kreezbyOrders" || key === "kreezbyCustomerReceipts" || key === "kreezbyOwnerReceipts") {
      const list = JSON.parse(stored);
      if (Array.isArray(list)) {
        const kept = list.filter((o) => !o || !RETIRED_ORDER_NUMBERS.has(String(o.orderNumber || "")));
        if (kept.length !== list.length) return JSON.stringify(kept);
      }
    }
  } catch (error) {
    /* not JSON: store as sent */
  }
  return stored;
}

// Retailer list 2026 (UPDATED_Retailer_List_2026.xlsx): area of every retailer shop and its
// usual pieces per delivery. Applied once: account areas in MongoDB and in the shared account
// list are set to these areas, so Settings and the Retailer Delivery POS list them correctly.
const RETAILER_LIST_2026 = [
  ["Lucena", "Chick'N J Ibaan", 10],
  ["Batangas", "SIDC Main", 15],
  ["Sto. Tomas", "Kubo sa Halamanan Malarayat", 15],
  ["Lipa", "SIDC Mahabang Parang", 20],
  ["Tagaytay", "HMM Muzon", 10],
  ["Citimart", "Citimart Caedo", 30],
  ["Lucena", "SIDC IBAAN", 15],
  ["Batangas", "SIDC Soro-Soro Ilaya", 20],
  ["Sto. Tomas", "LBN Marawoy", 15],
  ["Lipa", "SIDC San Jose", 10],
  ["Tagaytay", "SIDC Bauan", 10],
  ["Citimart", "Citimart Nuciti", 25],
  ["Lucena", "Balkonahe", 6],
  ["Batangas", "3M", 5],
  ["Sto. Tomas", "Kubo sa Halamanan Marawoy", 10],
  ["Lipa", "Banay-banay Eatery", 20],
  ["Tagaytay", "SIDC Sta. Teresita", 10],
  ["Citimart", "Citimart Baystar/Baymall", 45],
  ["Lucena", "Citimart Rosario", 25],
  ["Batangas", "Jhorjhanes Balagtas", 30],
  ["Sto. Tomas", "Lucias Cafe Lipa", 20],
  ["Lipa", "AA Lomi Lipa", 10],
  ["Tagaytay", "AA Lomi Taal", 30],
  ["Citimart", "Citimart Shop on/ Rizal Ave", 25],
  ["Lucena", "Chick'N J Namunga", 10],
  ["Batangas", "Wanam sa Bukid Balagtas", 15],
  ["Sto. Tomas", "Citimart Tanauan", 20],
  ["Lipa", "Butch Lipa", 35],
  ["Tagaytay", "Citimart Lemery", 25],
  ["Citimart", "Citimart Bauan", 50],
  ["Lucena", "SIDC Tiaong", 10],
  ["Batangas", "AA Lomi Balagtas", 40],
  ["Sto. Tomas", "Lucias Cafe Sto Tomas", 20],
  ["Lipa", "Shell Select Tambo", 10],
  ["Tagaytay", "Jaytees Acienda", 30],
  ["Citimart", "Dyan's", 5],
  ["Lucena", "Mr.Fields Coffe+", 15],
  ["Batangas", "Butch Alangilan", 35],
  ["Sto. Tomas", "JMA", 30],
  ["Lipa", "Shell Select Balintawak", 20],
  ["Tagaytay", "RSM Silvinas", 5],
  ["Citimart", "Ofels", 10],
  ["Lucena", "Bangihan", 10],
  ["Batangas", "Gracias Pasalubong", 15],
  ["Sto. Tomas", "Rose & Grace", 50],
  ["Lipa", "Lipa Grill Lipa", 50],
  ["Tagaytay", "Pamana", 15],
  ["Citimart", "Jorjhanes Sta. Rita", 10],
  ["Lucena", "Girasoles", 10],
  ["Batangas", "Shell Select Kumintang Ibaba", 10],
  ["Sto. Tomas", "D'Vinias", 5],
  ["Lipa", "Lipa Grill San Felipe", 25],
  ["Tagaytay", "Jaytees Main", 50],
  ["Lucena", "Shell Select Sariaya", 20],
  ["Batangas", "SIDC Tulo", 20],
  ["Sto. Tomas", "Tita Chu", 10],
  ["Lipa", "AA Lomi Padre Garcia", 30],
  ["Tagaytay", "Balinsasayaw Tagaytay", 15],
  ["Lucena", "Kope Right Sariaya", 20],
  ["Batangas", "SIDC Libjo", 30],
  ["Sto. Tomas", "Laong Laan", 10],
  ["Lipa", "Chick'N J Padre Garcia", 10],
  ["Tagaytay", "Green Ats", 10],
  ["Lucena", "Kope Right Lucena", 10],
  ["Batangas", "SIDC Pallocan", 10],
  ["Sto. Tomas", "Avilles", 10],
  ["Lipa", "Ben & Cha", 10],
  ["Tagaytay", "Jaytees 9th", 20],
  ["Lucena", "Shell Select Domoit", 20],
  ["Batangas", "Wanam sa Bukid Gulod", 20],
  ["Lucena", "SIDC San Juan", 10],
  ["Batangas", "Wanam sa Bukid Palengke", 10],
  ["Lucena", "Chick'N J Baybayin", 10],
  ["Batangas", "AA San Pascual", 275],
  ["Lucena", "Matteos Liquiwan", 20],
  ["Lucena", "Yummies", 15],
  ["Lucena", "Hang Out", 15]
];

function retailerKey(name) {
  return String(name || "").toLowerCase().replace(/&/g, " and ").replace(/'/g, " ").replace(/[^a-z0-9]+/g, " ").trim();
}

async function applyRetailerList2026() {
  const db = client.db(DB_NAME);
  const marker = "retailer_list_2026_applied";
  if (await collection().findOne({ _id: marker })) return;
  const byName = new Map(RETAILER_LIST_2026.map(([area, name, pcs]) => [retailerKey(name), { area, pcs }]));
  const accounts = await db.collection("retailer_accounts").find({}, { projection: { name: 1, area: 1 } }).toArray();
  const ops = [];
  accounts.forEach((acc) => {
    const hit = byName.get(retailerKey(acc.name));
    if (!hit) return;
    ops.push({ updateOne: { filter: { _id: acc._id }, update: { $set: { area: hit.area, usualPcs: hit.pcs } } } });
  });
  if (ops.length) await db.collection("retailer_accounts").bulkWrite(ops, { ordered: false });
  // The shared account list (Settings) carries the same areas.
  const row = await collection().findOne({ _id: "kreezby_maintenance_users" });
  if (row && typeof row.value === "string") {
    try {
      const users = JSON.parse(row.value);
      let changed = false;
      (users.retailers || []).forEach((u) => {
        const hit = u && byName.get(retailerKey(u.name));
        if (!hit) return;
        if (u.area !== hit.area) { u.area = hit.area; changed = true; }
        if (u.usualPcs !== hit.pcs) { u.usualPcs = hit.pcs; changed = true; }
      });
      if (changed) await persistUsersState(users);
    } catch (error) { /* leave the shared list as it is */ }
  }
  // Rebuild each retailer's sales document so it shows the new area.
  await db.collection("retailer_sales").deleteOne({ _id: "_meta" }).catch(() => {});
  await collection().updateOne({ _id: marker }, { $set: { at: new Date(), shops: ops.length } }, { upsert: true });
  console.log("Retailer list 2026 applied to " + ops.length + " shops.");
}

async function runOneTimeReset() {
  try {
    await applyRetailerList2026();
  } catch (error) {
    console.error("Retailer list 2026 could not be applied: " + error.message);
  }
  try {
    const reset = require("./scripts/reset-data.js");
    const log = (line) => console.log("[reset] " + line);
    const done = await reset.runResetOnce(client.db(DB_NAME), log);
    if (done) console.log("[reset] One-time data reset finished.");
    await reset.runAlertCleanupOnce(client.db(DB_NAME), log);
    await reset.runRestoreMarkOnce(client.db(DB_NAME), log);
  } catch (error) {
    console.error("[reset] One-time data reset failed: " + error.message);
  }
}

async function activateMongo() {
  if (!client) throw new Error("Missing MONGODB_URI in .env");
  await client.connect();
  await client.db(DB_NAME).command({ ping: 1 });
  if (!mongoReady) {
    await runOneTimeReset();
    await ensureSalesList();
    await refreshCache();
    await backfillMirrors();
    await ensureCustomerOrders();
    if (cache.kreezby_maintenance_users) {
      await syncAccountCollections(cache.kreezby_maintenance_users);
    }
    mongoReady = true;
    console.log("MongoDB connected");
  }
}

async function maintainMongo() {
  let failures = 0;
  for (;;) {
    try {
      await activateMongo();
      failures = 0;
      await sleep(15000);
    } catch (error) {
      mongoReady = false;
      failures += 1;
      const wait = Math.min(2000 * (2 ** Math.min(failures - 1, 4)), 30000);
      console.error("MongoDB unavailable. Retrying in " + Math.round(wait / 1000) + "s. " + error.message);
      await resetClient();
      await sleep(wait);
    }
  }
}

const ACCOUNT_COLLECTIONS = {
  admins: "admin_accounts",
  staff: "staff_accounts",
  retailers: "retailer_accounts",
  customers: "customer_accounts",
  wholesalers: "wholesaler_accounts",
};

const ACCOUNT_TYPES = {
  admins: "admin",
  staff: "staff",
  retailers: "retailer",
  customers: "customer",
  wholesalers: "wholesaler",
};

function collection() {
  return client.db(DB_NAME).collection("app_state");
}

function salesListCollection() {
  return client.db(DB_NAME).collection("sales_route_sheets");
}

async function ensureSalesList() {
  let raw;
  try {
    raw = JSON.parse(fs.readFileSync(SALES_LIST_FILE, "utf8"));
  } catch (error) {
    console.error("Sales list file unavailable. " + error.message);
    return;
  }
  const reports = Array.isArray(raw.dailyReports) ? raw.dailyReports : [];
  const ids = reports.map((report) => report && report.id ? String(report.id) : "").filter(Boolean);
  const col = salesListCollection();
  const meta = await col.findOne({ _id: "_meta" });
  if (meta && meta.reportCount === ids.length && meta.importedAt === (raw.importedAt || null)) return;

  const ops = [];
  for (const report of reports) {
    if (!report || !report.id) continue;
    const doc = { ...report, updatedAt: new Date() };
    delete doc._id;
    ops.push({
      updateOne: {
        filter: { _id: String(report.id) },
        update: { $set: doc },
        upsert: true,
      },
    });
  }
  for (let i = 0; i < ops.length; i += 400) {
    await col.bulkWrite(ops.slice(i, i + 400), { ordered: false });
  }
  await col.updateOne(
    { _id: "_meta" },
    {
      $set: {
        importedAt: raw.importedAt || null,
        dateRange: raw.dateRange || null,
        sources: raw.sources || {},
        note: raw.note || "",
        isTestData: !!raw.isTestData,
        adminOnly: !!raw.adminOnly,
        dataset: raw.dataset || "",
        reportCount: ids.length,
        updatedAt: new Date(),
      },
    },
    { upsert: true }
  );
  console.log("Sales list stored: " + ids.length + " route sheets");
}

function customerOrderId(order) {
  return String((order && (order.orderNumber || order.Order_ID)) || "").trim();
}

function readJsonArrayFile(file) {
  try {
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error("Could not read " + path.basename(file) + ". " + error.message);
    return [];
  }
}

function readCachedCustomerOrders() {
  if (!cache.kreezbyOrders) return [];
  try {
    const parsed = JSON.parse(cache.kreezbyOrders);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    return [];
  }
}

function salesOrderRecord(order) {
  const items = order.items && typeof order.items === "object" ? Object.values(order.items) : [];
  const quantity = items.reduce((sum, item) => sum + (Number(item && item.qty) || 0), 0);
  const products = items.map((item) => item && item.name).filter(Boolean).join(", ");
  const customer = (order.shippingInfo && order.shippingInfo.fullName) || order.poEntity || "Customer";
  return {
    Order_ID: customerOrderId(order),
    Order_Status: order.status || "Processing",
    Customer_ID: customer,
    Product_ID: products,
    Order_Quantity: quantity,
    Order_Date: order.date ? String(order.date).slice(0, 10) : "",
    Order_Total: order.total || "",
    updatedAt: new Date(),
  };
}

async function syncCustomerOrderDocs(orders) {
  const customerCol = client.db(DB_NAME).collection("customer_orders");
  const salesCol = client.db(DB_NAME).collection("sales_orders");
  const customerOps = [];
  const salesOps = [];
  for (const order of orders) {
    const id = customerOrderId(order);
    if (!id) continue;
    const doc = { ...order, updatedAt: new Date() };
    delete doc._id;
    customerOps.push({
      updateOne: {
        filter: { _id: id },
        update: { $set: doc },
        upsert: true,
      },
    });
    salesOps.push({
      updateOne: {
        filter: { _id: id },
        update: { $set: salesOrderRecord(order) },
        upsert: true,
      },
    });
  }
  if (customerOps.length) await customerCol.bulkWrite(customerOps, { ordered: false });
  if (salesOps.length) await salesCol.bulkWrite(salesOps, { ordered: false });
  return customerOps.length;
}

async function ensureCustomerOrders() {
  const byId = new Map();
  for (const order of readJsonArrayFile(CUSTOMER_ORDERS_FILE)) {
    const id = customerOrderId(order);
    if (id) byId.set(id, order);
  }
  for (const order of readCachedCustomerOrders()) {
    const id = customerOrderId(order);
    if (id) byId.set(id, order);
  }
  const count = await syncCustomerOrderDocs([...byId.values()]);
  console.log("Customer orders stored: " + count);
}

async function syncAccountCollections(raw) {
  let users;
  try {
    users = JSON.parse(raw);
  } catch (error) {
    return;
  }
  if (!users || typeof users !== "object") return;

  const db = client.db(DB_NAME);
  for (const [bucket, collectionName] of Object.entries(ACCOUNT_COLLECTIONS)) {
    if (!Array.isArray(users[bucket])) continue;
    const col = db.collection(collectionName);
    const ops = [];
    for (const account of users[bucket]) {
      if (!account || typeof account !== "object") continue;
      const id = String(account.id || account.user_id || account.email || account.username || "").trim();
      if (!id) continue;
      const accountType = account.accountType === "Head Administrator"
        ? "Head Administrator"
        : ACCOUNT_TYPES[bucket];
      const doc = { ...account, id, user_id: account.user_id || id, accountType, syncedFromApp: true, updatedAt: new Date() };
      delete doc._id;
      // Keep login secrets (temporaryPassword / password). Dummy password_hash values from
      // the browser seed are not real hashes and must not overwrite a stored hash.
      if (typeof doc.password_hash === "string" && doc.password_hash.indexOf("ph_") === 0) {
        delete doc.password_hash;
      }
      ops.push({
        updateOne: {
          filter: { _id: id },
          update: { $set: doc },
          upsert: true,
        },
      });
    }
    if (ops.length) await col.bulkWrite(ops, { ordered: false });
    // Upsert only. A browser with a partial user list must never delete accounts
    // that already live in MongoDB (including newly signed-up customers).
  }
}

function accountIdentityValues(account) {
  if (!account || typeof account !== "object") return [];
  return [account.email, account.username, account.user_id, account.id, account._id, account.contact, account.phone];
}

function sanitizeAccountInput(bucket, input) {
  const src = input && typeof input === "object" ? input : {};
  const prefix = bucket === "customers" ? "cust" : bucket.slice(0, 4);
  const id = String(src.id || src.user_id || "").trim() || (prefix + "-" + Date.now());
  const name = String(src.name || "").trim();
  const email = String(src.email || "").trim();
  // Contact number is a phone number; never copy an email into it.
  const phone = [src.phone, src.contact].map((v) => String(v || "").trim()).find((v) => v && v.indexOf("@") < 0) || "";
  const username = String(src.username || "").trim().toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9._]/g, "").slice(0, 30);
  const password = String(src.temporaryPassword || src.password || "").trim();
  const roles = { admins: "Admin", staff: "Staff", retailers: "Retailer", customers: "Customer", wholesalers: "Wholesaler" };
  const doc = {
    id,
    user_id: String(src.user_id || id).trim(),
    name,
    role: String(src.role || roles[bucket] || "Customer"),
    accountType: src.accountType === "Head Administrator" ? "Head Administrator" : ACCOUNT_TYPES[bucket],
    active: src.active !== false,
    joined: String(src.joined || new Date().toISOString().slice(0, 10)).slice(0, 10),
    syncedFromApp: true,
    updatedAt: new Date(),
  };
  if (email) doc.email = email;
  if (phone) {
    doc.phone = phone;
    doc.contact = phone;
  }
  if (username) doc.username = username;
  if (src.birthday) doc.birthday = String(src.birthday).slice(0, 10);
  if (src.address) doc.address = String(src.address).trim();
  if (src.area) doc.area = String(src.area).trim();
  // A retailer shop's own price per pouch (empty = the default retailer price).
  if (bucket === "retailers" && Object.prototype.hasOwnProperty.call(src, "retailerPrice")) {
    const price = Number(src.retailerPrice);
    doc.retailerPrice = Number.isFinite(price) && price > 0 ? Math.round(price * 100) / 100 : null;
  }
  if (password) doc.temporaryPassword = password;
  return doc;
}

async function findAccountClash(db, account, exceptId) {
  const keys = accountIdentityValues(account).map(loginKey).filter(Boolean);
  if (!keys.length) return null;
  for (const collectionName of Object.values(ACCOUNT_COLLECTIONS)) {
    const docs = await db.collection(collectionName).find({}).toArray();
    for (const row of docs) {
      if (String(row._id) === exceptId || String(row.id) === exceptId) continue;
      if (accountIdentityValues(row).some((field) => field != null && keys.includes(loginKey(field)))) {
        return row;
      }
    }
  }
  return null;
}

async function persistUsersState(users) {
  const stored = JSON.stringify(users);
  cache.kreezby_maintenance_users = stored;
  stateVersion = Date.now();
  await collection().bulkWrite([
    {
      updateOne: {
        filter: { _id: "kreezby_maintenance_users" },
        update: { $set: { value: stored, updatedAt: new Date() } },
        upsert: true,
      },
    },
    {
      updateOne: {
        filter: { _id: "state_meta" },
        update: { $set: { value: String(stateVersion) } },
        upsert: true,
      },
    },
  ], { ordered: false });
}

async function upsertAccountRecord(bucket, input) {
  const collectionName = ACCOUNT_COLLECTIONS[bucket];
  if (!collectionName) {
    return { status: 400, body: { ok: false, error: "Unknown account group." } };
  }
  const doc = sanitizeAccountInput(bucket, input);
  if (!doc.name) {
    return { status: 400, body: { ok: false, error: "Name is required." } };
  }
  if (bucket === "customers" && !doc.email && !doc.phone && !doc.username) {
    return { status: 400, body: { ok: false, error: "Email or phone is required." } };
  }
  if ((bucket === "staff" || bucket === "admins") && !doc.username) {
    return { status: 400, body: { ok: false, error: "Username is required." } };
  }
  const db = client.db(DB_NAME);
  const clash = await findAccountClash(db, doc, doc.id);
  if (clash) {
    return { status: 409, body: { ok: false, error: "An account with that email, username, or phone already exists." } };
  }
  const stored = { ...doc };
  delete stored._id;
  await db.collection(collectionName).updateOne(
    { _id: doc.id },
    { $set: stored },
    { upsert: true }
  );
  let users = {};
  try {
    // The latest shared account list (this server's copy can be a moment behind).
    const latest = await collection().findOne({ _id: "kreezby_maintenance_users" });
    if (latest && typeof latest.value === "string") cache.kreezby_maintenance_users = latest.value;
    users = JSON.parse(cache.kreezby_maintenance_users || "{}");
  } catch (error) {
    users = {};
  }
  if (!users || typeof users !== "object") users = {};
  if (!Array.isArray(users[bucket])) users[bucket] = [];
  const idx = users[bucket].findIndex((row) => String((row && (row.id || row.user_id)) || "") === doc.id);
  const stateRow = { ...stored };
  delete stateRow.updatedAt;
  delete stateRow.syncedFromApp;
  if (idx >= 0) users[bucket][idx] = Object.assign({}, users[bucket][idx], stateRow);
  else users[bucket].push(stateRow);
  await persistUsersState(users);
  return { status: 200, body: { ok: true, account: publicAccount({ ...stored, _id: doc.id }), bucket } };
}

// Keys this server wrote a moment ago: a refresh that raced with the write must not bring back the old value.
const cacheTouched = {};

// An account removed from its MongoDB collection (customer_accounts, staff_accounts, ...) is removed
// from the shared account list too, so it disappears from every portal.
const ACCOUNT_SEEN_DOC = "account_ids_seen";
let lastAccountReconcile = 0;
async function reconcileDeletedAccounts(force) {
  if (!mongoReady || !client) return false;
  const now = Date.now();
  if (!force && now - lastAccountReconcile < 4000) return false;
  lastAccountReconcile = now;
  const db = client.db(DB_NAME);
  const meta = db.collection("app_state");
  let seen = {};
  let deleted = {};
  try {
    const seenDoc = await meta.findOne({ _id: ACCOUNT_SEEN_DOC });
    const parsed = seenDoc && seenDoc.value ? JSON.parse(seenDoc.value) : {};
    seen = parsed.seen || {};
    deleted = parsed.deleted || {};
  } catch (error) { seen = {}; deleted = {}; }
  const present = {};
  let totalDocs = 0;
  for (const [bucket, name] of Object.entries(ACCOUNT_COLLECTIONS)) {
    const docs = await db.collection(name).find({}, { projection: { _id: 1, id: 1, user_id: 1, email: 1, username: 1 } }).toArray();
    present[bucket] = docs;
    totalDocs += docs.length;
  }
  if (!totalDocs) return false; // nothing readable: could be an outage, change nothing
  let users = null;
  try {
    const usersDoc = await meta.findOne({ _id: "kreezby_maintenance_users" });
    users = usersDoc && typeof usersDoc.value === "string" ? JSON.parse(usersDoc.value) : null;
  } catch (error) { users = null; }
  const nextSeen = {};
  let changed = false;
  for (const bucket of Object.keys(ACCOUNT_COLLECTIONS)) {
    const docs = present[bucket];
    nextSeen[bucket] = docs.map((d) => String(d._id));
    const rows = users && Array.isArray(users[bucket]) ? users[bucket] : null;
    if (!rows) continue;
    const presentKeys = new Set();
    docs.forEach((d) => accountRowKeys(d).concat([String(d._id).toLowerCase()]).forEach((k) => presentKeys.add(k)));
    const seenSet = new Set((seen[bucket] || []).map((v) => String(v).toLowerCase()));
    const gone = rows.filter((row) => {
      const keys = accountRowKeys(row);
      if (!keys.length || keys.some((k) => presentKeys.has(k))) return false;
      return row.fromMongo === true || keys.some((k) => seenSet.has(k));
    });
    if (!gone.length || gone.length > Math.max(2, rows.length * 0.5)) continue;
    users[bucket] = rows.filter((row) => gone.indexOf(row) < 0);
    gone.forEach((row) => accountRowKeys(row).forEach((k) => { deleted[k] = now; }));
    changed = true;
  }
  Object.keys(deleted).forEach((k) => { if (now - deleted[k] > 15 * 60 * 1000) delete deleted[k]; });
  accountTombstones = deleted;
  await meta.updateOne({ _id: ACCOUNT_SEEN_DOC }, { $set: { value: JSON.stringify({ seen: nextSeen, deleted }) } }, { upsert: true });
  if (changed) await persistUsersState(users);
  return changed;
}

async function refreshCache() {
  const docs = await collection().find({}).toArray();
  const next = {};
  for (const doc of docs) {
    if (typeof doc.value === "string") next[doc._id] = doc.value;
  }
  const now = Date.now();
  for (const key of Object.keys(cacheTouched)) {
    if (now - cacheTouched[key] > 5000) { delete cacheTouched[key]; continue; }
    if (typeof cache[key] === "string") next[key] = cache[key];
    else delete next[key];
  }
  cache = next;
}

// Browser security headers on every response.
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Content-Security-Policy", "frame-ancestors 'self'; object-src 'none'; base-uri 'self'");
  if (req.secure || String(req.headers["x-forwarded-proto"] || "") === "https") {
    res.setHeader("Strict-Transport-Security", "max-age=15552000; includeSubDomains");
  }
  next();
});

app.use(express.json({
  limit: "12mb",
  // Keep the exact bytes of PayMongo webhooks: their signature is checked against the raw body.
  verify(req, res, buf) {
    if (String(req.originalUrl || "").startsWith("/api/paymongo/webhook")) req.rawBody = buf.toString("utf8");
  },
}));

// Vercel runs this file as a serverless function: connect on demand instead of the
// always-on maintainMongo() loop, and keep the shared-state cache fresh per request.
let lazyConnect = null;
let lastCacheRefresh = 0;
app.use("/api", async (req, res, next) => {
  if (!client) return next();
  if (!SERVERLESS) {
    // Always-on server: re-read MongoDB so a document deleted or edited in Atlas shows up here too.
    if (mongoReady && /^\/(state(?!-)|permissions)/.test(req.path) && !(req.query && req.query.since) && Date.now() - lastCacheRefresh > 1500) {
      lastCacheRefresh = Date.now();
      try { await refreshCache(); } catch (error) { /* keep the last copy */ }
    }
    return next();
  }
  try {
    if (!mongoReady) {
      if (!lazyConnect) {
        lazyConnect = (async () => {
          await client.connect();
          await client.db(DB_NAME).command({ ping: 1 });
          await refreshCache();
          lastCacheRefresh = Date.now();
          mongoReady = true;
          Promise.resolve()
            .then(() => runOneTimeReset())
            .then(() => backfillMirrors())
            .catch((error) => console.error("MongoDB setup: " + error.message));
        })().finally(() => { lazyConnect = null; });
      }
      // Insight routes must answer before Vercel kills the function. Mongo can
      // finish in the background; the note is still saved if the connection is up.
      const insightRoute = req.path === "/management-insight" || req.path === "/product-recommendation";
      if (insightRoute) await Promise.race([lazyConnect.catch(() => {}), sleep(3000)]);
      else await lazyConnect;
    } else if (/^\/(state(?!-)|permissions)/.test(req.path) && !(req.query && req.query.since) && Date.now() - lastCacheRefresh > 1500) {
      lastCacheRefresh = Date.now();
      await refreshCache();
    }
  } catch (error) {
    mongoReady = false;
    console.error("MongoDB unavailable. " + error.message);
  }
  next();
});

app.use("/api", (req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Kreezby-Token");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  if (req.method === "OPTIONS") {
    res.sendStatus(204);
    return;
  }
  next();
});

// ---- Access rules for the API ----------------------------------------------------------------
// Every page sends its session token (X-Kreezby-Token, signed by the server at sign-in).
// - Without a token (guest pages, the sign-in page) only public data can be read, and only the
//   partner-inquiry form and sign-in bookkeeping can be written.
// - Passwords kept in the shared state are sent only to admin accounts; other accounts get the
//   same data without them, and a save from those accounts keeps the stored passwords.
// - An expired or forged token is refused (401) instead of being treated as a guest.
const GUEST_WRITABLE_RE = /^(kreezby-partner-inquiries-v1|kreezby_login_history|kreezbyPresence_)/;
const GUEST_HIDDEN_RE = /^(kreezby_maintenance_users|kreezbyAuthCredentials|kreezbyOrders|kreezby-po-orders-v1|kreezby-bo-orders-v1|kreezbyNotifications|kreezbyCustomerReceipts|kreezbyOwnerReceipts|kreezbyTeamChat_|kreezbyHelpQueue|kreezbyInbox|kreezbyChat|kreezbyIssue|kreezby-issue|kreezby-partner-inquiries|kreezby_security|kreezby_login_history|kreezbyPresence_|kreezby_staff_permissions|kreezby_admin_permissions|kreezby_delivery_schedule|kreezbyRetailer)/;
const SECRET_FIELDS = ["password", "temporaryPassword", "password_hash"];
// Customers and retailers also do not receive other people's contact details.
const CONTACT_FIELDS = ["email", "phone", "contact", "contactNumber", "mobile", "address", "birthday"];

function requestToken(req) {
  if (req.__kzToken !== undefined) return req.__kzToken;
  const raw = String((req.headers && req.headers["x-kreezby-token"]) || "").trim();
  req.__kzTokenSent = !!raw;
  req.__kzToken = raw ? retailerRecords.readToken(req) : null;
  return req.__kzToken;
}

function stripSecrets(key, text, reader) {
  if (key !== "kreezby_maintenance_users" && key !== "kreezbyAuthCredentials") return text;
  try {
    const data = JSON.parse(text);
    if (key === "kreezbyAuthCredentials") {
      const out = {};
      Object.keys(data || {}).forEach((k) => { const row = Object.assign({}, data[k]); SECRET_FIELDS.forEach((f) => delete row[f]); out[k] = row; });
      return JSON.stringify(out);
    }
    const outsider = reader && reader.bucket !== "admins" && reader.bucket !== "staff";
    Object.keys(data || {}).forEach((bucket) => {
      if (!Array.isArray(data[bucket])) return;
      data[bucket] = data[bucket].map((row) => {
        const copy = Object.assign({}, row);
        SECRET_FIELDS.forEach((f) => delete copy[f]);
        const own = reader && String(copy.id || copy.user_id || "") === String(reader.id);
        if (outsider && !own) CONTACT_FIELDS.forEach((f) => delete copy[f]);
        return copy;
      });
    });
    return JSON.stringify(data);
  } catch (error) {
    return text;
  }
}

// A save from an account that never received the passwords must not erase them.
function restoreSecrets(key, incoming, writer) {
  if ((key !== "kreezby_maintenance_users" && key !== "kreezbyAuthCredentials") || typeof cache[key] !== "string") return incoming;
  try {
    const next = JSON.parse(incoming);
    const stored = JSON.parse(cache[key]);
    if (key === "kreezbyAuthCredentials") {
      Object.keys(next || {}).forEach((k) => {
        const was = stored && stored[k];
        if (!was) return;
        SECRET_FIELDS.forEach((f) => { if (next[k] && next[k][f] === undefined && was[f] !== undefined) next[k][f] = was[f]; });
      });
      return JSON.stringify(next);
    }
    Object.keys(next || {}).forEach((bucket) => {
      if (!Array.isArray(next[bucket]) || !Array.isArray(stored && stored[bucket])) return;
      next[bucket].forEach((row) => {
        if (!row) return;
        const id = String(row.id || row.user_id || "");
        const was = id && stored[bucket].find((r) => r && String(r.id || r.user_id || "") === id);
        if (!was) return;
        SECRET_FIELDS.forEach((f) => { if (row[f] === undefined && was[f] !== undefined) row[f] = was[f]; });
        const outsider = !writer || (writer.bucket !== "admins" && writer.bucket !== "staff");
        if (outsider && !(writer && String(writer.id) === id)) CONTACT_FIELDS.forEach((f) => { if (row[f] === undefined && was[f] !== undefined) row[f] = was[f]; });
      });
    });
    return JSON.stringify(next);
  } catch (error) {
    return incoming;
  }
}

function itemsForReader(req, items) {
  const token = requestToken(req);
  const out = {};
  Object.keys(items || {}).forEach((key) => {
    const value = items[key];
    if (!token) { if (!GUEST_HIDDEN_RE.test(key)) out[key] = value; return; }
    out[key] = token.bucket === "admins" ? value : stripSecrets(key, value, token);
  });
  return out;
}

app.use("/api", (req, res, next) => {
  const token = requestToken(req);
  if (req.__kzTokenSent && !token && !/^\/(login|health|paymongo\/webhook)/.test(req.path)) {
    res.status(401).json({ ok: false, needLogin: true, error: "Your session has expired. Please log out and log in again." });
    return;
  }
  const bucket = token ? token.bucket : "";
  const staffOrAdmin = bucket === "admins" || bucket === "staff";
  const deny = (status, error) => res.status(status).json({ ok: false, needLogin: status === 401, error });
  // Shop permissions: read by every page, changed only by admins.
  if (req.path === "/permissions" && req.method === "POST" && bucket !== "admins") return deny(bucket ? 403 : 401, "Only admins can change permissions.");
  // Sales records: signed-in accounts only.
  if (/^\/records\//.test(req.path) && !token) return deny(401, "Please log in.");
  // Account records: staff and admins see every account; anyone else only their own.
  if (req.path === "/accounts" && req.method === "GET" && !token) return deny(401, "Please log in.");
  if (req.path === "/accounts" && req.method === "POST") {
    const wanted = String((req.body && req.body.bucket) || "customers").trim();
    if (wanted !== "customers" && bucket !== "admins") return deny(bucket ? 403 : 401, "Only admins can create or change staff, admin and retailer accounts.");
  }
  if (req.path === "/customer-orders" && req.method === "GET" && !token) return deny(401, "Please log in.");
  next();
});

function databaseReady(res) {
  if (mongoReady) return true;
  res.status(503).json({ ok: false, error: "Database is reconnecting." });
  return false;
}

app.get("/api/health", async (req, res) => {
  if (!databaseReady(res)) return;
  try {
    await client.db(DB_NAME).command({ ping: 1 });
    let cluster = "";
    try { cluster = new URL(String(process.env.MONGODB_URI || "").replace(/^mongodb(\+srv)?:/, "http:")).hostname; } catch (e) { cluster = ""; }
    res.json({ ok: true, database: DB_NAME, cluster, records: Object.keys(cache).length });
  } catch (error) {
    res.status(503).json({ ok: false, error: error.message });
  }
});

// Tiny "has anything changed?" check so browsers can poll every couple of seconds cheaply.
// Every open page asks this every 1.5 s, so it only reads state_meta. The slower checks
// (records added or deleted straight in MongoDB, deleted accounts) run at most every 10 s.
let lastSlowVersionCheck = 0;
app.get("/api/state-version", async (req, res) => {
  if (!databaseReady(res)) return;
  try {
    const row = await collection().findOne({ _id: "state_meta" });
    if (row && row.value) stateVersion = Number(row.value) || stateVersion;
    if (Date.now() - lastSlowVersionCheck < 10000) {
      res.json({ ok: true, version: Number(stateVersion) || 0 });
      return;
    }
    lastSlowVersionCheck = Date.now();
    // A document added or deleted straight in MongoDB does not touch state_meta, so notice it by
    // the document count and raise the version: every open page then reloads the shared data.
    const docCount = await collection().countDocuments({ _id: { $not: { $regex: "^(kreezbyPresence_|state_meta$)" } } });
    if (lastDocCount !== null && docCount !== lastDocCount) {
      stateVersion = Date.now();
      await collection().updateOne({ _id: "state_meta" }, { $set: { value: String(stateVersion) } }, { upsert: true });
    }
    lastDocCount = docCount;
    await reconcileDeletedAccounts(false);
    if (cache.kreezby_maintenance_users) {
      const metaRow = await collection().findOne({ _id: "state_meta" });
      if (metaRow && metaRow.value) stateVersion = Number(metaRow.value) || stateVersion;
    }
  } catch (error) { /* use the last known version */ }
  res.json({ ok: true, version: Number(stateVersion) || 0 });
});

app.get("/api/state", async (req, res) => {
  if (!databaseReady(res)) return;
  // ?since=<server time>: only the documents changed after that moment (a few small keys
  // instead of the whole shared state), so open pages pick up new data almost at once.
  const since = Number(req.query && req.query.since);
  if (Number.isFinite(since) && since > 0) {
    try {
      const serverTime = Date.now();
      const docs = await collection()
        .find({ updatedAt: { $gt: new Date(since - 3000) } }, { projection: { value: 1 } })
        .toArray();
      const items = {};
      for (const doc of docs) {
        if (typeof doc.value !== "string" || !isSharedKey(String(doc._id))) continue;
        items[doc._id] = doc.value;
        cache[doc._id] = doc.value;
      }
      res.json({ items: itemsForReader(req, items), partial: true, serverTime });
    } catch (error) {
      res.status(503).json({ ok: false, error: error.message });
    }
    return;
  }
  try {
    const serverTime = Date.now();
    await refreshCache();
    lastCacheRefresh = Date.now();
    res.json({ items: itemsForReader(req, cache), serverTime });
  } catch (error) {
    res.status(503).json({ ok: false, error: error.message });
  }
});

const RECORD_COLLECTIONS = {
  sales_orders: 1,
  sales_products: 1,
  sales_procurement: 1,
};

// Route sheets hold every retailer's records, so only admins and staff may read them.
// A retailer reads its own rows from /api/retailer-records.
function staffToken(req, res) {
  const token = retailerRecords.readToken(req);
  if (!token) {
    res.status(401).json({ ok: false, needLogin: true, error: "Please log in again to see the sales list." });
    return null;
  }
  if (token.bucket !== "admins" && token.bucket !== "staff") {
    res.status(403).json({ ok: false, error: "Only admins and staff can see every route sheet." });
    return null;
  }
  return token;
}

app.get("/api/sales-list", async (req, res) => {
  if (!databaseReady(res)) return;
  if (!staffToken(req, res)) return;
  try {
    const col = salesListCollection();
    const meta = await col.findOne({ _id: "_meta" }) || {};
    // ?from=YYYY-MM-DD (Retailer Delivery): only sheets from that date on, so it loads quickly.
    const from = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.from || "")) ? String(req.query.from) : "";
    const filter = from ? { _id: { $ne: "_meta" }, reportDate: { $gte: from } } : { _id: { $ne: "_meta" } };
    const reports = await col.find(filter).sort({ reportDate: 1, _id: 1 }).toArray();
    await retailerRecords.tagSheets(client.db(DB_NAME), reports);
    const dailyReports = reports.map((doc) => {
      const report = { ...doc, id: doc.id || String(doc._id) };
      delete report._id;
      delete report.updatedAt;
      return report;
    });
    res.json({
      importedAt: meta.importedAt || null,
      dateRange: meta.dateRange || null,
      sources: meta.sources || {},
      note: meta.note || "",
      isTestData: !!meta.isTestData,
      adminOnly: !!meta.adminOnly,
      dataset: meta.dataset || "",
      dailyReports,
      sales: [],
    });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// After a route sheet is saved or deleted: note which retailer accounts it touches, so each of
// those retailer portals reloads its own Sales List right away (other retailers are left alone).
const RETAILER_STAMP_KEY = "kreezbyRetailerSalesStamp";
async function announceRetailerSales(db, sheets) {
  try {
    const copies = (sheets || []).filter(Boolean).map((sheet) => ({
      ...sheet,
      id: String(sheet.id || sheet._id || ""),
      entries: (sheet.entries || []).map((e) => ({ ...e })),
    }));
    await retailerRecords.tagSheets(db, copies);
    const ids = new Set();
    copies.forEach((sheet) => (sheet.entries || []).forEach((e) => { if (e && e.accountId) ids.add(String(e.accountId)); }));
    if (!ids.size) return;
    let stamp = {};
    const current = await collection().findOne({ _id: RETAILER_STAMP_KEY });
    try { stamp = JSON.parse((current && current.value) || cache[RETAILER_STAMP_KEY] || "{}") || {}; } catch (error) { stamp = {}; }
    if (typeof stamp !== "object" || Array.isArray(stamp)) stamp = {};
    const at = Date.now();
    ids.forEach((id) => { stamp[id] = at; });
    const value = JSON.stringify(stamp);
    cache[RETAILER_STAMP_KEY] = value;
    cacheTouched[RETAILER_STAMP_KEY] = at;
    stateVersion = at;
    await collection().bulkWrite([
      { updateOne: { filter: { _id: RETAILER_STAMP_KEY }, update: { $set: { value, updatedAt: new Date() } }, upsert: true } },
      { updateOne: { filter: { _id: "state_meta" }, update: { $set: { value: String(stateVersion) } }, upsert: true } },
    ], { ordered: false });
  } catch (error) {
    console.error("retailer stamp: " + error.message);
  }
}

// Admin / staff save a route sheet (new or edited) straight into sales_route_sheets.
app.post("/api/route-sheets", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = staffToken(req, res);
  if (!token) return;
  try {
    const db = client.db(DB_NAME);
    const accounts = await db.collection("retailer_accounts").find({}, { projection: { name: 1 } }).toArray();
    const built = retailerRecords.buildRouteSheet(req.body || {}, accounts);
    if (built.error) return res.status(400).json({ ok: false, error: built.error });
    const col = salesListCollection();
    const existing = await col.findOne({ _id: built.doc.id });
    const doc = Object.assign({}, built.doc, {
      dataset: (existing && existing.dataset) || "system",
      updatedAt: new Date(),
      updatedBy: token.id,
    });
    if (!existing) doc.createdAt = new Date();
    await col.updateOne({ _id: doc.id }, { $set: doc }, { upsert: true });
    // Refresh each shop's own record in retailer_sales.
    try { await retailerRecords.syncRetailerSales(db); } catch (syncError) { console.error("retailer_sales: " + syncError.message); }
    const saved = await col.findOne({ _id: doc.id });
    await announceRetailerSales(db, [existing, saved]);
    await retailerRecords.tagSheets(db, [saved]);
    const report = { ...saved, id: doc.id };
    delete report._id;
    delete report.updatedAt;
    res.json({ ok: true, report });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// A retailer's own delivery & collection rows. Admins and staff may pass ?account=<id>.
// Admin / staff delete a route sheet. The deleted sheet is kept in deleted_route_sheets (so it can
// be restored by hand), and every shop's retailer_sales record is rebuilt without it.
app.post("/api/route-sheets/delete", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = staffToken(req, res);
  if (!token) return;
  const id = String((req.body && req.body.id) || "").trim();
  if (!/^[A-Za-z0-9_.-]{3,80}$/.test(id) || id === "_meta") {
    res.status(400).json({ ok: false, error: "Invalid sheet id." });
    return;
  }
  try {
    const db = client.db(DB_NAME);
    const col = salesListCollection();
    const doc = await col.findOne({ _id: id });
    if (!doc) {
      res.status(404).json({ ok: false, error: "That route sheet is already gone." });
      return;
    }
    await db.collection("deleted_route_sheets").replaceOne(
      { _id: id },
      { ...doc, deletedAt: new Date(), deletedBy: token.id },
      { upsert: true },
    );
    await col.deleteOne({ _id: id });
    try { await retailerRecords.syncRetailerSales(db); } catch (syncError) { console.error("retailer_sales: " + syncError.message); }
    await announceRetailerSales(db, [doc]);
    res.json({ ok: true, id });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// A signed-in account changes its own display name (the only profile detail customers can edit).
app.post("/api/update-name", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = retailerRecords.readToken(req);
  if (!token || !ACCOUNT_COLLECTIONS[token.bucket]) {
    res.status(401).json({ ok: false, needLogin: true, error: "Please log out and log in again." });
    return;
  }
  const name = String((req.body && req.body.name) || "").replace(/\s+/g, " ").trim();
  if (name.length < 2 || name.length > 80) return res.status(400).json({ ok: false, error: "Enter a name of 2 to 80 characters." });
  try {
    const db = client.db(DB_NAME);
    const accounts = db.collection(ACCOUNT_COLLECTIONS[token.bucket]);
    const doc = await accounts.findOne({ _id: token.id });
    if (!doc) return res.status(404).json({ ok: false, error: "Account not found." });
    await accounts.updateOne({ _id: doc._id }, { $set: { name, updatedAt: new Date() } });
    res.json({ ok: true, name });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// A signed-in customer changes their own username. It must be unique across every account group.
app.post("/api/update-username", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = retailerRecords.readToken(req);
  if (!token || token.bucket !== "customers") {
    res.status(401).json({ ok: false, needLogin: true, error: "Please log out and log in again." });
    return;
  }
  const username = String((req.body && req.body.username) || "").trim().toLowerCase();
  if (!/^[a-z0-9._]{3,30}$/.test(username)) {
    return res.status(400).json({ ok: false, error: "Username must be 3 to 30 letters, numbers, dots or underscores." });
  }
  try {
    const db = client.db(DB_NAME);
    const accounts = db.collection(ACCOUNT_COLLECTIONS.customers);
    const doc = await accounts.findOne({ _id: token.id });
    if (!doc) return res.status(404).json({ ok: false, error: "Account not found." });
    const oldUsername = String(doc.username || "");
    if (loginKey(oldUsername) === username) return res.json({ ok: true, username });
    const clash = await findAccountClash(db, { username }, String(doc._id));
    if (clash) return res.status(409).json({ ok: false, error: "That username is already taken." });
    const now = new Date();
    await accounts.updateOne({ _id: doc._id }, { $set: { username, updatedAt: now } });
    // Keep the app's shared copies in step so the new username works at login.
    try {
      const shared = await collection().find({ _id: { $in: ["kreezbyAuthCredentials", "kreezby_maintenance_users"] } }).toArray();
      const parse = (id) => {
        const row = shared.find((d) => d._id === id);
        try { return row && typeof row.value === "string" ? JSON.parse(row.value) : null; } catch (e) { return null; }
      };
      const users = parse("kreezby_maintenance_users");
      if (users && Array.isArray(users.customers)) {
        const row = users.customers.find((r) => r && [r.id, r.user_id].some((v) => v != null && String(v) === String(doc._id) || String(v) === String(doc.id)));
        if (row) { row.username = username; await persistUsersState(users); }
      }
      const creds = parse("kreezbyAuthCredentials");
      const squash = (v) => String(v == null ? "" : v).trim().toLowerCase().replace(/[\s._-]+/g, "");
      if (creds && oldUsername && creds[squash(oldUsername)]) {
        creds[squash(username)] = Object.assign({}, creds[squash(oldUsername)], { updatedAt: now.toISOString() });
        const stored = JSON.stringify(creds);
        cache.kreezbyAuthCredentials = stored;
        await collection().updateOne({ _id: "kreezbyAuthCredentials" }, { $set: { value: stored, updatedAt: now } }, { upsert: true });
      }
    } catch (syncError) { /* the account itself is already changed */ }
    res.json({ ok: true, username });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// Any signed-in account changes its own password. The current password is checked the same way
// the login checks it; the new one is saved on the account and in the app's shared account list.
app.post("/api/change-password", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = retailerRecords.readToken(req);
  if (!token || !ACCOUNT_COLLECTIONS[token.bucket]) {
    res.status(401).json({ ok: false, needLogin: true, error: "Please log out and log in again, then change your password." });
    return;
  }
  const current = String((req.body && req.body.currentPassword) || "");
  const next = String((req.body && req.body.newPassword) || "");
  if (!current) return res.status(400).json({ ok: false, error: "Enter your current password." });
  if (next.length < 6 || next.length > 64) return res.status(400).json({ ok: false, error: "The new password must be 6 to 64 characters." });
  if (/\s/.test(next)) return res.status(400).json({ ok: false, error: "The new password cannot contain spaces." });
  if (next === current) return res.status(400).json({ ok: false, error: "The new password must be different from the current one." });
  try {
    const db = client.db(DB_NAME);
    const accounts = db.collection(ACCOUNT_COLLECTIONS[token.bucket]);
    const doc = await accounts.findOne({ _id: token.id });
    if (!doc) return res.status(404).json({ ok: false, error: "Account not found." });
    const squash = (v) => String(v == null ? "" : v).trim().toLowerCase().replace(/[\s._-]+/g, "");
    const shared = await collection().find({ _id: { $in: ["kreezbyAuthCredentials", "kreezby_maintenance_users"] } }).toArray();
    const parse = (id) => {
      const row = shared.find((d) => d._id === id);
      try { return row && typeof row.value === "string" ? JSON.parse(row.value) : null; } catch (e) { return null; }
    };
    const creds = parse("kreezbyAuthCredentials") || {};
    const users = parse("kreezby_maintenance_users") || {};
    const sameAccount = (row) => row && [row.id, row.user_id, row.username, row.email].some((v) => v != null && String(v) !== "" &&
      [doc._id, doc.id, doc.user_id, doc.username, doc.email].some((w) => w != null && loginKey(w) === loginKey(v)));
    const list = Array.isArray(users[token.bucket]) ? users[token.bucket] : [];
    const appRow = list.find(sameAccount);
    const keys = [doc.username, doc.name, doc.email, doc.id, doc._id, doc.contact].map(squash).filter(Boolean);
    const credPasswords = keys.map((k) => creds[k] && creds[k].password).filter(Boolean);
    let valid = [doc.temporaryPassword, doc.password, appRow && appRow.temporaryPassword, appRow && appRow.password]
      .concat(credPasswords).some((p) => p && String(p) === current);
    const anyStored = doc.temporaryPassword || doc.password || doc.password_hash || (appRow && (appRow.temporaryPassword || appRow.password)) || credPasswords.length;
    if (!valid && !anyStored && current === "kreezby123") valid = true;
    if (!valid && doc.password_hash) {
      try { valid = await require("bcryptjs").compare(current, String(doc.password_hash)); } catch (e) { valid = false; }
    }
    if (!valid) return res.status(403).json({ ok: false, error: "Your current password is incorrect." });

    const now = new Date();
    await accounts.updateOne({ _id: doc._id }, { $set: { temporaryPassword: next, passwordChangedAt: now, updatedAt: now }, $unset: { password: "", password_hash: "" } });
    // Keep the app's shared copies in step, so no old password keeps working anywhere.
    if (appRow) {
      appRow.temporaryPassword = next;
      delete appRow.password;
      await persistUsersState(users);
    }
    let credsChanged = false;
    keys.forEach((k) => {
      if (creds[k]) { creds[k] = Object.assign({}, creds[k], { password: next, updatedAt: now.toISOString() }); credsChanged = true; }
    });
    if (credsChanged) {
      const stored = JSON.stringify(creds);
      cache.kreezbyAuthCredentials = stored;
      await collection().updateOne({ _id: "kreezbyAuthCredentials" }, { $set: { value: stored, updatedAt: now } }, { upsert: true });
    }
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// ---- Move a retailer shop to another delivery area (head admin and admin) ----
// Updates the shop's account (retailer_accounts) and the shared account list, so Retailer
// Delivery, the Delivery Schedule and Settings show it under the new area right away.
// Past deliveries stay on the route sheets of the area they were delivered in.
app.post("/api/move-retailer", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = retailerRecords.readToken(req);
  if (!token) return res.status(401).json({ ok: false, error: "Please log out and log in again, then try again." });
  if (token.bucket !== "admins") return res.status(403).json({ ok: false, error: "Only head admin and admin can move a shop." });
  const accountId = String((req.body && req.body.accountId) || "").trim();
  const shopName = String((req.body && req.body.name) || "").trim();
  const area = String((req.body && req.body.area) || "").trim().replace(/\s+/g, " ");
  if (!accountId && !shopName) return res.status(400).json({ ok: false, error: "Choose the shop to move." });
  if (!area || area.length > 60) return res.status(400).json({ ok: false, error: "Choose the area to move the shop to." });
  if (loginKey(area).replace(/[^a-z0-9]+/g, "") === "batangascity") return res.status(400).json({ ok: false, error: "Batangas City is not a delivery area." });
  try {
    const db = client.db(DB_NAME);
    const shops = db.collection("retailer_accounts");
    let doc = accountId ? await shops.findOne({ _id: accountId }) : null;
    if (!doc && shopName) {
      const all = await shops.find({}, { projection: { name: 1, area: 1 } }).toArray();
      doc = all.find((row) => retailerKey(row.name) === retailerKey(shopName)) || null;
    }
    if (!doc) return res.status(404).json({ ok: false, error: "Shop not found." });
    const from = String(doc.area || "");
    if (loginKey(from) === loginKey(area)) return res.status(400).json({ ok: false, error: doc.name + " is already in " + area + "." });
    const now = new Date();
    await shops.updateOne({ _id: doc._id }, { $set: { area, areaMovedAt: now, updatedAt: now } });

    // The shared account list (Settings › Retailers and every portal's copy).
    const latest = await collection().findOne({ _id: "kreezby_maintenance_users" });
    let users = {};
    try { users = latest && typeof latest.value === "string" ? JSON.parse(latest.value) : {}; } catch (e) { users = {}; }
    const list = Array.isArray(users.retailers) ? users.retailers : [];
    const ids = [doc._id, doc.id, doc.user_id, doc.username].filter((v) => v != null && String(v) !== "").map(loginKey);
    const row = list.find((r) => r && [r.id, r.user_id, r.username].some((v) => v != null && ids.indexOf(loginKey(v)) >= 0)) ||
      list.find((r) => r && retailerKey(r.name) === retailerKey(doc.name));
    if (row) {
      row.area = area;
      await persistUsersState(users);
    }
    await writeSecurityLog(token, "shop_moved", req, { shop: String(doc.name || ""), fromArea: from, toArea: area });
    res.json({ ok: true, id: String(doc._id), name: doc.name, from, to: area });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// ---- Session lock (screen lock after inactivity) ----
// A signed-in page locks itself when nobody uses it; it opens again only with that account's
// password, checked here. Too many wrong passwords block the account's unlock for a while,
// and every lock, unlock and failed try is written to the security_log collection.
const UNLOCK_MAX_TRIES = 5;
const UNLOCK_BLOCK_MS = 15 * 60 * 1000;
const unlockTries = new Map();

async function writeSecurityLog(token, event, req, extra) {
  try {
    if (!mongoReady) return;
    await client.db(DB_NAME).collection("security_log").insertOne(Object.assign({
      at: new Date(),
      event: String(event || "").slice(0, 40),
      accountId: token ? String(token.id) : "",
      bucket: token ? String(token.bucket) : "",
      ip: String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "").split(",")[0].trim(),
      userAgent: String(req.headers["user-agent"] || "").slice(0, 200),
    }, extra || {}));
  } catch (error) {
    console.error("Security log: " + error.message);
  }
}

// Same password rules as log in and change password.
async function accountPasswordMatches(token, password) {
  const db = client.db(DB_NAME);
  const accounts = db.collection(ACCOUNT_COLLECTIONS[token.bucket]);
  const doc = await accounts.findOne({ _id: token.id });
  if (!doc) return { found: false, valid: false };
  if (doc.active === false) return { found: true, valid: false, deactivated: true };
  const squash = (v) => String(v == null ? "" : v).trim().toLowerCase().replace(/[\s._-]+/g, "");
  const shared = await collection().find({ _id: { $in: ["kreezbyAuthCredentials", "kreezby_maintenance_users"] } }).toArray();
  const parse = (id) => {
    const row = shared.find((d) => d._id === id);
    try { return row && typeof row.value === "string" ? JSON.parse(row.value) : null; } catch (e) { return null; }
  };
  const creds = parse("kreezbyAuthCredentials") || {};
  const users = parse("kreezby_maintenance_users") || {};
  const sameAccount = (row) => row && [row.id, row.user_id, row.username, row.email].some((v) => v != null && String(v) !== "" &&
    [doc._id, doc.id, doc.user_id, doc.username, doc.email].some((w) => w != null && loginKey(w) === loginKey(v)));
  const list = Array.isArray(users[token.bucket]) ? users[token.bucket] : [];
  const appRow = list.find(sameAccount);
  const keys = [doc.username, doc.name, doc.email, doc.id, doc._id, doc.contact].map(squash).filter(Boolean);
  const credPasswords = keys.map((k) => creds[k] && creds[k].password).filter(Boolean);
  let valid = [doc.temporaryPassword, doc.password, appRow && appRow.temporaryPassword, appRow && appRow.password]
    .concat(credPasswords).some((p) => p && String(p) === password);
  const anyStored = doc.temporaryPassword || doc.password || doc.password_hash || (appRow && (appRow.temporaryPassword || appRow.password)) || credPasswords.length;
  if (!valid && !anyStored && password === "kreezby123") valid = true;
  if (!valid && doc.password_hash) {
    try { valid = await require("bcryptjs").compare(password, String(doc.password_hash)); } catch (e) { valid = false; }
  }
  return { found: true, valid };
}

app.post("/api/unlock-session", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = retailerRecords.readToken(req);
  if (!token || !ACCOUNT_COLLECTIONS[token.bucket]) {
    res.status(401).json({ ok: false, needLogin: true, error: "Your sign-in has ended. Please log in again." });
    return;
  }
  const key = token.bucket + ":" + token.id;
  const now = Date.now();
  const entry = unlockTries.get(key) || { count: 0, until: 0 };
  if (entry.until > now) {
    res.status(429).json({ ok: false, needLogin: true, error: "Too many wrong passwords. Please log in again." });
    return;
  }
  const password = String((req.body && req.body.password) || "");
  if (!password) return res.status(400).json({ ok: false, error: "Enter your password." });
  try {
    const result = await accountPasswordMatches(token, password);
    if (!result.found || result.deactivated) {
      await writeSecurityLog(token, "unlock_refused", req);
      res.status(403).json({ ok: false, needLogin: true, error: result.deactivated ? "This account is deactivated." : "Account not found." });
      return;
    }
    if (!result.valid) {
      entry.count += 1;
      const left = Math.max(0, UNLOCK_MAX_TRIES - entry.count);
      if (!left) { entry.until = now + UNLOCK_BLOCK_MS; entry.count = 0; }
      unlockTries.set(key, entry);
      await writeSecurityLog(token, "unlock_failed", req, { triesLeft: left });
      res.status(403).json({ ok: false, triesLeft: left, needLogin: !left, error: left ? "Wrong password." : "Too many wrong passwords. Please log in again." });
      return;
    }
    unlockTries.delete(key);
    await writeSecurityLog(token, "unlocked", req);
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// The page reports when it locks itself or ends the sign-in, for the security log.
app.post("/api/security-event", async (req, res) => {
  const token = retailerRecords.readToken(req);
  const allowed = ["locked", "locked_manual", "auto_logout", "logout_from_lock"];
  const event = String((req.body && req.body.event) || "");
  if (!token || allowed.indexOf(event) < 0) return res.status(400).json({ ok: false });
  await writeSecurityLog(token, event, req, { minutesIdle: Number(req.body.minutesIdle) || 0 });
  res.json({ ok: true });
});

app.get("/api/retailer-records", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = retailerRecords.readToken(req);
  if (!token) {
    res.status(401).json({ ok: false, needLogin: true, error: "Please log in again to see your records." });
    return;
  }
  let accountId = token.id;
  if (token.bucket === "admins" || token.bucket === "staff") {
    accountId = String(req.query.account || "");
  } else if (token.bucket !== "retailers") {
    res.status(403).json({ ok: false, error: "Only retailer accounts have route-sheet records." });
    return;
  }
  try {
    const db = client.db(DB_NAME);
    if (!accountId) {
      // Admin/staff without an account: list the retailer accounts and how many rows each has.
      const accounts = await db.collection("retailer_accounts").find({}, { projection: { name: 1, area: 1, usualPcs: 1, retailerPrice: 1 } }).sort({ name: 1 }).toArray();
      // ?lite=1 (Retailer Delivery): just the shops, without reading every route sheet for row counts.
      if (req.query.lite) {
        res.json({ ok: true, accounts: accounts.map((a) => ({ id: String(a._id), name: a.name || String(a._id), area: a.area || "", usualPcs: Number(a.usualPcs) || 0, retailerPrice: Number(a.retailerPrice) || 0 })) });
        return;
      }
      const reports = await salesListCollection().find({ _id: { $ne: "_meta" }, isTestData: { $ne: true } }).toArray();
      await retailerRecords.tagSheets(db, reports);
      const counts = {};
      reports.forEach((sheet) => (sheet.entries || []).forEach((e) => { if (e.accountId) counts[e.accountId] = (counts[e.accountId] || 0) + 1; }));
      res.json({ ok: true, accounts: accounts.map((a) => ({ id: String(a._id), name: a.name || String(a._id), area: a.area || "", usualPcs: Number(a.usualPcs) || 0, retailerPrice: Number(a.retailerPrice) || 0, rows: counts[String(a._id)] || 0 })) });
      return;
    }
    const account = await db.collection("retailer_accounts").findOne({ _id: accountId }, { projection: { name: 1, area: 1 } });
    if (!account) {
      res.status(404).json({ ok: false, error: "Retailer account not found." });
      return;
    }
    const sales = await retailerRecords.recordsForAccount(db, accountId);
    res.json({ ok: true, account: { id: accountId, name: account.name || accountId, area: account.area || "" }, sales });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

function publicAccount(doc) {
  const row = { ...doc, id: doc.id || String(doc._id) };
  delete row._id;
  delete row.updatedAt;
  delete row.syncedFromApp;
  delete row.password;
  delete row.password_hash;
  return row;
}

app.get("/api/accounts", async (req, res) => {
  if (!databaseReady(res)) return;
  try {
    const db = client.db(DB_NAME);
    const accounts = {};
    try { await reconcileDeletedAccounts(true); } catch (error) { console.error("Account reconcile failed: " + error.message); }
    const token = requestToken(req);
    const everyone = token && (token.bucket === "admins" || token.bucket === "staff");
    for (const [bucket, collectionName] of Object.entries(ACCOUNT_COLLECTIONS)) {
      if (bucket === "wholesalers") continue;
      if (!everyone && bucket !== token.bucket) continue;
      const filter = everyone ? {} : { _id: token.id };
      const docs = await db.collection(collectionName).find(filter).toArray();
      accounts[bucket] = docs.map(publicAccount);
    }
    res.json({ ok: true, accounts, onlyOwn: !everyone });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

app.post("/api/accounts", async (req, res) => {
  if (!databaseReady(res)) return;
  try {
    const bucket = String((req.body && req.body.bucket) || "customers").trim();
    const token = requestToken(req);
    if (bucket === "customers" && (!token || token.bucket === "customers")) {
      const acc = (req.body && req.body.account) || {};
      const id = String(acc.id || acc.user_id || "").trim();
      const existing = id ? await client.db(DB_NAME).collection(ACCOUNT_COLLECTIONS.customers).findOne({ _id: id }) : null;
      if (existing && (!token || String(token.id) !== id)) {
        res.status(403).json({ ok: false, error: "You can only change your own account." });
        return;
      }
    }
    const result = await upsertAccountRecord(bucket, req.body && req.body.account);
    res.status(result.status).json(result.body);
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

function loginKey(value) {
  return String(value == null ? "" : value).trim().toLowerCase();
}

// ---- Sign-in protection: 5 wrong passwords for one account from one address pause it 15 minutes.
const loginFailures = new Map();
const LOGIN_MAX_FAILS = 5;
const LOGIN_BLOCK_MS = 15 * 60 * 1000;
function clientIp(req) {
  return String((req.headers && req.headers["x-forwarded-for"]) || req.ip || "").split(",")[0].trim().slice(0, 64);
}
function loginFailureKey(req, identity) { return clientIp(req) + "|" + identity; }
function loginBlockedFor(req, identity) {
  const row = loginFailures.get(loginFailureKey(req, identity));
  if (!row || !row.until) return 0;
  const left = row.until - Date.now();
  if (left <= 0) { loginFailures.delete(loginFailureKey(req, identity)); return 0; }
  return left;
}
function noteLoginFailure(req, identity) {
  const key = loginFailureKey(req, identity);
  const row = loginFailures.get(key) || { count: 0, until: 0 };
  row.count += 1;
  if (row.count >= LOGIN_MAX_FAILS) { row.until = Date.now() + LOGIN_BLOCK_MS; row.count = 0; }
  loginFailures.set(key, row);
  return row.until ? 0 : LOGIN_MAX_FAILS - row.count;
}

app.post("/api/login", async (req, res) => {
  if (!mongoReady) {
    res.status(503).json({ ok: false, error: "Database is reconnecting." });
    return;
  }
  try {
    const identity = loginKey(req.body && req.body.identity);
    const password = String((req.body && req.body.password) || "");
    if (!identity || !password) {
      res.status(400).json({ ok: false, error: "identity and password required" });
      return;
    }
    if (identity.length > 120 || password.length > 128) {
      res.status(400).json({ ok: false, error: "Sign-in details are too long." });
      return;
    }
    const blockedFor = loginBlockedFor(req, identity);
    if (blockedFor > 0) {
      res.status(429).json({ ok: false, error: "Too many wrong passwords. Try again in " + Math.ceil(blockedFor / 60000) + " minute(s)." });
      return;
    }
    const db = client.db(DB_NAME);
    // Same matching as the browser login: "marcela_admin", "marcela-admin" and "Marcela Admin" are one
    // account, and the shortcut names the login page accepts (e.g. "headadmin") point to their account.
    const squash = (v) => String(v == null ? "" : v).trim().toLowerCase().replace(/[\s._-]+/g, "");
    const LOGIN_SHORTCUTS = { headadmin: "admin-owner", marcelaadmin: "admin-owner", brentadmin: "admin-ops", ailoreadmin: "admin-marketing" };
    const squashed = squash(identity);
    const shortcutId = LOGIN_SHORTCUTS[squashed] || "";
    // Passwords changed in the app are kept in the shared state; the login page checks them too.
    const sharedDocs = await collection().find({ _id: { $in: ["kreezbyAuthCredentials", "kreezby_maintenance_users"] } }).toArray();
    const sharedValue = (id) => {
      const row = sharedDocs.find((d) => d._id === id);
      try { return row && typeof row.value === "string" ? JSON.parse(row.value) : null; } catch (e) { return null; }
    };
    const savedCreds = sharedValue("kreezbyAuthCredentials") || {};
    const appUsers = sharedValue("kreezby_maintenance_users") || {};
    // Staff and admins first so an internal account is never taken for a customer.
    const order = ["admins", "staff", "retailers", "customers"];
    for (const bucket of order) {
      const docs = await db.collection(ACCOUNT_COLLECTIONS[bucket]).find({}).toArray();
      const fields = (row) => [row.email, row.username, row.user_id, row.id, row._id, row.name, row.contact];
      const doc = docs.find((row) => fields(row).some((field) => field != null && loginKey(field) === identity)) ||
        docs.find((row) => shortcutId && (String(row._id) === shortcutId || String(row.id) === shortcutId)) ||
        docs.find((row) => fields(row).some((field) => field != null && squash(field) && squash(field) === squashed));
      if (!doc) continue;
      if (doc.active === false) {
        res.status(403).json({ ok: false, error: "This account is deactivated." });
        return;
      }
      let valid = false;
      const appRow = (Array.isArray(appUsers[bucket]) ? appUsers[bucket] : []).find((row) =>
        row && [row.id, row.user_id, row.username, row.email].some((v) => v != null && String(v) !== "" &&
          [doc._id, doc.id, doc.user_id, doc.username, doc.email].some((w) => w != null && loginKey(w) === loginKey(v))));
      const credPasswords = [identity, doc.username, doc.name, doc.email, doc.id].map(squash).filter(Boolean)
        .map((k) => savedCreds[k] && savedCreds[k].password).filter(Boolean);
      for (const field of [doc.temporaryPassword, doc.password, appRow && appRow.temporaryPassword, appRow && appRow.password].concat(credPasswords)) {
        if (field && String(field) === password) valid = true;
      }
      // Accounts with no stored password use the shared starter password, as the browser login does.
      const anyStored = doc.temporaryPassword || doc.password || doc.password_hash || (appRow && (appRow.temporaryPassword || appRow.password)) || credPasswords.length;
      if (!valid && !anyStored && password === "kreezby123") {
        valid = true;
      }
      if (!valid && doc.password_hash) {
        try {
          valid = await require("bcryptjs").compare(password, String(doc.password_hash));
        } catch (error) {
          valid = false;
        }
      }
      if (!valid) {
        const left = noteLoginFailure(req, identity);
        await writeSecurityLog({ id: String(doc._id), bucket }, left > 0 ? "login_failed" : "login_paused", req);
        res.status(401).json({ ok: false, error: left > 0 ? "Invalid password. " + left + " " + (left === 1 ? "try" : "tries") + " left before this sign-in is paused for 15 minutes." : "Invalid password." });
        return;
      }
      loginFailures.delete(loginFailureKey(req, identity));
      const key = [doc.username, doc.user_id, doc.id, doc._id].map(loginKey).join("|");
      const isHead = /(^|\|)(marcela_admin|admin-owner)(\||$)/.test(key) ||
        (!/(^|\|)(brent_admin|admin-ops|ailore_admin|ailore)(\||$)/.test(key) && loginKey(doc.role) === "owner");
      const accountType = bucket === "admins"
        ? (isHead ? "Head Administrator" : "Administrator")
        : { staff: "Staff", retailers: "Retailer", customers: "Customer" }[bucket];
      res.json({
        ok: true,
        account: { ...publicAccount(doc), accountType },
        bucket,
        // Proves who signed in; pages send it back to read their own records.
        token: retailerRecords.issueToken(String(doc._id), bucket),
      });
      return;
    }
    res.status(404).json({ ok: false, error: "Account not found." });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// Every transaction the app saves is also stored one-document-per-record in its own collection.
const { mirrorTransactions } = require("./scripts/transaction-mirror.js");

async function mirrorSaved(items) {
  try {
    await mirrorTransactions(client.db(DB_NAME), items);
  } catch (error) {
    console.error("Transaction mirror failed: " + error.message);
  }
}

// Fill the transaction collections once from what is already saved.
let mirrorBackfillStarted = false;
async function backfillMirrors() {
  if (mirrorBackfillStarted) return;
  mirrorBackfillStarted = true;
  try {
    const state = client.db(DB_NAME).collection("app_state");
    if (await state.findOne({ _id: "mirror_backfill_20261023_done" })) return;
    await mirrorTransactions(client.db(DB_NAME), Object.assign({}, cache));
    await state.updateOne({ _id: "mirror_backfill_20261023_done" }, { $set: { at: new Date() } }, { upsert: true });
    console.log("Transaction collections filled from saved data.");
  } catch (error) {
    mirrorBackfillStarted = false;
    console.error("Transaction backfill failed: " + error.message);
  }
}

function mergeByField(raw, record, field) {
  let list = [];
  try { list = JSON.parse(raw || "[]"); } catch (error) { list = []; }
  if (!Array.isArray(list)) list = [];
  const id = String(record[field] || "");
  const at = list.findIndex((row) => row && String(row[field] || "") === id);
  if (at >= 0) list[at] = Object.assign({}, list[at], record);
  else list.push(record);
  return JSON.stringify(list);
}

// Checkout posts each new order here and waits for it, so an order is in MongoDB
// (customer_orders, sales_orders, receipts and the shared order list) before the page moves on.
app.post("/api/customer-orders", async (req, res) => {
  if (!databaseReady(res)) return;
  try {
    const order = req.body && req.body.order;
    const receipt = req.body && req.body.receipt;
    if (!order || typeof order !== "object" || !customerOrderId(order)) {
      res.status(400).json({ ok: false, error: "order with orderNumber required" });
      return;
    }
    // Merge into the latest lists in MongoDB, so an order placed on another server instance
    // a moment ago is never written over.
    const fresh = await collection().find({ _id: { $in: ["kreezbyOrders", "kreezbyCustomerReceipts", "kreezbyOwnerReceipts"] } }).toArray();
    fresh.forEach((doc) => { if (typeof doc.value === "string") cache[doc._id] = doc.value; });
    const items = { kreezbyOrders: mergeByField(cache.kreezbyOrders, order, "orderNumber") };
    if (receipt && typeof receipt === "object" && receipt.receiptNumber) {
      items.kreezbyCustomerReceipts = mergeByField(cache.kreezbyCustomerReceipts, receipt, "receiptNumber");
      items.kreezbyOwnerReceipts = mergeByField(cache.kreezbyOwnerReceipts, receipt, "receiptNumber");
    }
    const now = new Date();
    const ops = Object.entries(items).map(([key, value]) => {
      cache[key] = value;
    cacheTouched[key] = Date.now();
      return { updateOne: { filter: { _id: key }, update: { $set: { value, updatedAt: now } }, upsert: true } };
    });
    stateVersion = Date.now();
    ops.push({ updateOne: { filter: { _id: "state_meta" }, update: { $set: { value: String(stateVersion) } }, upsert: true } });
    await collection().bulkWrite(ops, { ordered: false });
    await syncCustomerOrderDocs([order]);
    await mirrorSaved(items);
    res.json({ ok: true, orderNumber: customerOrderId(order) });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// A customer asks for a refund on a delivered order. The request is added to Order Errors
// (Customer Returns) and the order is marked, both in one save so neither list is overwritten.
app.post("/api/customer-refund", async (req, res) => {
  if (!databaseReady(res)) return;
  try {
    const orderNumber = String((req.body && req.body.orderNumber) || "").trim();
    const reason = String((req.body && req.body.reason) || "").trim().slice(0, 500);
    if (!orderNumber || !reason) {
      res.status(400).json({ ok: false, error: "Add the reason for the refund." });
      return;
    }
    // Read the latest copies from MongoDB (this server's cache can be a moment behind).
    const fresh = await collection().find({ _id: { $in: ["kreezbyOrders", "kreezby-bo-orders-v1"] } }).toArray();
    fresh.forEach((doc) => { if (typeof doc.value === "string") cache[doc._id] = doc.value; });
    let orders = [];
    try { orders = JSON.parse(cache.kreezbyOrders || "[]"); } catch (error) { orders = []; }
    if (!Array.isArray(orders)) orders = [];
    const order = orders.find((o) => o && String(o.orderNumber || "") === orderNumber);
    if (!order) { res.status(404).json({ ok: false, error: "Order not found." }); return; }
    if (String(order.status || "") !== "Completed") {
      res.status(400).json({ ok: false, error: "A refund can be requested once the order is delivered." });
      return;
    }
    if (order.refundRequest && order.refundRequest.code) {
      res.status(409).json({ ok: false, error: "A refund was already requested for this order.", refundRequest: order.refundRequest });
      return;
    }
    let returns = {};
    try { returns = JSON.parse(cache["kreezby-bo-orders-v1"] || "{}") || {}; } catch (error) { returns = {}; }
    if (typeof returns !== "object" || Array.isArray(returns)) returns = {};
    const nowIso = new Date().toISOString();
    const today = new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
    const code = "RF-" + orderNumber;
    const shipping = order.shippingInfo || {};
    const items = Object.values(order.items || {}).map((it) => {
      const qty = Number(it && it.qty) || 0;
      const cost = Number(it && it.cost) || 0;
      return { name: (it && it.name) || "Item", unit: "pcs", ordered: qty, received: qty, backOrder: qty, cost, total: Math.round(cost * qty * 100) / 100 };
    });
    returns[code] = {
      code,
      poCode: order.poCode || orderNumber,
      orderNumber,
      dateCreated: today,
      requestedAt: nowIso,
      entity: shipping.fullName || order.customerName || "Customer",
      entityType: "customer",
      accountType: "Regular Customer",
      customerId: order.customerId || "",
      customerEmail: order.customerEmail || shipping.email || "",
      supplier: "Kreezby Bakeshop",
      expectedDelivery: "",
      status: "PENDING",
      statusClass: "pending",
      source: "customer-refund",
      remarks: "Refund request: " + reason,
      items,
    };
    order.refundRequest = { code, reason, requestedAt: nowIso, status: "PENDING", statusClass: "pending" };
    const saved = { kreezbyOrders: JSON.stringify(orders), "kreezby-bo-orders-v1": JSON.stringify(returns) };
    const now = new Date();
    const ops = Object.entries(saved).map(([key, value]) => {
      cache[key] = value;
      cacheTouched[key] = Date.now();
      return { updateOne: { filter: { _id: key }, update: { $set: { value, updatedAt: now } }, upsert: true } };
    });
    stateVersion = Date.now();
    ops.push({ updateOne: { filter: { _id: "state_meta" }, update: { $set: { value: String(stateVersion) } }, upsert: true } });
    await collection().bulkWrite(ops, { ordered: false });
    await syncCustomerOrderDocs([order]);
    await mirrorSaved(saved);
    res.json({ ok: true, refundRequest: order.refundRequest, record: returns[code] });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

app.get("/api/customer-orders", async (req, res) => {
  if (!databaseReady(res)) return;
  try {
    const token = requestToken(req);
    const filter = { inApp: { $ne: false } };
    if (token && token.bucket !== "admins" && token.bucket !== "staff") filter.customerId = String(token.id);
    const records = await client.db(DB_NAME).collection("customer_orders").find(filter).sort({ date: -1 }).toArray();
    const orders = records.map((doc) => {
      const order = { ...doc, orderNumber: doc.orderNumber || String(doc._id) };
      delete order._id;
      delete order.updatedAt;
      return order;
    });
    res.json({ ok: true, orders });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

app.get("/api/records/:name", async (req, res) => {
  if (!databaseReady(res)) return;
  const name = String(req.params.name || "");
  if (!RECORD_COLLECTIONS[name]) {
    res.status(404).json({ ok: false, error: "Unknown record set." });
    return;
  }
  const limit = Math.min(Math.max(Number(req.query.limit) || 80, 1), 200);
  try {
    const records = await client.db(DB_NAME).collection(name).find({}).limit(limit).toArray();
    res.json({ ok: true, records });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

const PERMISSION_FILE = path.join(SITE_ROOT, "data", "shared-permissions.json");
const PERMISSION_KEYS = ["kreezby_staff_permissions", "kreezby_admin_permissions"];

function readPermissionFile() {
  try {
    const parsed = JSON.parse(fs.readFileSync(PERMISSION_FILE, "utf8"));
    return parsed && typeof parsed === "object" ? parsed : { updatedAt: 0 };
  } catch (error) {
    return { updatedAt: 0 };
  }
}

function writePermissionFile(items) {
  const current = readPermissionFile();
  const next = { updatedAt: Date.now() };
  let wrote = false;
  PERMISSION_KEYS.forEach((key) => {
    if (typeof items[key] === "string") {
      next[key] = items[key];
      wrote = true;
    } else if (typeof current[key] === "string") {
      next[key] = current[key];
    }
    if (typeof next[key] === "string") cache[key] = next[key];
  });
  if (!wrote) return null;
  try {
    fs.mkdirSync(path.dirname(PERMISSION_FILE), { recursive: true });
    fs.writeFileSync(PERMISSION_FILE, JSON.stringify(next, null, 2));
  } catch (error) {
    /* Read-only hosting (Vercel): the copy in MongoDB below is the shared one. */
  }
  return next;
}

async function storePermissionsInMongo(doc) {
  if (!mongoReady) return;
  const col = collection();
  const ops = PERMISSION_KEYS
    .filter((key) => typeof doc[key] === "string")
    .map((key) => ({
      updateOne: { filter: { _id: key }, update: { $set: { value: doc[key] } }, upsert: true },
    }));
  ops.push({
    updateOne: {
      filter: { _id: "shared_permissions_doc" },
      update: { $set: { value: JSON.stringify(doc) } },
      upsert: true,
    },
  });
  await col.bulkWrite(ops, { ordered: false });
}

async function currentPermissionDoc() {
  if (mongoReady) {
    try {
      const row = await collection().findOne({ _id: "shared_permissions_doc" });
      if (row && typeof row.value === "string") {
        const parsed = JSON.parse(row.value);
        if (parsed && typeof parsed.updatedAt === "number") return parsed;
      }
    } catch (error) { /* fall back to the file */ }
  }
  return readPermissionFile();
}

app.get("/api/permissions", async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json(await currentPermissionDoc());
});

app.post("/api/permissions", async (req, res) => {
  const items = req.body && typeof req.body === "object" ? req.body : {};
  const saved = writePermissionFile(items);
  if (!saved) {
    res.status(400).json({ ok: false, error: "Permission records are required." });
    return;
  }
  try {
    await storePermissionsInMongo(saved);
  } catch (error) {
    console.error("Could not store permissions in MongoDB. " + error.message);
  }
  res.json({ ok: true, updatedAt: saved.updatedAt });
});

// A paid order may be taken out of stock by whichever admin/staff page notices it first. This
// hands out exactly one claim per order, so two open pages can never deduct it twice.
app.post("/api/stock/claim-order", async (req, res) => {
  if (!databaseReady(res)) return;
  const orderNumber = String((req.body && req.body.orderNumber) || "").trim().slice(0, 80);
  if (!orderNumber) {
    res.status(400).json({ ok: false, error: "orderNumber required" });
    return;
  }
  try {
    await client.db(DB_NAME).collection("stock_deduction_claims").insertOne({ _id: orderNumber, at: new Date() });
    res.json({ ok: true, claimed: true });
  } catch (error) {
    if (error && error.code === 11000) res.json({ ok: true, claimed: false });
    else res.status(500).json({ ok: false, error: error.message });
  }
});

app.post("/api/state", async (req, res) => {
  if (!databaseReady(res)) return;
  try {
    const items = req.body && req.body.items;
    if (!items || typeof items !== "object" || Array.isArray(items)) {
      res.status(400).json({ ok: false, error: "items object required" });
      return;
    }

    const writer = requestToken(req);
    const refused = [];
    Object.keys(items).forEach((key) => {
      if (!writer && !GUEST_WRITABLE_RE.test(key)) { refused.push(key); delete items[key]; return; }
      if (typeof items[key] === "string" && (!writer || writer.bucket !== "admins")) items[key] = restoreSecrets(key, items[key], writer);
    });
    if (refused.length) await writeSecurityLog(null, "guest_write_refused", req, { keys: refused.slice(0, 20) });
    const ops = [];
    const bases = req.body && req.body.bases && typeof req.body.bases === "object" ? req.body.bases : {};
    const stockKeys = [];
    let meaningful = false;
    for (const [key, value] of Object.entries(items)) {
      if (!isSharedKey(key)) continue;
      if (Object.prototype.hasOwnProperty.call(STOCK_MERGE_KEYS, key) && value != null && typeof bases[key] === "string") {
        stockKeys.push(key);
        meaningful = true;
        continue;
      }
      if (!isEphemeralKey(key)) meaningful = true;
      else if (key.indexOf("kreezbyPresence_") === 0 && value != null) {
        // Someone signing in, going offline, or coming back: tell every page now (not every heartbeat).
        try {
          const next = JSON.parse(String(value));
          const prev = cache[key] ? JSON.parse(cache[key]) : null;
          const wasOnline = prev && !prev.offline && Date.now() - Number(prev.lastSeen || 0) < 150000;
          const isOnline = next && !next.offline;
          if (Boolean(wasOnline) !== Boolean(isOnline)) meaningful = true;
        } catch (e) { /* not JSON: ignore */ }
      }
      if (value == null) {
        ops.push({ deleteOne: { filter: { _id: key } } });
        delete cache[key];
        cacheTouched[key] = Date.now();
        continue;
      }
      const stored = keepStoredRecords(key, dropRetired(key, String(value)));
      if (stored !== String(value)) items[key] = stored;
      if (stored.length > 12 * 1024 * 1024) continue;
      ops.push({
        updateOne: {
          filter: { _id: key },
          update: { $set: { value: stored, updatedAt: new Date() } },
          upsert: true,
        },
      });
      cache[key] = stored;
      cacheTouched[key] = Date.now();
    }

    const merged = {};
    for (const key of stockKeys) {
      const sent = String(items[key]);
      const finalText = await saveStockKey(key, sent, bases[key]);
      items[key] = finalText;
      if (finalText !== sent) merged[key] = finalText;
    }
    writePermissionFile(items);
    if (ops.length || stockKeys.length) {
      if (meaningful) {
        stateVersion = Date.now();
        ops.push({
          updateOne: {
            filter: { _id: "state_meta" },
            update: { $set: { value: String(stateVersion) } },
            upsert: true,
          },
        });
      }
      await collection().bulkWrite(ops, { ordered: false });
    }
    if (typeof items.kreezby_maintenance_users === "string") {
      await syncAccountCollections(items.kreezby_maintenance_users);
    }
    if (typeof items.kreezbyOrders === "string") {
      await syncCustomerOrderDocs(readCachedCustomerOrders());
    }
    await mirrorSaved(items);
    res.json({ ok: true, merged: itemsForReader(req, merged), refused });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini";
const insightLastCall = new Map();

function cleanInsightText(value, max) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, max);
}

function insightNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.round(number * 10) / 10 : null;
}

function insightAllowed(ip) {
  const now = Date.now();
  const last = insightLastCall.get(ip) || 0;
  if (now - last < 8000) return false;
  insightLastCall.set(ip, now);
  return true;
}

// Stay under Vercel's function limit: connect, call OpenAI, then still have time to reply.
const OPENAI_TIMEOUT_MS = SERVERLESS ? 12000 : 20000;

function openaiKey() {
  return String(process.env.OPENAI_API_KEY || "").replace(/^\uFEFF/, "").trim();
}

function completionText(payload) {
  const message = payload && payload.choices && payload.choices[0] && payload.choices[0].message;
  if (!message) return "";
  const content = message.content;
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) {
    return content.map((part) => (part && typeof part.text === "string" ? part.text : "")).join("").trim();
  }
  return "";
}

// Node's global fetch follows IPv6 first and can sit there until Vercel times the
// function out, which the browser sees as no response. Force IPv4.
function postOpenAI(apiKey, body, timeoutMs) {
  const data = Buffer.from(JSON.stringify(body));
  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: "api.openai.com",
      path: "/v1/chat/completions",
      method: "POST",
      family: 4,
      headers: {
        Authorization: "Bearer " + apiKey,
        "Content-Type": "application/json",
        "Content-Length": data.length,
      },
      timeout: timeoutMs,
    }, (response) => {
      const chunks = [];
      response.on("data", (chunk) => chunks.push(chunk));
      response.on("end", () => {
        let payload = {};
        try { payload = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch (error) { payload = {}; }
        resolve({ status: response.statusCode || 0, payload });
      });
    });
    req.on("timeout", () => req.destroy(Object.assign(new Error("OpenAI timed out"), { status: 504 })));
    req.on("error", reject);
    req.write(data);
    req.end();
  });
}

function openAiFailure(error, feature) {
  const code = error && error.code;
  if (code === "credit_balance_exhausted" || code === "insufficient_quota") {
    return { status: 402, error: "The GPT-4o mini account has no credits left. Add credits in OpenAI billing, then refresh this note." };
  }
  if (error && error.status === 401) {
    return { status: 401, error: "The " + feature + " service rejected the API key. Check OPENAI_API_KEY in the Vercel project settings." };
  }
  if (error && (error.status === 504 || /timed out/i.test(String(error.message || "")))) {
    return { status: 504, error: "OpenAI did not answer in time. Try again in a moment." };
  }
  return { status: error && error.status >= 400 && error.status < 500 ? error.status : 502, error: "The " + feature + " could not be written just now." };
}

async function writeOwnerNote(apiKey, snapshot, instructions, maxTokens) {
  const limit = maxTokens || 320;
  const reasoning = /^(o\d|gpt-5)/i.test(OPENAI_MODEL);
  const body = {
    model: OPENAI_MODEL,
    messages: [
      { role: "system", content: instructions },
      { role: "user", content: JSON.stringify(snapshot) },
    ],
  };
  if (!reasoning) body.temperature = 0;
  body[reasoning ? "max_completion_tokens" : "max_tokens"] = limit;

  let result = await postOpenAI(apiKey, body, OPENAI_TIMEOUT_MS);
  const errMsg = result.payload && result.payload.error ? String(result.payload.error.message || "") : "";
  if (result.status === 400 && /max_tokens|max_completion_tokens|temperature/i.test(errMsg)) {
    delete body.temperature;
    delete body.max_tokens;
    body.max_completion_tokens = limit;
    result = await postOpenAI(apiKey, body, OPENAI_TIMEOUT_MS);
  }
  if (result.status < 200 || result.status >= 300) {
    const error = new Error("OpenAI request failed");
    error.status = result.status || 502;
    error.code = result.payload && result.payload.error ? result.payload.error.code : "";
    throw error;
  }
  const text = completionText(result.payload);
  if (!text) {
    const error = new Error("Empty insight");
    error.status = 502;
    throw error;
  }
  return text;
}

function insightIncludesNumber(text, value) {
  if (value == null) return true;
  const digits = String(value).replace(/\.0$/, "");
  return new RegExp("(^|[^0-9])" + digits.replace(".", "\\.") + "([^0-9]|$)").test(String(text || ""));
}

// ---------- Management Insight: the Interpretation is written by GPT ----------
// The page works out sales, stock and situations from the shop's records and sends them here.
// GPT writes the owner's interpretation from those figures only.
function cleanInsightData(value, depth) {
  if (depth > 5) return null;
  if (typeof value === "number") return Number.isFinite(value) ? Math.round(value * 100) / 100 : null;
  if (typeof value === "string") return cleanInsightText(value, 400);
  if (typeof value === "boolean" || value == null) return value == null ? null : value;
  if (Array.isArray(value)) return value.slice(0, 40).map((item) => cleanInsightData(item, depth + 1));
  if (typeof value === "object") {
    const out = {};
    Object.keys(value).slice(0, 40).forEach((key) => { out[cleanInsightText(key, 40)] = cleanInsightData(value[key], depth + 1); });
    return out;
  }
  return null;
}

function numbersInText(text) {
  return (String(text || "").match(/\d[\d,]*(?:\.\d+)?/g) || [])
    .map((raw) => Number(raw.replace(/,/g, "")))
    .filter((value) => Number.isFinite(value));
}

function collectNumbers(value, out, key) {
  if (key === "asOf") return out;
  if (typeof value === "number") out.push(value);
  else if (typeof value === "string") numbersInText(value).forEach((n) => out.push(n));
  else if (Array.isArray(value)) {
    out.push(value.length);
    value.forEach((item) => collectNumbers(item, out));
  } else if (value && typeof value === "object") Object.keys(value).forEach((k) => collectNumbers(value[k], out, k));
  return out;
}

// Every number GPT writes must come from the figures it was given (counts of listed items allowed).
function insightNumbersMatch(text, data) {
  const known = new Set(collectNumbers(data, []).map((n) => Math.round(n * 100) / 100));
  return numbersInText(text).every((n) => n === 1 || known.has(Math.round(n * 100) / 100));
}

function writeManagementInsight(apiKey, data) {
  return writeOwnerNote(
    apiKey,
    data,
    "You write the Interpretation part of the Management Insight for the owner of Kreezby Bakeshop, a crinkles bakery that sells pouches. "
      + "The data has sales totals for the last 7 and 30 days and the 30 days before, each flavor's stock and sales, alerts, and the business situations already found. "
      + "Reply with JSON only, no markdown: {\"sales\":\"\",\"inventory\":\"\",\"demand\":\"\"}. "
      + "sales: one or two short sentences on how many pouches sold and the sales value in the last 30 days, and whether that is more or less than the 30 days before. "
      + "inventory: one or two short sentences on pouches in stock, flavors out of stock or running low, and expired or near-expiry batches. "
      + "demand: one or two short sentences on which flavors customers buy most, and which are rising, falling or not selling. "
      + "Use simple everyday words. Use only numbers that appear in the data, written exactly as given; write peso amounts with the peso sign. "
      + "Do not invent products, numbers or reasons. Do not forecast. Do not use business jargon. If there are no sales yet, say so plainly.",
    600
  );
}

function parseInterpretation(text) {
  const raw = String(text || "").trim().replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/```$/, "").trim();
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    return null;
  }
  if (!parsed || typeof parsed !== "object") return null;
  const result = {
    sales: cleanInsightText(parsed.sales, 600),
    inventory: cleanInsightText(parsed.inventory, 600),
    demand: cleanInsightText(parsed.demand, 600),
  };
  if (!result.sales || !result.inventory || !result.demand) return null;
  return result;
}

function interpretationText(item) {
  return "Sales: " + item.sales + "\nInventory: " + item.inventory + "\nDemand: " + item.demand;
}

const productRecommendationLastCall = new Map();

function sanitizeProductRecommendation(input) {
  const source = input && typeof input === "object" ? input : {};
  const products = Array.isArray(source.products) ? source.products.slice(0, 12) : [];
  const nonNeg = (v) => { const n = insightNumber(v); return n == null || n < 0 ? 0 : n; };
  const out = {
    asOf: cleanInsightText(source.asOf, 20),
    products: products.map((row) => ({
      name: cleanInsightText(row && row.name, 80),
      finishedStock: nonNeg(row && row.finishedStock),
      expiredStock: nonNeg(row && row.expiredStock),
      pendingOrders: nonNeg(row && row.pendingOrders),
      pendingStillToCover: nonNeg(row && row.pendingStillToCover),
      retailerDeliveries: nonNeg(row && row.retailerDeliveries),
      suggestedBake: nonNeg(row && row.suggestedBake),
      packagingAvailable: row && row.packagingAvailable == null ? null : nonNeg(row.packagingAvailable),
      packagingShort: nonNeg(row && row.packagingShort),
    })).filter((row) => row.name),
    totalBake: nonNeg(source.totalBake),
    dailyCapacity: nonNeg(source.dailyCapacity) || 25,
    daysNeeded: nonNeg(source.daysNeeded),
  };
  // The bake amounts are worked out again here, so a wrong number sent by a page is not used.
  out.products.forEach((row) => {
    const gap = row.pendingStillToCover + row.retailerDeliveries - row.finishedStock;
    row.suggestedBake = gap > 0 ? Math.ceil(gap) : 0;
    row.packagingShort = row.packagingAvailable != null && row.suggestedBake > row.packagingAvailable ? row.suggestedBake - row.packagingAvailable : 0;
  });
  out.totalBake = out.products.reduce((t, r) => t + r.suggestedBake, 0);
  out.daysNeeded = out.totalBake ? Math.ceil(out.totalBake / out.dailyCapacity) : 0;
  return out;
}

function productRecommendationAllowed(ip) {
  const now = Date.now();
  const last = productRecommendationLastCall.get(ip) || 0;
  if (now - last < 8000) return false;
  productRecommendationLastCall.set(ip, now);
  return true;
}

function deterministicRecommendation(snapshot) {
  if (!snapshot.products.length) {
    return "There is not enough finished product or pending order data yet to recommend a bake.";
  }
  const lines = snapshot.products.map((row) => {
    const bake = Number(row.suggestedBake) || 0;
    if (bake > 0) {
      return "Bake " + bake + " pouches of " + row.name + ". Good stock is " + row.finishedStock + ", customer orders still to cover are " + (row.pendingStillToCover || 0)
        + (row.retailerDeliveries ? " and scheduled retailer deliveries need " + row.retailerDeliveries : "") + "."
        + (row.packagingShort ? " Packaging is short by " + row.packagingShort + " pouches." : "");
    }
    return row.name + " is covered. Good stock is " + row.finishedStock + " and no extra pouches are needed.";
  });
  if (snapshot.totalBake) lines.push("In total, bake " + snapshot.totalBake + " pouches, about " + snapshot.daysNeeded + " day(s) at " + snapshot.dailyCapacity + " pouches a day.");
  return lines.join(" ");
}

function recommendationMatchesSnapshot(text, snapshot) {
  const body = String(text || "").toLowerCase();
  // Every number GPT writes must be one of the given figures, and each bake amount must appear.
  if (!insightNumbersMatch(text, snapshot)) return false;
  return snapshot.products.every((row) => {
    if (body.indexOf(String(row.name || "").toLowerCase()) < 0) return false;
    const bake = Number(row.suggestedBake) || 0;
    return bake <= 0 || insightIncludesNumber(text, bake);
  });
}

function writeProductRecommendation(apiKey, snapshot) {
  return writeOwnerNote(
    apiKey,
    snapshot,
    "You write a short production recommendation for the owner of Kreezby Bakeshop, a crinkles bakery. The numbers were already calculated by the system with a fixed formula; you only explain them, you do not change them. Use 4 to 7 short sentences in simple everyday language. finishedStock is good (not expired) pouches; expiredStock is never counted. suggestedBake = pendingStillToCover + retailerDeliveries - finishedStock (0 when covered). When suggestedBake is above 0, name the product and say to bake that many pouches. When it is 0, say that product is covered. If packagingShort is above 0, say packaging is short by that many pouches. End with totalBake and daysNeeded at dailyCapacity pouches a day when totalBake is above 0. Use only numbers from the data, written exactly. Do not forecast future demand. Do not invent figures. Do not use business jargon."
  );
}

app.post("/api/management-insight", async (req, res) => {
  const apiKey = openaiKey();
  if (!apiKey) {
    res.status(503).json({ ok: false, error: "Management insight is not configured (OPENAI_API_KEY is missing on the server)." });
    return;
  }
  const body = req.body || {};
  const data = cleanInsightData(body.data, 0);
  if (!data || typeof data !== "object" || !Array.isArray(data.flavors) || !data.flavors.length) {
    res.status(400).json({ ok: false, error: "There is no sales or stock data to interpret yet." });
    return;
  }
  const fallback = parseInterpretation(JSON.stringify(body.fallback || {}));
  const salesKey = cleanSalesKey(body.salesKey);
  const trigger = cleanTrigger(body.trigger);

  // Not a Refresh click: if someone already wrote an output for these same sales, show that one
  // instead of asking GPT-4o mini again (e.g. two accounts open the page right after a sale).
  if (trigger !== "manual") {
    const saved = await latestAiOutput("management-insight");
    if (saved && saved.salesKey === salesKey && saved.shown) {
      res.json(Object.assign({ ok: true, interpretation: saved.shown, reused: true }, savedMeta(saved)));
      return;
    }
  }

  const ip = req.ip || "local";
  if (!insightAllowed(ip)) {
    res.status(429).json({ ok: false, error: "Please wait a few seconds before asking for another insight." });
    return;
  }

  try {
    const reply = await writeManagementInsight(apiKey, data);
    const parsed = parseInterpretation(reply);
    const matches = !!parsed && insightNumbersMatch(interpretationText(parsed), data);
    const shown = matches ? parsed : fallback;
    if (!shown) {
      res.status(502).json({ ok: false, error: "The management insight could not be written just now." });
      return;
    }
    // Every GPT answer is kept word for word in the output history.
    const saved = mongoReady ? await Promise.race([
      logAiOutput({
        module: "management-insight",
        engine: OPENAI_MODEL,
        inputData: data,
        rawOutput: parsed ? interpretationText(parsed) : reply,
        shownOutput: interpretationText(shown),
        shown,
        usedFallback: !matches,
        salesKey,
        trigger,
        token: retailerRecords.readToken(req),
      }),
      sleep(2000).then(() => null),
    ]) : null;
    res.json(Object.assign({ ok: true, interpretation: shown, usedFallback: !matches, model: OPENAI_MODEL, historyId: saved ? saved.id : null }, saved ? savedMeta(saved) : { createdAt: new Date() }));
  } catch (error) {
    const failure = openAiFailure(error, "management insight");
    if (fallback && failure.status !== 401 && failure.status !== 402) {
      res.json({ ok: true, interpretation: fallback, usedFallback: true, model: OPENAI_MODEL, error: failure.error });
      return;
    }
    res.status(failure.status).json({ ok: false, error: failure.error });
  }
});

app.post("/api/product-recommendation", async (req, res) => {
  const apiKey = openaiKey();
  if (!apiKey) {
    res.status(503).json({ ok: false, error: "Production recommendation is not configured." });
    return;
  }

  const snapshot = sanitizeProductRecommendation(req.body && req.body.snapshot);
  if (!snapshot.products.length) {
    res.json({
      ok: true,
      recommendation: "There is not enough finished product or pending order data yet to recommend a bake.",
      model: OPENAI_MODEL,
    });
    return;
  }

  const salesKey = cleanSalesKey(req.body && req.body.salesKey);
  const trigger = cleanTrigger(req.body && req.body.trigger);

  // Not a Refresh click: reuse the output already written for these same sales.
  if (trigger !== "manual") {
    const saved = await latestAiOutput("production-recommendation");
    if (saved && saved.salesKey === salesKey && saved.shownOutput) {
      res.json(Object.assign({ ok: true, recommendation: saved.shownOutput, reused: true }, savedMeta(saved)));
      return;
    }
  }

  const ip = req.ip || "local";
  if (!productRecommendationAllowed(ip)) {
    res.status(429).json({ ok: false, error: "Please wait a few seconds before asking for another recommendation." });
    return;
  }

  try {
    const recommendation = await writeProductRecommendation(apiKey, snapshot);
    const matches = recommendationMatchesSnapshot(recommendation, snapshot);
    const safeRecommendation = matches
      ? recommendation
      : deterministicRecommendation(snapshot);
    // Every GPT answer is kept word for word in the output history.
    const saved = mongoReady ? await Promise.race([
      logAiOutput({
        module: "production-recommendation",
        engine: OPENAI_MODEL,
        inputData: snapshot,
        rawOutput: recommendation,
        shownOutput: safeRecommendation,
        usedFallback: !matches,
        salesKey,
        trigger,
        token: retailerRecords.readToken(req),
      }),
      sleep(2000).then(() => null),
    ]) : null;
    res.json(Object.assign({ ok: true, recommendation: safeRecommendation, model: OPENAI_MODEL, historyId: saved ? saved.id : null }, saved ? savedMeta(saved) : { createdAt: new Date() }));
  } catch (error) {
    const failure = openAiFailure(error, "production recommendation");
    if (failure.status !== 401 && failure.status !== 402) {
      res.json({
        ok: true,
        recommendation: deterministicRecommendation(snapshot),
        model: OPENAI_MODEL,
        error: failure.error,
      });
      return;
    }
    res.status(failure.status).json({ ok: false, error: failure.error });
  }
});

// ---------- AI output history ----------
// Every GPT-4o mini output (Management Insight and Production Recommendation) is kept in
// ai_output_history with the date, the account that generated it, and the data it was based on.
const AI_HISTORY_COL = "ai_output_history";
const AI_HISTORY_MODULES = {
  "management-insight": "Management Insight",
  "production-recommendation": "Production Recommendation",
};

function aiHistoryCollection() {
  return client.db(DB_NAME).collection(AI_HISTORY_COL);
}

async function accountFromToken(token) {
  if (!token || !token.id) return null;
  const bucket = String(token.bucket || "");
  let name = token.id;
  let role = { admins: "Admin", staff: "Staff" }[bucket] || bucket;
  try {
    const collectionName = ACCOUNT_COLLECTIONS[bucket];
    if (collectionName) {
      const doc = await client.db(DB_NAME).collection(collectionName).findOne({ _id: token.id }, { maxTimeMS: 1500 });
      if (doc) {
        name = doc.name || doc.full_name || doc.username || doc.email || token.id;
        const key = [doc.username, doc.user_id, doc.id, doc._id].map(loginKey).join("|");
        if (bucket === "admins" && /(^|\|)(marcela_admin|admin-owner)(\||$)/.test(key)) role = "Head Admin";
      }
    }
  } catch (error) {
    /* keep the id as the name */
  }
  return { id: String(token.id), name: String(name), role };
}

function safeInputData(value) {
  try {
    const text = JSON.stringify(value == null ? {} : value);
    if (text.length > 60000) return { note: "Input data was too large to keep." };
    return JSON.parse(text);
  } catch (error) {
    return {};
  }
}

function historyFingerprint(module, inputData, output) {
  return crypto.createHash("sha1").update(module + "\n" + JSON.stringify(inputData) + "\n" + output).digest("hex");
}

// Saves one output. The same output from the same data (e.g. reopening the page) is kept once.
async function logAiOutput(entry) {
  if (!mongoReady || !client) return null;
  try {
    const inputData = safeInputData(entry.inputData);
    const shownOutput = String(entry.shownOutput || "").slice(0, 20000);
    const rawOutput = String(entry.rawOutput == null ? shownOutput : entry.rawOutput).slice(0, 20000);
    const fingerprint = historyFingerprint(entry.module, inputData, rawOutput);
    const col = aiHistoryCollection();
    const latest = await col.find({ module: entry.module }).maxTimeMS(1500).sort({ createdAt: -1 }).limit(1).next();
    if (latest && latest.fingerprint === fingerprint) {
      // Same output from the same data: keep one record, but note the sales it now matches.
      if (latest.salesKey !== entry.salesKey) {
        await col.updateOne({ _id: latest._id }, { $set: { salesKey: entry.salesKey || "" } }, { timeoutMS: 1500 });
        latest.salesKey = entry.salesKey || "";
      }
      return Object.assign({ id: String(latest._id) }, latest);
    }
    const doc = {
      _id: "aih-" + Date.now().toString(36) + "-" + crypto.randomBytes(4).toString("hex"),
      module: entry.module,
      createdAt: new Date(),
      generatedBy: (await accountFromToken(entry.token)) || { id: "", name: "Unknown (not signed in)", role: "" },
      engine: String(entry.engine || ""),
      inputData,
      rawOutput,
      shownOutput,
      usedFallback: !!entry.usedFallback,
      salesKey: String(entry.salesKey || ""),
      trigger: String(entry.trigger || ""),
      fingerprint,
    };
    if (entry.shown) doc.shown = entry.shown;
    await col.insertOne(doc, { timeoutMS: 2000 });
    return Object.assign({ id: doc._id }, doc);
  } catch (error) {
    console.error("AI output history: " + error.message);
    return null;
  }
}

// The sales "fingerprint" sent by the page. A new sale changes it; nothing else does.
function cleanSalesKey(value) {
  return String(value == null ? "" : value).replace(/[^\w:.-]/g, "").slice(0, 80);
}

// What asked for the output: "manual" (Refresh button), "new-sales", or "first" (none saved yet).
function cleanTrigger(value) {
  const text = String(value || "");
  return text === "manual" || text === "new-sales" || text === "first" ? text : "first";
}

async function latestAiOutput(module) {
  if (!mongoReady || !client) return null;
  try {
    return await Promise.race([
      aiHistoryCollection().find({ module }).maxTimeMS(1500).sort({ createdAt: -1 }).limit(1).next(),
      sleep(1800).then(() => null),
    ]);
  } catch (error) {
    return null;
  }
}

function savedMeta(doc) {
  return {
    historyId: String(doc.id || doc._id || ""),
    createdAt: doc.createdAt,
    generatedBy: doc.generatedBy || null,
    salesKey: doc.salesKey || "",
    usedFallback: !!doc.usedFallback,
    model: doc.engine || OPENAI_MODEL,
  };
}

function historyToken(req, res) {
  const token = retailerRecords.readToken(req);
  if (!token) {
    res.status(401).json({ ok: false, needLogin: true, error: "Please log out and log in again to see the output history." });
    return null;
  }
  if (token.bucket !== "admins" && token.bucket !== "staff") {
    res.status(403).json({ ok: false, error: "Only head admin, admin and staff accounts can see the output history." });
    return null;
  }
  return token;
}

// The last saved output of one module, so the page shows it instead of writing a new one on every open.
app.get("/api/ai-latest", async (req, res) => {
  if (!databaseReady(res)) return;
  if (!historyToken(req, res)) return;
  const module = String(req.query.module || "");
  if (!AI_HISTORY_MODULES[module]) {
    res.status(400).json({ ok: false, error: "Unknown module." });
    return;
  }
  const doc = await latestAiOutput(module);
  if (!doc) {
    res.json({ ok: true, record: null });
    return;
  }
  const record = Object.assign({ shownOutput: doc.shownOutput || "", shown: doc.shown || null }, savedMeta(doc));
  res.json({ ok: true, record });
});

app.get("/api/ai-history", async (req, res) => {
  if (!databaseReady(res)) return;
  if (!historyToken(req, res)) return;
  try {
    const filter = {};
    const module = String(req.query.module || "");
    if (AI_HISTORY_MODULES[module]) filter.module = module;
    const from = Number(req.query.from);
    const to = Number(req.query.to);
    if (Number.isFinite(from) && from > 0) filter.createdAt = Object.assign(filter.createdAt || {}, { $gte: new Date(from) });
    if (Number.isFinite(to) && to > 0) filter.createdAt = Object.assign(filter.createdAt || {}, { $lte: new Date(to) });
    const col = aiHistoryCollection();
    const total = await col.countDocuments(filter);
    const limit = Math.min(Math.max(Number(req.query.limit) || 300, 1), 2000);
    const rows = await col.find(filter).sort({ createdAt: -1 }).limit(limit).toArray();
    res.json({
      ok: true,
      total,
      records: rows.map((doc) => {
        const row = { ...doc, id: String(doc._id) };
        delete row._id;
        delete row.fingerprint;
        row.moduleLabel = AI_HISTORY_MODULES[row.module] || row.module;
        return row;
      }),
    });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

const PAYMONGO_API = "https://api.paymongo.com";

function paymongoSecret() {
  return String(process.env.PAYMONGO_SECRET_KEY || "").trim();
}

function paymongoErrorMessage(payload, fallback) {
  const detail = payload && payload.errors && payload.errors[0]
    ? (payload.errors[0].detail || payload.errors[0].code)
    : "";
  return String(detail || fallback || "PayMongo request failed").slice(0, 240);
}

async function paymongoRequest(method, apiPath, body) {
  const response = await fetch(PAYMONGO_API + apiPath, {
    method,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Basic " + Buffer.from(paymongoSecret() + ":").toString("base64"),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(paymongoErrorMessage(payload));
    error.status = response.status;
    throw error;
  }
  return payload;
}

function paymongoReturnUrl(req, value) {
  try {
    const url = new URL(String(value || ""));
    const host = req.get("host");
    const localPage = /^(localhost|127\.0\.0\.1)$/i.test(url.hostname);
    const localApi = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(host || "");
    return (url.protocol === "http:" || url.protocol === "https:") && (url.host === host || (localPage && localApi));
  } catch (error) {
    return false;
  }
}

function allowLocalPaymongo(req, res, next) {
  const origin = String(req.get("origin") || "");
  if (/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Kreezby-Token");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Private-Network", "true");
  }
  if (req.method === "OPTIONS") {
    res.sendStatus(204);
    return;
  }
  next();
}

function paymongoPublicIntent(resource) {
  const data = resource && resource.data ? resource.data : resource;
  const attributes = (data && data.attributes) || {};
  const payment = Array.isArray(attributes.payments) && attributes.payments[0]
    ? attributes.payments[0]
    : null;
  const paymentAttributes = (payment && payment.attributes) || {};
  const source = paymentAttributes.source || {};
  const lastError = attributes.last_payment_error || null;
  return {
    paymentIntentId: data && data.id ? data.id : "",
    status: attributes.status || "",
    amount: Number(attributes.amount || 0) / 100,
    currency: attributes.currency || "PHP",
    wallet: (attributes.metadata && attributes.metadata.wallet) || source.type || "",
    lastPaymentError: lastError ? String(lastError.detail || lastError.message || "Payment was not completed.").slice(0, 240) : "",
  };
}

const PAYMONGO_CHECKOUT_METHODS = {
  qrph: { type: "qrph" },
  gcash: { type: "gcash", redirect: true },
  paymaya: { type: "paymaya", redirect: true },
};

function paymongoRedirectUrl(nextAction) {
  const raw = nextAction && nextAction.redirect && nextAction.redirect.url ? String(nextAction.redirect.url) : "";
  try {
    const parsed = new URL(raw);
    const host = parsed.hostname.toLowerCase();
    const okHost = host === "paymongo.com" || host.endsWith(".paymongo.com") || host === "pm.link";
    return parsed.protocol === "https:" && okHost ? parsed.toString() : "";
  } catch (error) {
    return "";
  }
}

function paymongoQrDataUri(nextAction) {
  const code = nextAction && nextAction.code;
  const image = code && code.image_url ? String(code.image_url).replace(/\s+/g, "") : "";
  if (!/^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$/.test(image)) return "";
  if (image.length < 80 || image.length > 2 * 1024 * 1024) return "";
  return image;
}

function paymongoTestUrl(nextAction) {
  const code = nextAction && nextAction.code;
  const raw = code && code.test_url ? String(code.test_url) : "";
  try {
    const parsed = new URL(raw);
    const host = parsed.hostname.toLowerCase();
    if (parsed.protocol !== "https:" || (host !== "paymongo.com" && !host.endsWith(".paymongo.com"))) return "";
    return parsed.toString();
  } catch (error) {
    return "";
  }
}

async function scannableQr(text) {
  const value = String(text || "").trim();
  if (!value || value.length > 2000) return "";
  return QRCode.toDataURL(value, {
    errorCorrectionLevel: "M",
    margin: 4,
    width: 360,
    color: { dark: "#111111", light: "#ffffff" },
  });
}

app.use("/api/paymongo", allowLocalPaymongo);

app.post("/api/paymongo/e-wallet", async (req, res) => {
  if (!/^sk_(test|live)_/.test(paymongoSecret())) {
    res.status(503).json({
      ok: false,
      error: "PayMongo is not configured. In the PayMongo dashboard, switch to test mode, open Settings, then Developers, and set PAYMONGO_SECRET_KEY.",
    });
    return;
  }

  const body = req.body || {};
  const requested = String(body.wallet || "qrph");
  const methodInfo = PAYMONGO_CHECKOUT_METHODS[requested];
  const wallet = methodInfo ? requested : "";
  const amount = Number(body.amount);
  const centavos = Math.round(amount * 100);
  const name = String(body.name || "").trim();
  const email = String(body.email || "").trim();
  const phone = String(body.phone || "").trim();
  const audience = body.audience === "wholesaler" ? "wholesaler" : (body.audience === "customer" ? "customer" : "");
  if (!wallet || !audience || !name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    res.status(400).json({ ok: false, error: "Enter the payer name and email before paying with QR Ph." });
    return;
  }
  if (!Number.isFinite(amount) || centavos < 2000 || centavos > 100000000) {
    res.status(400).json({ ok: false, error: "PayMongo accepts payments from ₱20.00 up to ₱1,000,000.00." });
    return;
  }
  if (!paymongoReturnUrl(req, body.returnUrl)) {
    res.status(400).json({ ok: false, error: "PayMongo could not return to this page." });
    return;
  }

  try {
    // GCash / Maya: send the customer straight into the app (or the wallet's sign-in page).
    if (methodInfo.redirect) {
      const walletIntent = await paymongoRequest("POST", "/v1/payment_intents", {
        data: {
          attributes: {
            amount: centavos,
            payment_method_allowed: [methodInfo.type],
            currency: "PHP",
            capture_type: "automatic",
            description: String(body.description || "Kreezby Bakeshop order").slice(0, 255),
            statement_descriptor: "KREEZBY",
            metadata: { reference: String(body.reference || "").slice(0, 80), audience, wallet },
          },
        },
      });
      const walletMethod = await paymongoRequest("POST", "/v1/payment_methods", {
        data: {
          attributes: {
            type: methodInfo.type,
            billing: Object.assign({ name: name.slice(0, 80), email }, phone ? { phone: phone.slice(0, 20) } : {}),
          },
        },
      });
      const walletAttached = await paymongoRequest("POST", "/v1/payment_intents/" + walletIntent.data.id + "/attach", {
        data: { attributes: { payment_method: walletMethod.data.id, return_url: String(body.returnUrl) } },
      });
      const walletAttributes = walletAttached.data.attributes || {};
      const redirectUrl = paymongoRedirectUrl(walletAttributes.next_action);
      if (!redirectUrl) {
        res.status(502).json({ ok: false, error: "PayMongo did not return a link to the app." });
        return;
      }
      res.json({
        ok: true,
        paymentIntentId: walletAttached.data.id,
        status: walletAttributes.status || "",
        redirectUrl,
        wallet,
      });
      return;
    }

    // QR Ph payment-intent flow (test and live):
    //   1. create a Payment Intent with "qrph" allowed, 2. create a qrph Payment Method,
    //   3. attach it; the response's next_action.code.image_url is the QR Ph image.
    // Live mode shows that real QR Ph image, which GCash, Maya and bank apps can scan.
    // Test mode shows a QR of PayMongo's test page instead (open it with the phone camera
    // and choose "Authorize"), because test QR Ph codes cannot be paid in real apps.
    // PayMongo sends payment.paid to the webhook once the payment goes through.
    const isTestKey = /^sk_test_/.test(paymongoSecret());
    {
      const intent = await paymongoRequest("POST", "/v1/payment_intents", {
        data: {
          attributes: {
            amount: centavos,
            payment_method_allowed: [methodInfo.type],
            currency: "PHP",
            capture_type: "automatic",
            description: String(body.description || "Kreezby Bakeshop order").slice(0, 255),
            statement_descriptor: "KREEZBY",
            metadata: { reference: String(body.reference || "").slice(0, 80), audience, wallet },
          },
        },
      });
      const method = await paymongoRequest("POST", "/v1/payment_methods", {
        data: {
          attributes: {
            type: methodInfo.type,
            billing: Object.assign({ name: name.slice(0, 80), email }, phone ? { phone: phone.slice(0, 20) } : {}),
          },
        },
      });
      const attachedIntent = await paymongoRequest("POST", "/v1/payment_intents/" + intent.data.id + "/attach", {
        data: { attributes: { payment_method: method.data.id, return_url: String(body.returnUrl) } },
      });
      const intentAttributes = attachedIntent.data.attributes || {};
      const realQr = paymongoQrDataUri(intentAttributes.next_action);
      const intentTestUrl = isTestKey ? paymongoTestUrl(intentAttributes.next_action) : "";
      const intentQr = isTestKey
        ? ((intentTestUrl ? await scannableQr(intentTestUrl) : "") || realQr)
        : realQr;
      if (intentQr) {
        res.json({
          ok: true,
          paymentIntentId: attachedIntent.data.id,
          status: intentAttributes.status || "",
          qrImage: intentQr,
          testUrl: intentTestUrl,
          wallet,
        });
        return;
      }
      if (isTestKey) {
        res.status(502).json({ ok: false, error: "PayMongo did not return a QR Ph code." });
        return;
      }
      // Live mode with no QR image returned: fall back to PayMongo's hosted checkout below.
    }

    // Live mode: hosted PayMongo Checkout: a normal https page that opens from any phone camera,
    // where the customer picks QR Ph / GCash / Maya and pays.
    const referenceText = String(body.reference || "").slice(0, 80);
    const buildSession = (methods) => ({
      data: {
        attributes: {
          billing: Object.assign({ name: name.slice(0, 80), email }, phone ? { phone: phone.slice(0, 20) } : {}),
          send_email_receipt: true,
          show_description: true,
          show_line_items: true,
          description: String(body.description || "Kreezby Bakeshop order").slice(0, 255),
          line_items: [{
            currency: "PHP",
            amount: centavos,
            name: "Kreezby Bakeshop order",
            quantity: 1,
          }],
          payment_method_types: methods,
          reference_number: referenceText || undefined,
          success_url: String(body.returnUrl),
          cancel_url: String(body.returnUrl),
          metadata: { reference: referenceText, audience, wallet },
        },
      },
    });
    let session;
    try {
      session = await paymongoRequest("POST", "/v1/checkout_sessions", buildSession(["qrph", "gcash", "paymaya"]));
    } catch (error) {
      // A method that is not switched on for the account is rejected: retry with QR Ph only.
      if (!error.status || error.status >= 500) throw error;
      session = await paymongoRequest("POST", "/v1/checkout_sessions", buildSession(["qrph"]));
    }
    const attributes = (session.data && session.data.attributes) || {};
    const checkoutUrl = paymongoTestUrl({ code: { test_url: attributes.checkout_url } });
    if (!checkoutUrl) {
      res.status(502).json({ ok: false, error: "PayMongo did not return a payment page." });
      return;
    }
    const intentOf = (attrs) => {
      const ref = attrs && attrs.payment_intent;
      return ref && typeof ref === "object" ? String(ref.id || "") : String(ref || "");
    };
    let intentId = intentOf(attributes);
    if (!/^pi_/.test(intentId)) {
      const again = await paymongoRequest("GET", "/v1/checkout_sessions/" + session.data.id);
      intentId = intentOf(again.data && again.data.attributes);
    }
    if (!/^pi_[A-Za-z0-9]+$/.test(intentId)) {
      res.status(502).json({ ok: false, error: "PayMongo did not return a payment reference." });
      return;
    }
    const qrImage = await scannableQr(checkoutUrl);
    const testUrl = checkoutUrl;
    const attached = { data: { id: intentId } };
    res.json({
      ok: true,
      paymentIntentId: attached.data.id,
      status: "awaiting_payment",
      qrImage,
      testUrl,
      wallet,
    });
  } catch (error) {
    res.status(error.status && error.status < 500 ? error.status : 502).json({
      ok: false,
      error: error.message || "PayMongo could not start the payment.",
    });
  }
});

app.get("/api/paymongo/payment-intents/:id", async (req, res) => {
  if (!/^sk_(test|live)_/.test(paymongoSecret())) {
    res.status(503).json({ ok: false, error: "PayMongo is not configured." });
    return;
  }
  if (!/^pi_[A-Za-z0-9]+$/.test(req.params.id || "")) {
    res.status(400).json({ ok: false, error: "Unknown PayMongo payment." });
    return;
  }
  try {
    const intent = await paymongoRequest("GET", "/v1/payment_intents/" + req.params.id);
    const info = paymongoPublicIntent(intent);
    // The status check also settles a waiting order, in case the webhook is not set up.
    if (info.status === "succeeded") {
      try {
        const settled = await settleQrOrder(info.paymentIntentId, "paid", { amount: info.amount });
        // The page asks every few seconds: log only when this check changed the order.
        if (settled && (settled.result === "paid" || settled.result === "amount_mismatch" || settled.result === "paid_after_cancel")) {
          await logPaymentEvent({ source: "status_check", type: "payment_intent.succeeded", paymentIntentId: info.paymentIntentId,
            orderNumber: settled.order ? settled.order.orderNumber : "", amount: info.amount, result: settled.result });
        }
      } catch (error) { /* the page still updates */ }
    }
    res.json(Object.assign({ ok: true }, info));
  } catch (error) {
    res.status(error.status && error.status < 500 ? error.status : 502).json({
      ok: false,
      error: error.message || "PayMongo could not be checked.",
    });
  }
});

// Every PayMongo event the server receives is kept in payment_events (for audit and testing):
// source (webhook or status check), PayMongo event type, payment intent and payment references,
// order number, amount, and what the system did with it (paid, duplicate ignored, failed,
// expired, amount mismatch, no matching order, invalid signature).
async function logPaymentEvent(entry) {
  try {
    if (!mongoReady) return;
    await client.db(DB_NAME).collection("payment_events").insertOne(Object.assign({ at: new Date() }, entry));
  } catch (error) {
    console.error("Payment event log: " + error.message);
  }
}

// PayMongo webhook: https://<site>/api/paymongo/webhook
// Needs PAYMONGO_WEBHOOK_SECRET (the whsk_... secret of the webhook in the PayMongo dashboard).
// Marks a waiting QR Ph order paid (or expired) on the server, so it updates even if the
// customer never returns to the checkout page after paying in GCash.
async function settleQrOrder(paymentIntentId, outcome, details) {
  if (!mongoReady || !paymentIntentId || typeof cache.kreezbyOrders !== "string") return { order: null, result: "not_ready" };
  let orders;
  try { orders = JSON.parse(cache.kreezbyOrders); } catch (error) { return { order: null, result: "not_ready" }; }
  if (!Array.isArray(orders)) return { order: null, result: "not_ready" };
  const order = orders.find((o) => o && o.paymongo && o.paymongo.paymentIntentId === paymentIntentId);
  if (!order) return { order: null, result: "no_matching_order" };
  // The same payment reported again (PayMongo retries, or the webhook and the status check
  // both report it): nothing changes, so the order is never paid or deducted twice.
  if (order.paymentStatus === "paid") return { order, result: outcome === "paid" ? "duplicate_ignored" : "already_paid" };
  const now = new Date();
  let result = outcome;
  if (order.status === "Cancelled") {
    // Never flip a cancelled order back to paid. If the customer still paid the old QR code,
    // the money must go back: the order shows "Refund pending" for the admin to refund.
    if (outcome !== "paid" || order.paymentStatus === "refund_pending" || order.paymentStatus === "refunded") {
      return { order, result: "order_cancelled" };
    }
    result = "paid_after_cancel";
    const received = details && details.amount != null ? Number(details.amount) : Number(order.totalAmount) || 0;
    order.paymentStatus = "refund_pending";
    order.refund = { status: "pending", amount: received, requestedAt: now.toISOString(), note: "Paid after the order was cancelled" };
    order.paymongo = Object.assign({}, order.paymongo, details || {}, { status: "succeeded" });
    delete order.paymongo.qrImage;
  } else if (outcome === "paid" && details && details.amount != null && Number.isFinite(Number(order.totalAmount))
      && Math.abs(Number(details.amount) - Number(order.totalAmount)) > 0.009) {
    // The amount paid does not match the order total: hold it for the admin to check.
    if (order.paymentStatus === "under_review") return { order, result: "duplicate_ignored" };
    result = "amount_mismatch";
    order.paymentStatus = "under_review";
    order.status = "Payment under review";
    order.paymongo = Object.assign({}, order.paymongo, details || {}, { status: "amount_mismatch", expectedAmount: Number(order.totalAmount) });
    delete order.paymongo.qrImage;
  } else if (outcome === "paid") {
    order.paymentStatus = "paid";
    order.paymentVerified = true;
    // A failed attempt can be followed by a successful one on the same payment.
    if (order.status === "Awaiting payment" || order.status === "Payment failed") order.status = "Processing";
    order.paymentFailed = false;
    order.paidAt = order.paidAt || now.toISOString();
    order.paymongo = Object.assign({}, order.paymongo, details || {}, { status: "succeeded" });
    delete order.paymongo.qrImage;
  } else if (outcome === "expired") {
    if (order.paymentStatus !== "awaiting_payment") return { order, result: "ignored" };
    order.paymentStatus = "expired";
    order.status = "Payment expired";
    order.paymongo = Object.assign({}, order.paymongo, { status: "expired" });
  } else if (outcome === "failed") {
    if (order.paymentStatus !== "awaiting_payment") return { order, result: "ignored" };
    order.paymentStatus = "failed";
    order.paymentFailed = true;
    order.status = "Payment failed";
    order.paymongo = Object.assign({}, order.paymongo, { status: "failed", lastPaymentError: String((details && details.error) || "").slice(0, 240) });
    delete order.paymongo.qrImage;
  } else {
    return { order, result: "ignored" };
  }
  const items = { kreezbyOrders: JSON.stringify(orders) };
  ["kreezbyCustomerReceipts", "kreezbyOwnerReceipts"].forEach((key) => {
    if (typeof cache[key] !== "string") return;
    try {
      const list = JSON.parse(cache[key]);
      if (!Array.isArray(list)) return;
      let touched = false;
      list.forEach((r) => {
        if (r && r.orderNumber === order.orderNumber) {
          r.paymentStatus = ({ paid: "Paid", expired: "Payment expired", failed: "Payment failed", amount_mismatch: "Payment under review", paid_after_cancel: "Refund pending" })[result] || r.paymentStatus;
          touched = true;
        }
      });
      if (touched) items[key] = JSON.stringify(list);
    } catch (error) { /* leave receipts as they are */ }
  });
  if (result === "paid_after_cancel") {
    try {
      const notes = JSON.parse(cache.kreezbyNotifications || "[]");
      if (Array.isArray(notes) && !notes.some((n) => n && n.id === "n-refund-due-" + order.orderNumber)) {
        notes.unshift({
          id: "n-refund-due-" + order.orderNumber,
          title: "Refund needed",
          description: "Cancelled order " + order.orderNumber + " was paid (₱" + Number(order.refund.amount).toFixed(2) + ") after it was cancelled. Refund it in PayMongo, then record the refund on the order.",
          timestamp: now.toISOString(),
          read: false,
          source: "payment",
          audiences: ["head", "admin"],
        });
        items.kreezbyNotifications = JSON.stringify(notes);
      }
    } catch (error) { /* notification is optional */ }
  }
  if (result === "amount_mismatch") {
    try {
      const notes = JSON.parse(cache.kreezbyNotifications || "[]");
      if (Array.isArray(notes) && !notes.some((n) => n && n.id === "n-review-" + order.orderNumber)) {
        notes.unshift({
          id: "n-review-" + order.orderNumber,
          title: "Payment needs checking",
          description: "Order " + order.orderNumber + ": ₱" + Number(details.amount).toFixed(2) + " was paid but the order total is ₱" + Number(order.totalAmount).toFixed(2) + ". Check it in PayMongo before processing the order.",
          timestamp: now.toISOString(),
          read: false,
          source: "payment",
          audiences: ["head", "admin"],
        });
        items.kreezbyNotifications = JSON.stringify(notes);
      }
    } catch (error) { /* notification is optional */ }
  }
  if (result === "paid") {
    try {
      const notes = JSON.parse(cache.kreezbyNotifications || "[]");
      if (Array.isArray(notes) && !notes.some((n) => n && n.id === "n-paid-" + order.orderNumber)) {
        notes.unshift({
          id: "n-paid-" + order.orderNumber,
          title: "Payment Received",
          description: "QR Ph payment received for order " + order.orderNumber + " (" + order.total + ").",
          timestamp: now.toISOString(),
          read: false,
          source: "payment",
        });
        items.kreezbyNotifications = JSON.stringify(notes);
      }
    } catch (error) { /* notification is optional */ }
  }
  const ops = Object.entries(items).map(([key, value]) => {
    cache[key] = value;
    cacheTouched[key] = Date.now();
    return { updateOne: { filter: { _id: key }, update: { $set: { value, updatedAt: now } }, upsert: true } };
  });
  stateVersion = Date.now();
  ops.push({ updateOne: { filter: { _id: "state_meta" }, update: { $set: { value: String(stateVersion) } }, upsert: true } });
  await collection().bulkWrite(ops, { ordered: false });
  await syncCustomerOrderDocs([order]);
  await mirrorSaved(items);
  console.log("QR order " + order.orderNumber + " marked " + result);
  return { order, result };
}

app.post("/api/paymongo/webhook", async (req, res) => {
  const secret = String(process.env.PAYMONGO_WEBHOOK_SECRET || "").trim();
  if (!secret) {
    console.error("PayMongo webhook: PAYMONGO_WEBHOOK_SECRET is not set");
    res.status(500).json({ ok: false, error: "Webhook not configured" });
    return;
  }
  const rawBody = typeof req.rawBody === "string" ? req.rawBody : "";
  const parts = {};
  String(req.get("paymongo-signature") || "").split(",").forEach((piece) => {
    const i = piece.indexOf("=");
    if (i > 0) parts[piece.slice(0, i).trim()] = piece.slice(i + 1).trim();
  });
  const attrs = (req.body && req.body.data && req.body.data.attributes) || {};
  const given = attrs.livemode === true ? parts.li : parts.te;
  const expected = crypto.createHmac("sha256", secret).update(String(parts.t || "") + "." + rawBody).digest("hex");
  const age = Math.abs(Math.floor(Date.now() / 1000) - Number(parts.t));
  const valid = rawBody && parts.t && given && given.length === expected.length && Number.isFinite(age) && age <= 300
    && crypto.timingSafeEqual(Buffer.from(given, "utf8"), Buffer.from(expected, "utf8"));
  if (!valid) {
    await logPaymentEvent({ source: "webhook", type: String(attrs.type || ""), result: "invalid_signature" });
    res.status(401).json({ ok: false, error: "Invalid signature" });
    return;
  }
  const resource = attrs.data || {};
  const resourceAttrs = resource.attributes || {};
  // payment.paid / checkout_session.payment.paid confirm the QR Ph payment. The checkout page
  // also polls /api/paymongo/payment-intents/:id and places the order once it reads "succeeded".
  console.log("PayMongo webhook:", attrs.type, resource.id || "", resourceAttrs.payment_intent_id || "",
    resourceAttrs.amount != null ? Number(resourceAttrs.amount) / 100 : "");
  try {
    const intentId = String(resourceAttrs.payment_intent_id || (resource.id && String(resource.id).indexOf("pi_") === 0 ? resource.id : "") || "");
    const amount = resourceAttrs.amount != null ? Number(resourceAttrs.amount) / 100 : undefined;
    let settled = { order: null, result: "ignored" };
    if (attrs.type === "payment.paid" || attrs.type === "checkout_session.payment.paid") {
      settled = await settleQrOrder(intentId, "paid", { paymentId: resource.id || "", amount });
    } else if (attrs.type === "qrph.expired" || attrs.type === "payment.failed") {
      const failure = resourceAttrs.failed_message || resourceAttrs.failed_code || "";
      settled = await settleQrOrder(intentId, attrs.type === "qrph.expired" ? "expired" : "failed", { error: failure });
    }
    await logPaymentEvent({
      source: "webhook",
      eventId: String((req.body && req.body.data && req.body.data.id) || ""),
      type: String(attrs.type || ""),
      paymentIntentId: intentId,
      paymentId: String(resource.id || ""),
      orderNumber: settled.order ? settled.order.orderNumber : "",
      amount,
      result: settled.result,
    });
  } catch (error) {
    console.error("Webhook could not update the order: " + error.message);
  }
  res.json({ ok: true });
});

// ---- Error monitoring --------------------------------------------------------------------------
// Server errors and browser errors are kept in the error_log collection (newest first) so they can
// be checked after the fact; head admin / admin read them at GET /api/error-log.
async function logError(entry) {
  try {
    if (!mongoReady || !client) return;
    await client.db(DB_NAME).collection("error_log").insertOne(Object.assign({ at: new Date() }, entry));
  } catch (error) {
    console.error("Error log: " + error.message);
  }
}

const clientErrorCount = new Map();
app.post("/api/client-error", async (req, res) => {
  const ip = clientIp(req);
  const now = Date.now();
  const row = clientErrorCount.get(ip) || { n: 0, since: now };
  if (now - row.since > 60000) { row.n = 0; row.since = now; }
  row.n += 1;
  clientErrorCount.set(ip, row);
  if (row.n <= 20) {
    const b = req.body || {};
    const token = requestToken(req);
    await logError({
      source: "browser",
      message: String(b.message || "").slice(0, 500),
      where: String(b.source || "").slice(0, 300) + (b.line ? ":" + Number(b.line) : ""),
      page: String(b.page || "").slice(0, 300),
      stack: String(b.stack || "").slice(0, 2000),
      account: token ? String(token.id) : "",
      bucket: token ? String(token.bucket) : "guest",
      userAgent: String(req.headers["user-agent"] || "").slice(0, 200),
    });
  }
  res.json({ ok: true });
});

app.get("/api/error-log", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = requestToken(req);
  if (!token || token.bucket !== "admins") { res.status(token ? 403 : 401).json({ ok: false, error: "Only admins can read the error log." }); return; }
  const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
  const rows = await client.db(DB_NAME).collection("error_log").find({}).sort({ at: -1 }).limit(limit).toArray();
  res.json({ ok: true, errors: rows });
});

// ---- Backup -----------------------------------------------------------------------------------
// Head admin / admin download a full copy of the database as one JSON file (every collection).
// It is restored with: node scripts/restore-db.js <file> --confirm
app.get("/api/backup", async (req, res) => {
  if (!databaseReady(res)) return;
  const token = requestToken(req);
  if (!token || token.bucket !== "admins") { res.status(token ? 403 : 401).json({ ok: false, error: "Only admins can download a backup." }); return; }
  try {
    const db = client.db(DB_NAME);
    const cols = await db.listCollections({}, { nameOnly: true }).toArray();
    const out = { database: DB_NAME, createdAt: new Date().toISOString(), collections: {} };
    for (const c of cols) out.collections[c.name] = await db.collection(c.name).find({}).toArray();
    await writeSecurityLog(token, "backup_downloaded", req, { collections: cols.length });
    const stamp = new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 16).replace(/[-:T]/g, "");
    res.setHeader("Content-Disposition", "attachment; filename=\"kreezby-backup-" + stamp + ".json\"");
    res.type("application/json").send(JSON.stringify(out));
  } catch (error) {
    await logError({ source: "server", message: "Backup failed: " + error.message, where: "/api/backup" });
    res.status(500).json({ ok: false, error: "The backup could not be made." });
  }
});

app.get("/", (req, res) => {
  res.redirect("/auth/start.html");
});

const staticOptions = {
  setHeaders(res, filePath) {
    // Always revalidate code files so edits show up without a hard refresh.
    if (/\.(html|js|css)$/i.test(filePath)) res.setHeader("Cache-Control", "no-cache");
  },
};
app.use(express.static(SITE_ROOT, staticOptions));
// Vercel (vercel.json rewrites, old links, the root index.html) may ask for the same files
// under /Kreezby-Bakeshop-main/... — serve them there too instead of "Cannot GET".
app.use("/Kreezby-Bakeshop-main", express.static(SITE_ROOT, staticOptions));

// Unknown API paths answer in JSON, and any error thrown in a route is logged and answered
// without showing the server's internals.
app.use("/api", (req, res) => {
  res.status(404).json({ ok: false, error: "Unknown API address." });
});
app.use((err, req, res, next) => {
  const status = err && (err.status || err.statusCode) >= 400 && (err.status || err.statusCode) < 500 ? (err.status || err.statusCode) : 500;
  if (status >= 500) logError({ source: "server", message: String(err && err.message || err).slice(0, 500), where: req.method + " " + req.path, stack: String(err && err.stack || "").slice(0, 2000) });
  if (res.headersSent) return next(err);
  res.status(status).json({ ok: false, error: status === 400 ? "The request could not be read." : (status === 413 ? "The request is too large." : "Something went wrong on the server.") });
});
process.on("unhandledRejection", (reason) => {
  console.error("Unhandled rejection: " + (reason && reason.message ? reason.message : reason));
  logError({ source: "server", message: "Unhandled rejection: " + String(reason && reason.message ? reason.message : reason).slice(0, 500) });
});

function listenOn(host) {
  const server = app.listen(PORT, host);
  server.on("listening", () => {
    console.log("Kreezby server on http://" + (host === "::1" ? "localhost" : host) + ":" + PORT);
  });
  server.on("error", (error) => {
    if (host === "::1") {
      console.error("IPv6 localhost skipped: " + error.message);
      return;
    }
    console.error(error);
    process.exit(1);
  });
}

async function main() {
  listenOn("127.0.0.1");
  listenOn("::1");
  console.log("Open http://localhost:" + PORT + "/auth/start.html");
  if (!process.env.MONGODB_URI) {
    console.error("Missing MONGODB_URI in .env. The site is still available. Shared shop data stays in this browser.");
    return;
  }
  await maintainMongo();
}

if (require.main === module && !SERVERLESS) {
  main().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}

module.exports = app;
